package linsem.model;

import java.util.List;
import java.util.Map;

public interface KripkeFrame<ID,M> {
	public String getName();
	public void setName(String name);
	public List<ID> getW();
	public int sizeW();
	public void setW(List<ID> w) throws Exception;
	public void setW(ID[] w) throws Exception;
	public Map<ID, M> getR();
	public void setR(Map<ID, M> r) throws Exception;
	public void clear();
}
