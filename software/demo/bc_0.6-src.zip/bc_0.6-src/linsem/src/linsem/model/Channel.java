package linsem.model;

import java.util.Map;

public interface Channel<ID,M> {
	public Map<ID, M> getC();
	public void setC(Map<ID, M> c) throws Exception;	
}
