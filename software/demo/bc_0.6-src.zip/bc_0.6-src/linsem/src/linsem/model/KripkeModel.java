package linsem.model;

import java.util.List;

public interface KripkeModel<ID,M> extends KripkeFrame<ID,M>{
	public List<ID> getP();
	public int sizeP();
	public void setP(List<ID> p) throws Exception;
	public void setP(ID[] p) throws Exception;
	public M getV();
	public void setV(M v) throws Exception;
}
