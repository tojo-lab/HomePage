package linsem.model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract class AbstractKripkeModel<ID,M> implements ChanneledKripkeModel<ID,M> {

	protected String	name = "";
	protected List<ID> 	 W = null; //possible worlds
	protected List<ID>	 G = null; //agents
	protected Map<ID, M> R = null; //accessibility relations (Note: This should be LinkedHashMap to assure ordering).  
	protected Map<ID, M> C = null; //channel relations (Note: This should be LinkedHashMap to assure ordering).
	protected List<ID>	 P = null; //propositions
	protected M 		 V = null; //valuation
	
	public AbstractKripkeModel(){}
	
	public AbstractKripkeModel(String name){
		this.name = name;
	}
	
	public AbstractKripkeModel(String name, List<ID> w, List<ID> g, Map<ID, M> r, Map<ID, M> c, List<ID> p, M v) throws Exception{
		this(name);
		setW(w);
		setG(g);
		setR(r);
		setC(c);
		setP(p);
		setV(v);
	}	
	
	public AbstractKripkeModel(String name, ID[] w, ID[] g, Map<ID, M> r, Map<ID, M> c, ID[] p, M v) throws Exception{
		this(name, Arrays.asList(w), Arrays.asList(g), r, c, Arrays.asList(p), v);
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}

	public List<ID> getW() {
		return W;
	}
	
	public int sizeW(){
		return W.size();
	}

	public void setW(List<ID> w) throws Exception {
		if(check_duplication(w)) throw new Exception("Duplicated id list inserted.");
		W = w;
	}
	
	public void setW(ID[] w) throws Exception {
		setW(Arrays.asList(w));
	}

	public List<ID> getG() {
		return G;
	}
	
	public int sizeG(){
		return G.size();
	}

	public void setG(List<ID> g) throws Exception {
		if(check_duplication(g)) throw new Exception("Duplicated id list inserted.");
		G = g;
	}
	
	public void setG(ID[] g) throws Exception {
		setG(Arrays.asList(g));
	}	

	public Map<ID, M> getR() {
		return R;
	}

	public void setR(Map<ID, M> r) throws Exception {
		if(!check_bin_rel_indices(r, this.G, this.W, this.W))throw new Exception("Wrong index found.");
		R = r;
	}

	public Map<ID, M> getC() {
		return C;
	}

	public void setC(Map<ID, M> c) throws Exception {
		if(!check_bin_rel_indices(c, this.W, this.G, this.G))throw new Exception("Wrong index found.");
		C = c;
	}

	public List<ID> getP() {
		return P;
	}
	
	public int sizeP(){
		return P.size();
	}

	public void setP(List<ID> p) throws Exception {
		if(check_duplication(p)) throw new Exception("Duplicated id list inserted.");
		P = p;
	}
	
	public void setP(ID[] p) throws Exception {
		setP(Arrays.asList(p));
	}	

	public M getV() {
		return V;
	}

	public void setV(M v) throws Exception {
		if(!check_bin_rel_indices(v, this.W, this.P))throw new Exception("Wrong index found.");
		V = v;
	}
	
	public abstract void clear();
	
	protected boolean check_duplication(List<ID> list){
		HashSet<ID> hs = new HashSet<ID>();
		for(ID id: list){
			if(!hs.contains(id))hs.add(id);
			else return true;
		}
		return false;
	}
	
	protected boolean check_index(Set<ID> s, List<ID> list){
		for(ID id: list){
			if(!s.contains(id))return false;
		}
		return true;
	}
	

	//for valuation
	public boolean check_bin_rel_indices(M m, List<ID> from, List<ID> to){
		if(!check_index(m, from, true) || 
			!check_index(m, to, false)) return false;
		return true;		
	}
	
	//for accessibility relations, channel relations
	public boolean check_bin_rel_indices(Map<ID, M> map, List<ID> idx, List<ID> from, List<ID> to){
		if(!check_index(map.keySet(), idx) ||
			!check_bin_rel_indices(map, from, true) || 
			!check_bin_rel_indices(map, to, false)) return false;
		return true;		
	}
	
	//check indices of binary relation
	//"first" option indicates the first element of given relations.
	protected boolean check_bin_rel_indices(Map<ID, M> map, List<ID> list, boolean isFrom){
		Set<ID> keys = map.keySet();
		for(ID key: keys){
			if(!check_index(map.get(key), list, isFrom)) return false;
		}
		return true;
	}
	
	protected abstract boolean check_index(M m, List<ID> list, boolean first);
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append(this.getClass().getSimpleName() + "<" + this.hashCode() + ">\n");
		sb.append("Name=" + name + "\n");
		sb.append("Worlds=" + W.toString() + "\n");
		sb.append("Agents=" + G.toString() + "\n");
		sb.append("Relations=\n" + R.toString() + "\n");
		sb.append("Channels=\n" + C.toString() + "\n");
		sb.append("Valuation=\n" + V.toString() + "\n");
		return sb.toString();
	}
}
