package linsem.model;

import java.util.List;

public interface MultiAgent<ID>{
	public List<ID> getG();
	public int sizeG();
	public void setG(List<ID> g) throws Exception;
	public void setG(ID[] g) throws Exception;

}
