package linsem.model;

public interface ChanneledKripkeModel<ID,M> extends KripkeModel<ID,M>, MultiAgent<ID>, Channel<ID,M> {
	//stub 
}
