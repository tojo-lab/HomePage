package linsem.model;

import java.util.List;
import java.util.Map;

import org.ujmp.core.matrix.SparseMatrix;

public class UJMPKripkeModel<ID> extends AbstractKripkeModel<ID, SparseMatrix>{
	
	public UJMPKripkeModel(){
		super();
	}
	
	public UJMPKripkeModel(String name){
		super(name);
	}
	
	public UJMPKripkeModel(String name, List<ID> w, List<ID> g, Map<ID, SparseMatrix> r, Map<ID, SparseMatrix> c, List<ID> p, SparseMatrix v) throws Exception{
		super(name, w,g,r,c,p,v);
	}
	
	public UJMPKripkeModel(String name, ID[] w, ID[] g, Map<ID, SparseMatrix> r, Map<ID, SparseMatrix> c, ID[] p, SparseMatrix v) throws Exception{
		super(name, w,g,r,c,p,v);
	}
	
	public void clear(){
		W.clear();
		G.clear();
		C.clear();
		P.clear();
		V.clear();
	}
	
	@Override
	protected boolean check_index(SparseMatrix m, List<ID> list, boolean first) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		return true;
	}

}
