package linsem.parser;

import java.io.PrintStream;

import linsem.ast.Location;


public class ErrorHandler {
	
	protected String id;
	protected PrintStream stream;
	protected long errCount;
	protected long warnCount;
	
	public ErrorHandler(String id){
		this.id = id;
		this.stream = System.err;
	}
	
	public ErrorHandler(String id, PrintStream stream){
		this.id = id;
		this.stream = stream;
	}

	public void error(Location loc, String msg){
		error(loc.toString() + ": " + msg);
	}
	
	public void error(String msg){
		stream.println(id + ": error:" + msg);
		errCount++;		
	}
	
	public void warn(Location loc, String msg){
		warn(loc.toString() + ": " + msg);
	}
	
	public void warn(String msg){
		stream.println(id + ": error:" + msg);
		warnCount++;		
	}
	
	public boolean isErrorOccured(){
		return (errCount > 0);
	}
}
