package linsem.parser;

import java.util.Map;
import java.util.Objects;

import linsem.ast.ASTVisitor;
import linsem.ast.AndFormulaNode;
import linsem.ast.AtomicFormulaNode;
import linsem.ast.AtomicProgramNode;
import linsem.ast.ChlFormulaNode;
import linsem.ast.ChoiceProgramNode;
import linsem.ast.CmfProgramNode;
import linsem.ast.CmpProgramNode;
import linsem.ast.ExprNode;
import linsem.ast.ExprStmtNode;
import linsem.ast.IacProgramNode;
import linsem.ast.ImpFormulaNode;
import linsem.ast.LiteralNode;
import linsem.ast.MultiModalFormulaNode;
import linsem.ast.MultiModalFormulaNodeD;
import linsem.ast.NegFormulaNode;
import linsem.ast.OrFormulaNode;
import linsem.ast.TestProgramNode;
import linsem.model.ChanneledKripkeModel;
import linsem.obsolete.CmfFormulaNode;
import linsem.obsolete.IacFormulaNode;
import linsem.obsolete.OldUtil;

import org.ujmp.core.matrix.SparseMatrix;

import linsem.util.UJMPUtil;

public class CalcVisitor implements ASTVisitor<SparseMatrix, SparseMatrix, SparseMatrix>{
	
	protected ChanneledKripkeModel<String, SparseMatrix> model;
	protected boolean verbose = true;
	protected boolean updated = false;
		
	public CalcVisitor(ChanneledKripkeModel<String, SparseMatrix> model){
		super();
		this.model = model;
	}
	
	public CalcVisitor(ChanneledKripkeModel<String, SparseMatrix> model, boolean verbose){
		this(model);
		this.verbose = verbose;
	}

	@Override
	public SparseMatrix visit(ExprStmtNode node) {
		ExprNode expr = node.expr(); 
		return expr.accept(this);
	}

	@Override
	public SparseMatrix visit(ImpFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		SparseMatrix mleft = left.accept(this);
		SparseMatrix mright= right.accept(this);		
		return UJMPUtil.bool_impl(mleft, mright, verbose);
	}

	@Override
	public SparseMatrix visit(OrFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		SparseMatrix mleft = left.accept(this);
		SparseMatrix mright= right.accept(this);
		//(bleft || bright)
		return UJMPUtil.bool_or(mleft, mright, verbose);
	}

	@Override
	public SparseMatrix visit(AndFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		SparseMatrix mleft = left.accept(this);
		SparseMatrix mright= right.accept(this);
		//(bleft && bright)
		return UJMPUtil.bool_and(mleft, mright, verbose);
	}

	@Override
	public SparseMatrix visit(NegFormulaNode node) {
		ExprNode right = node.right();
		SparseMatrix mright = right.accept(this);
		return UJMPUtil.bool_complement(mright, verbose);
	}

	@Override
	public SparseMatrix visit(ChlFormulaNode node) {
		LiteralNode left = (LiteralNode)node.left();
		LiteralNode right = (LiteralNode)node.right();
		String from = left.value();
		String to   = right.value();
		Map<String, SparseMatrix> C = model.getC();
		return UJMPUtil.bool_chl(from, to, C, verbose);		
	}

	@Override
	public SparseMatrix visit(AtomicFormulaNode node) {
		String key = node.value();
		SparseMatrix V = model.getV();
		if(Objects.nonNull(key)){
			Long col = V.getColumnForLabel(key);
			if(col < 0) return null; //if col is -1, there is no such proposition in valuation.
			SparseMatrix mresult = UJMPUtil.bool_atomic_formula(V, col, verbose);
			return mresult;
		}
		return null;
	}
	
	@Override
	public SparseMatrix visit(LiteralNode node) { 
		return null;
	}

	@Override
	public SparseMatrix visit(MultiModalFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		SparseMatrix mleft = left.acceptAsP(this); //modality 
		SparseMatrix mright= right.accept(this);
		return UJMPUtil.bool_modal(mleft, mright, verbose); 
	}
	
	@Override
	public SparseMatrix visit(MultiModalFormulaNodeD node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		SparseMatrix mleft = left.acceptAsP(this); //modality
		SparseMatrix mright= right.accept(this);
		return UJMPUtil.bool_modal_dia(mleft, mright, verbose); 
	}	

	@Override
	public SparseMatrix visit(IacProgramNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		SparseMatrix mleft = left.accept(this); //formula
		SparseMatrix mright= right.acceptAsP(this); //literal (TODO: this should be 'list of literal')
		updated = true;//TODO:
		return UJMPUtil.bool_iac(mleft, mright); 
	}

	@Override
	public SparseMatrix visit(CmfProgramNode node) {
		ExprNode left = node.left();
		LiteralNode center = (LiteralNode) node.center();
		LiteralNode right  = (LiteralNode)node.right();
		SparseMatrix mleft = left.accept(this); //formula
		
		final String from = center.value(); //literal (agent from)
		final String to  = right.value();    //literal (agent to)
		final int card_G = model.sizeG();
		Map<String, SparseMatrix> R = model.getR();
		//SparseMatrix R_from  = R.get(from);	
		//SparseMatrix R_to = R.get(to);
		SparseMatrix R_from = UJMPUtil.bool_atomic_program(R, from ,false);
		SparseMatrix R_to   = UJMPUtil.bool_atomic_program(R, to ,false);
		
		//this is for loop
		int b = UJMPUtil.get_index(to, "_");
		for(int c = 1; c <= card_G; c++){
			if(c == b){
				Map<String, SparseMatrix> C = model.getC();
				SparseMatrix C_ab = UJMPUtil.bool_chl(from, to, C, false);
				SparseMatrix X = UJMPUtil.bool_test(C_ab, false);
				SparseMatrix Y = UJMPUtil.bool_test(UJMPUtil.bool_modal(R_from, mleft, false), false);
				SparseMatrix Z = UJMPUtil.bool_test(mleft, false);
				SparseMatrix R_to_prime = UJMPUtil.bool_cmf(X, Y, R_to, Z, verbose);
				//if(R_to.equals(R_to_prime)) {
				updated = true;
				R_to = R_to_prime;
				R.put(to, R_to); //update
				//}
			}else{}
		}		
		return R_to; 
	} 	
	
	@Override
	public SparseMatrix visit(ChoiceProgramNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		SparseMatrix mleft = left.acceptAsP(this);
		SparseMatrix mright= right.acceptAsP(this);
		return UJMPUtil.bool_choice(mleft, mright, verbose);
		//UJMPUtil.asBooleanMatrix((SparseMatrix)mleft.plus(mright)); //TODO:
	}

	@Override
	public SparseMatrix visit(CmpProgramNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		SparseMatrix mleft = left.acceptAsP(this);
		SparseMatrix mright= right.acceptAsP(this);
		return UJMPUtil.bool_composition(mleft, mright, verbose); 
		//UJMPUtil.asBooleanMatrix((SparseMatrix)mleft.mtimes(mright)); //TODO:
	}

	@Override
	public SparseMatrix visit(TestProgramNode node) {
		ExprNode right = node.right();
		SparseMatrix mright= right.accept(this); // this should be a truth set of a formula
		return UJMPUtil.bool_test(mright, verbose);
	}

	@Override
	public SparseMatrix visit(AtomicProgramNode node) {
		ExprNode right = node.right();
		Map<String, SparseMatrix> R = model.getR();
		if(right instanceof LiteralNode){
			String key = ((LiteralNode)right).value();
			if(Objects.nonNull(key)){
				return UJMPUtil.bool_atomic_program(R, key, verbose);
			}
		}
		return null; //TODO:		
	}

	public boolean isUpdated(){
		return updated;
	}
	
	protected String[] getWLabels(){
		String[] w_labels = model.getW().toArray(new String[0]);
		return w_labels;
	}
	
}
