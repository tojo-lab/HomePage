package linsem;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

import linsem.ast.AST;
import linsem.ast.StmtNode;
import linsem.model.ChanneledKripkeModel;
import linsem.model.UJMPKripkeModel;
import linsem.parser.CalcVisitor;
import linsem.parser.ErrorHandler;
import linsem.parser.ParseException;
import linsem.parser.Parser;
import linsem.parser.TokenMgrError;
import linsem.util.UJMPUtil;

import org.ujmp.core.matrix.SparseMatrix;

public class CUIMain {
	
	public static final String id = "linsem";
	public static final double version = 0.6;
	protected ErrorHandler errHandler;
	protected boolean isContinue = true;
	protected ChanneledKripkeModel<String, SparseMatrix> model;
	protected File file = null;
	
	public CUIMain(String id){
		this.errHandler = new ErrorHandler(id);
		try {
			this.model = getTestModel();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args){
		CUIMain m = new CUIMain(id);
		m.repl();
	}
	
	public void repl(){
		String str = null;
		System.out.println(id + " version " + version);
		System.out.println("simple read-eval-print-loop: '?' shows command list.");
		while(isContinue){
			System.out.print(">");
			str = readLine();
			parse_command(str);
		}
		System.out.println("[halt.]");
	}

	public String readLine(){
		String res = null; 
		BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
		try {
			res = buf.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return res;
	}
			
	public void parse_command(String arg){
		String[] args = arg.split("[ \t\n\r\f]+", 2);		
		
		switch(args[0]){
			case "load":
				if(args.length > 1){
					load(args[1]);					
				}else{ err(); }
				break;
			case "reload":
			case "make":
				if(Objects.nonNull(file)){
					reload();
				}else{ System.out.println("err: no such file."); }
				break;
			case "eval":
				if(args.length > 1){ 
					eval(args[1], model);
				}else{ err(); }
				break;
			case "save":
				if(args.length > 1){
					save(args[1]);
				}else{ err(); }
				break;
			case "show":
				show(); 
				break;
			case "?":
			case "help":
			case "h":
				help();
				break;
			case "exit":
			case "quit":
				exit();
				break;
			default:
				err();
		}
	}
	
	public void load(String path){
		System.out.println("load -> " + path);
	}
	
	public void reload(){
		System.out.println("reload -> " + file.getAbsolutePath());
	}
	
	public void eval(String formula, ChanneledKripkeModel<String, SparseMatrix> model){
		System.out.println("parse -> " + formula);
		try{
			System.out.println("---- begin parsing ----");
			Parser parser = Parser.newStringParser(formula, errHandler, false);
			AST ast = parser.parse_without_eof();
			System.out.println("---- end parsing ----");
			System.out.println("---- begin AST dump ----");
			ast.dump();
			System.out.println("---- end AST dump ----");
			StmtNode[] stmts = ast.stmts();
			for(StmtNode stmt: stmts){
				System.out.println("---- begin stmt calculation----");
				eval_stmt(stmt, model);
				System.out.println("---- end stmt calculation ----");
			}
		}catch(ParseException e){
			errHandler.error(e.getMessage());
		}catch(TokenMgrError | Exception e){
			errHandler.error(e.getMessage());
		}
	}
	
	public void eval_stmt(StmtNode stmt, ChanneledKripkeModel<String, SparseMatrix> model){
		CalcVisitor visitor = new  CalcVisitor(model);
		SparseMatrix res = stmt.accept(visitor);
		if(Objects.nonNull(res)){
			UJMPUtil.setAxisLabels(res, model.getW().toArray(new String[0]), true);
			System.out.println("resultant truth set= ");
			System.out.println(res);
			if(visitor.isUpdated()){ System.out.println("model updated!"); }
		}else{ throw new NullPointerException(); }		
	}
	
	public void save(String path){
		System.out.println("save -> " + path);
	}
	
	public void show(){
		if(Objects.nonNull(model)){ System.out.println(model); }
		else{ System.out.println("err: model not defined (use `load [FILE PATH]' to define model)"); }
	}	
		
	public void help(){
		System.out.println(
				id + " version " + version + "\n" + 
				"USAGE: command [ARGS]...\n" +
				"load [FILE PATH]\t load model file \n" + 
				"reload or make\t\t reload current loaded/saved file \n" + 
				"eval [FORMULA]\t\t evaluate given formula with current model \n" +
				"save [FILE PATH]\t save current model \n" +
				"show\t\t\t show current model \n" +
				"exit or quit\t\t quit this program \n" +
				"? or help\t\t show this command list \n"
				);
	}
	
	public void exit(){
		isContinue = false;
	}
		
	public void err(){
		System.out.println("err: missing argument (press `?' to show command list.)");
	}
	
	public void test(){
		try {
			model = getTestModel();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
			
	public ChanneledKripkeModel<String, SparseMatrix> getTestModel() throws Exception{
		//initialize
		String[] w = {"w0", "w1", "w2"};
		String[] g = {"a0", "a1"};
		int w_size = w.length;
		int g_size = g.length;
		SparseMatrix r_a0 = SparseMatrix.factory.zeros(w_size, w_size); 
		SparseMatrix r_a1 = SparseMatrix.factory.zeros(w_size, w_size);
		Map<String, SparseMatrix> r = new LinkedHashMap<String, SparseMatrix>();
		r.put("a0", r_a0);
		r.put("a1", r_a1);
		SparseMatrix c_w0 = SparseMatrix.factory.zeros(g_size, g_size);
		SparseMatrix c_w1 = SparseMatrix.factory.zeros(g_size, g_size);
		SparseMatrix c_w2 = SparseMatrix.factory.zeros(g_size, g_size);
		Map<String, SparseMatrix> c = new LinkedHashMap<String, SparseMatrix>();
		c.put("w0", c_w0);
		c.put("w1", c_w1);
		c.put("w2", c_w2);
		String[] p = {"p", "q"};
		int p_size = p.length;
		SparseMatrix v = SparseMatrix.factory.zeros(w_size, p_size); //row, col
		
		//put values
		UJMPUtil.setMatrixLabels(r_a0, w, w);
		r_a0.setAsInt(1, 0, 0);
		r_a0.setAsInt(1, 0, 1);
		r_a0.setAsInt(1, 0, 2);
		r_a0.setAsInt(1, 1, 1);
		r_a0.setAsInt(1, 2, 2);
		UJMPUtil.setMatrixLabels(r_a1, w, w);
		r_a1.setAsInt(1, 0, 0);
		r_a1.setAsInt(1, 0, 1);
		r_a1.setAsInt(1, 0, 2);
		r_a1.setAsInt(1, 1, 0);
		r_a1.setAsInt(1, 1, 1);
		r_a1.setAsInt(1, 1, 2);
		r_a1.setAsInt(1, 2, 0);
		r_a1.setAsInt(1, 2, 1);
		r_a1.setAsInt(1, 2, 2);
		
		UJMPUtil.setMatrixLabels(c_w0, g, g);
		c_w0.setAsInt(1, 0, 0);
		c_w0.setAsInt(1, 1, 0);
		c_w0.setAsInt(1, 1, 1);
		UJMPUtil.setMatrixLabels(c_w1, g, g);
		c_w1.setAsInt(1, 0, 0);
		c_w1.setAsInt(1, 1, 0);
		c_w1.setAsInt(1, 1, 1);
		UJMPUtil.setMatrixLabels(c_w2, g, g);
		c_w2.setAsInt(1, 0, 0);
		c_w2.setAsInt(1, 1, 1);
		
		UJMPUtil.setMatrixLabels(v, w, p);
		v.setAsInt(1, 1, 0);
		v.setAsInt(1, 2, 1);
		//v.setAsInt(1, 0, 1);
		v.setAsInt(1, 1, 1);

		ChanneledKripkeModel<String, SparseMatrix> model = new UJMPKripkeModel<String>("M_{Sample}", w, g, r, c, p, v);
		return model;
	}
	
	public String[] get_test_code(){
		return new String[] {
				"p", 							//atomic formula
				"\\neg p",						//negation
				"p \\lor  q",					//or
				"p \\land q",					//and
				"p \\to q", 					//implication
				"((p \\to q) \\to p) \\to p", 	//peirce's law
				"\\chl{a0}{a1}", 				//channel constant
				"[\\rel{a0}] p",				//atomic program
				"[\\rel{a0} \\cup \\rel{a1}] p", //choice
				"[\\rel{a0} \\; \\rel{a1}] p",	//composition
				"[\\? p] p", 					//test
				"[\\cmf{p}{a0}{a1}] p",			//cmf (semi-private ann.)
				"[\\iac{p}{H}] p",				//iac (group ann.)
		};  		
	}
}
