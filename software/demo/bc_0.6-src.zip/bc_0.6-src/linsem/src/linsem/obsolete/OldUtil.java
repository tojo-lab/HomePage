package linsem.obsolete;

import javax.swing.table.TableModel;

import org.ujmp.core.matrix.SparseMatrix;

public class OldUtil {

	
/*
	static String text_delimiter = ",";
	static String text_delimiter_regexp = "[" + text_delimiter +"\\s]+";
	static String relation_delimiter = "r";
	static String relation_delimiter_regexp = "[" + relation_delimiter + "\\s]+";
	
	//xml2models
	public static NodeList xml2models(Document doc){
		Element root   = doc.getDocumentElement();
		NodeList nodes = root.getChildNodes();
		return nodes;
	}
	
	//models2xml
	public static Element models2xml(Document doc, Element[] children){
		Element models = doc.createElement("models");
		for(Element child: children){
			models.appendChild(child);
		}
		return models;
	}
	
	public static Node xml2item(Element e, String tagName){
		NodeList list = e.getElementsByTagName(tagName);
		if(list.getLength() == 0)return null; 
		return list.item(0);		
	}
	
	public static Element item2xml(Document doc, String tagName, Set<Integer> set){
		Element e = doc.createElement(tagName);
		String text = concatinateIntegerSetAsString(set, text_delimiter);
		e.setTextContent(text);
		return e;
	}
	
	public static Node xml2worlds(Element e){
		return xml2item(e, "worlds");
	}

	public static Element worlds2xml(Document doc, Set<Integer> set){
		return item2xml(doc, "worlds", set);
	}
	
	public static Node xml2agents(Element e){
		return xml2item(e, "agents");
	}
	
	public static Element agents2xml(Document doc, Set<Integer> set){		
		return item2xml(doc, "agents", set);
	}
	
	public static NodeList xml2accessibilities(Element e){
		return e.getElementsByTagName("accessibilities");
	}
	
	public static NodeList xml2valuations(Element e){
		Element valuations = (Element)xml2item(e, "valuations");
		return valuations.getElementsByTagName("valuation");
	}
	
	public static Element valuations2xml(Document doc, Map<String, Set<Integer>> map){
		Element valuations = doc.createElement("valuations");
		Set set = null;
		Element valuation = null;
		for(String key: map.keySet()){
			valuation = doc.createElement("valuation");
			valuation.setAttribute("formula", key);
			set = map.get(key);
			if(set!=null){
				valuation.setTextContent(concatinateIntegerSetAsString(set, text_delimiter));
			}
			valuations.appendChild(valuation);
		}
		return valuations;
	}
	
	public static Set<Integer> splitStringAsIntegerSet(String text, String delimiter){
		String[] tokens = text.split(delimiter);
		Set<Integer> set = null;
		if(tokens != null && tokens.length > 0){
			set = new HashSet<Integer>();
			for(String token: tokens){
				
				set.add(Integer.parseInt(token));
			}
		}
		return set;
	}
	
	public static String concatinateIntegerSetAsString(Set<Integer> set, String delimiter){
		StringBuilder sb = new StringBuilder();
		for(Iterator<Integer> it = set.iterator(); it.hasNext();){
			sb.append(it.next());
			if(it.hasNext()){ sb.append(delimiter); }
		}
		return sb.toString(); 
	}
	
	//xml2channel
	//channel2xml
	
	//valuation2matrix
	public static SparseMatrix valuation2matrix(List<Integer> sorted_worlds, Map<String, Set<Integer>> valuations){		
		Set<String> formulas = valuations.keySet();
		int wsize = sorted_worlds.size();
		int fsize = formulas.size();
		
		SparseMatrix matrix = SparseMatrix.factory.zeros(fsize, wsize); //row, col
		//matrix.setRowLabel(row, label);
		//matrix.setColumnLabel(col, label);
		for(String formula: formulas){
			Set<Integer> set = valuations.get(formula);
			if(set != null){
				for(Integer world: set){
					//toarray蠢�隕�
				}
			}
		}
		
		return matrix;
	}
	
	//proposition2int
	public static int prop2int(String proposition, String delimiter){
		String[] tokens = proposition.split(delimiter);
		int res = -1;
		int i   = 0;
		if(tokens.length > 1){
			res = 1;
		}
		try{ res = Integer.parseInt(tokens[i]); }catch(NumberFormatException e){}
		return res;
	}
	
	public static SparseMatrix matrix2zeromatrix(SparseMatrix matrix){
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		SparseMatrix zero_matrix = SparseMatrix.factory.zeros(row, col);
		
		return zero_matrix;
	}
	
	public static SparseMatrix zeromatrix(long row, long col){
		return SparseMatrix.factory.zeros(row, col);
	}
	
	//matrix calculation ----
	
	public static SparseMatrix matrix2sparse(Matrix matrix){
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		
		SparseMatrix smatrix = SparseMatrix.factory.zeros(row, col);
		for(int i = 0; i < row; i++){
			for(int j = 0; j < col; j++){
				smatrix.setAsInt(matrix.getAsInt(i, j), i,j);
			}
		}
		return smatrix;
	}
	
	public static SparseMatrix getColumnVector(SparseMatrix matrix, long i){
		long row = matrix.getRowCount();
		return matrix2sparse(matrix.subMatrix(Calculation.LINK, 0, i, row-1, i));
	}
	
	public static SparseMatrix complement(SparseMatrix matrix){
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		int value = 0;
		SparseMatrix matrix_c = SparseMatrix.factory.zeros(row, col);
		
		for(int i = 0; i < row; i++){
			for(int j = 0; j < col; j++){
				value = matrix.getAsInt(i,j); 
				if(value > 0){
					matrix_c.setAsInt(0, i, j);
				}else{
					matrix_c.setAsInt(1, i, j);
				}
			}
		}
		return matrix_c;
	}
	
	public static SparseMatrix test_complement(SparseMatrix square_matrix){
		long size = square_matrix.getRowCount();
		int value = 0;
		SparseMatrix matrix_c = SparseMatrix.factory.zeros(size, size);
		
		for(int i = 0; i < size; i++){
			value = square_matrix.getAsInt(i,i);
			if(value > 0){
				matrix_c.setAsInt(0, i, i);
			}else{
				matrix_c.setAsInt(1, i, i);
			}
		}
		return matrix_c;
	}
	
	public static SparseMatrix mbelief_of(SparseMatrix mat_R_a, SparseMatrix mat_V_p){ 
		SparseMatrix mat_B_a_p = complement((SparseMatrix)mat_R_a.mtimes(complement(mat_V_p)));
		return mat_B_a_p;
	}
	
	public static SparseMatrix arr2vector(Integer[] arr, int size, boolean isColumn){
		SparseMatrix matrix;
		
		if(isColumn) matrix = SparseMatrix.factory.zeros(size, 1);
		else matrix = SparseMatrix.factory.zeros(1, size);
		
		for(int i = 0; i < arr.length; i++){
			int value = arr[i]; //i-th column/row
			if(isColumn) matrix.setAsInt(1, value-1, 0); //value, row, col
			else matrix.setAsInt(1, 0, value-1);
			
		}
		return matrix;
	}
	
	public static SparseMatrix test(SparseMatrix col_vector){
		long size = col_vector.getRowCount();
		SparseMatrix matrix_diagonalized = SparseMatrix.factory.zeros(size, size);
		
		Iterable<long[]> coordinates = col_vector.availableCoordinates(); //蠎ｧ讓�
		for(long[] coordinate: coordinates){
			long row = coordinate[0];
			long col = coordinate[1];
			matrix_diagonalized.setAsInt(1, row, row);
		}
		return matrix_diagonalized;
	}
	
	public static SparseMatrix semi_relation_update(SparseMatrix X, SparseMatrix Y, SparseMatrix mat_R_b, SparseMatrix Z){
		System.out.println("/*-------");
		System.out.println("X=");
		System.out.println(X);
		System.out.println("-------");
		System.out.println("Y=");
		System.out.println(Y);
		System.out.println("-------");
		System.out.println("R_b^M=");
		System.out.println(mat_R_b);
		System.out.println("-------");
		System.out.println("Z=");
		System.out.println(Z);
		System.out.println("=======");
		SparseMatrix XY = matrix2boolmatrix((SparseMatrix)X.mtimes(Y));
		SparseMatrix XY_mat_R_b = matrix2boolmatrix((SparseMatrix)XY.mtimes(mat_R_b));
		SparseMatrix mat_R_b_prime_succ = matrix2boolmatrix((SparseMatrix)XY_mat_R_b.mtimes(Z));
		SparseMatrix mat_R_b_prime_fail = matrix2boolmatrix((SparseMatrix)test_complement(XY).mtimes(mat_R_b));
		SparseMatrix mat_R_b_prime      = matrix2boolmatrix((SparseMatrix)mat_R_b_prime_succ.plus(mat_R_b_prime_fail));
		
		System.out.println("XYR_b^MZ");
		System.out.println(mat_R_b_prime_succ);
		System.out.println("-------");
		System.out.println("\\overline{XY}R_b^M=");
		System.out.println(mat_R_b_prime_fail);
		System.out.println("--->");
		System.out.println("R'_b^M=");
		System.out.println(mat_R_b_prime);*/
		//System.out.println("-------*/");
		//System.out.println("updated?=" + !mat_R_b.equals(mat_R_b_prime));
		
	/*
		return mat_R_b_prime;
	}
	
	
	public static boolean isT(SparseMatrix R){ //Reflexive
		long size = R.getRowCount();
		SparseMatrix E = (SparseMatrix) SparseMatrix.factory.eye(size, size);
		SparseMatrix R_plus_E = Converter.matrix2boolmatrix((SparseMatrix) R.plus(E));
		return R.equals(R_plus_E);
	}
	
	public static boolean isB(SparseMatrix R){ //Symmetric
		SparseMatrix t_R = (SparseMatrix) R.transpose();
		return R.equals(t_R);		
	}
	
	public static boolean is4(SparseMatrix R){ //Transitive
		SparseMatrix R_2 = Converter.matrix2boolmatrix((SparseMatrix) R.mtimes(R));
		SparseMatrix R_2_plus_R = Converter.matrix2boolmatrix((SparseMatrix) R_2.plus(R));
		return R.equals(R_2_plus_R);		
	}
	
	public static boolean isD(SparseMatrix R){ //Serial
		Iterable<long[]> coordinates = R.availableCoordinates();
		long row = R.getRowCount();
		
		outside:
		for(int i = 0; i < row; i++){
			for(long[] coordinate: coordinates){
				if(i == (int)coordinate[0]){ //row
					continue outside;
				}
			}
			return false;
		}
		return true;		
	}
	
	public static boolean is5(SparseMatrix R){ //Euclidian //TODO:
		Iterable<long[]> coordinates0 = R.availableCoordinates();
		Iterable<long[]> coordinates1 = R.availableCoordinates();
		
		long i = -1;
		long j = -1;
		long k = -1;
		System.out.println("--- is it 5? ---");
		for(long[] coordinate0: coordinates0){
			for(long[] coordinate1: coordinates1){
				if(coordinate0[0] == coordinate1[0]){//for any (i,j) and (i,k) of i
					i = coordinate0[0];
					j = coordinate0[1];
					k = coordinate1[1];
					if((R.getAsInt(i,j) > 0) && (R.getAsInt(i,k) > 0)){ // (i,j) and (i,k) are 1
						System.out.println("checking euclidian for (" + i +"," + j + ") and (" + i + "," + k + ")");
						if(R.getAsInt(k,j) < 1 || R.getAsInt(j,k) < 1){ //not euclidian 
							System.out.println("failed: j=" + j + ", k=" + k);
							System.out.println("---> this is not 5.");
							return false;
						}else{// (j,k) and (k,j) elements are all 1's
							; //do nothing.
						} 
					}
				}				
			}
		}
		System.out.println("---> this is 5.");
		return true;		
	}

*/
	
// -----------------------	

/*	
	public static SparseMatrix asBooleanMatrix(SparseMatrix matrix){
		Iterable<long[]> coordinates = matrix.availableCoordinates();
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		
		for(long[] coordinate: coordinates){
			row = (int)coordinate[0];
			col = (int)coordinate[1];
			int value = matrix.getAsInt(row, col);
			if(value > 0) matrix.setAsInt(1, row, col);
			//System.out.println(row + ", " + col + ", " + matrix.getAsInt(row, col));
		}		
		return matrix;
	}
		
	public static void setValueByIDs(SparseMatrix m, String row_id, String col_id, int value) throws NumberFormatException{
		long row = m.getRowForLabel(row_id);
		long col = m.getColumnForLabel(col_id);
		if(row == -1 || col == -1 || value > 1 || value < 0) throw new NumberFormatException(); 
		m.setAsInt(value, row, col);
	}
*/
	
// -----------------------	

	/*	
	//xml2models
	public static NodeList xml2models(Document doc){
		Element root   = doc.getDocumentElement();
		NodeList nodes = root.getChildNodes();
		return nodes;
	}
	
	//models2xml
	public static Element models2xml(Document doc, Element[] children){
		Element models = doc.createElement("models");
		for(Element child: children){
			models.appendChild(child);
		}
		return models;
	}
	
	public static Node xml2item(Element e, String tagName){
		NodeList list = e.getElementsByTagName(tagName);
		if(list.getLength() == 0)return null; 
		return list.item(0);		
	}

	
	public static Element item2xml(Document doc, String tagName, Set<Integer> set){
		Element e = doc.createElement(tagName);
		String text = concatinateIntegerSetAsString(set, text_delimiter);
		e.setTextContent(text);
		return e;
	}

	public static Node xml2worlds(Element e){
		return xml2item(e, "worlds");
	}

	public static Element worlds2xml(Document doc, Set<Integer> set){
		return item2xml(doc, "worlds", set);
	}
	
	public static Node xml2agents(Element e){
		return xml2item(e, "agents");
	}
	
	public static Element agents2xml(Document doc, Set<Integer> set){		
		return item2xml(doc, "agents", set);
	}
	
	public static NodeList xml2accessibilities(Element e){
		return e.getElementsByTagName("accessibilities");
	}
*/
/*	
	public static Element[] accessibilities2xml(Document doc, Map<Integer, Set<Pair<Integer, Integer>>> map){
		List<Element> list = new ArrayList<Element>();
		Element accessibilities = null;
		Set set = null;
		for(Integer key: map.keySet()){ 
			accessibilities = doc.createElement("accessibilities");
			accessibilities.setAttribute("agent", String.valueOf(key));
			set = map.get(key);
			if(set!=null){
				accessibilities.setTextContent(concatinatePairSetAsString(set, text_delimiter, relation_delimiter));
			}
			list.add(accessibilities);
		}
		
		return list.toArray(new Element[0]);
	}
	
	public static NodeList xml2valuations(Element e){
		Element valuations = (Element)xml2item(e, "valuations");
		return valuations.getElementsByTagName("valuation");
	}
	
	public static Element valuations2xml(Document doc, Map<String, Set<Integer>> map){
		Element valuations = doc.createElement("valuations");
		Set set = null;
		Element valuation = null;
		for(String key: map.keySet()){
			valuation = doc.createElement("valuation");
			valuation.setAttribute("formula", key);
			set = map.get(key);
			if(set!=null){
				valuation.setTextContent(concatinateIntegerSetAsString(set, text_delimiter));
			}
			valuations.appendChild(valuation);
		}
		return valuations;
	}
	
	public static Set<Integer> splitStringAsIntegerSet(String text, String delimiter){
		String[] tokens = text.split(delimiter);
		Set<Integer> set = null;
		if(tokens != null && tokens.length > 0){
			set = new HashSet<Integer>();
			for(String token: tokens){
				
				set.add(Integer.parseInt(token));
			}
		}
		return set;
	}
	
	public static String concatinateIntegerSetAsString(Set<Integer> set, String delimiter){
		StringBuilder sb = new StringBuilder();
		for(Iterator<Integer> it = set.iterator(); it.hasNext();){
			sb.append(it.next());
			if(it.hasNext()){ sb.append(delimiter); }
		}
		return sb.toString(); 
	}
	
	public static Pair<Integer,Integer> splitStringAsPair(String text, String delimiter){
		String[] tokens = text.split(delimiter);
		Pair<Integer,Integer> pair = null;
		if(tokens != null && tokens.length == 2){
			int left  = Integer.parseInt(tokens[0]);
			int right = Integer.parseInt(tokens[1]);
			pair = new Pair<Integer,Integer>(left, right);
		}
		return pair;		
	}
	
	public static String concatinatePairAsString(Pair<Integer,Integer> pair, String delimiter){
		StringBuilder sb = new StringBuilder();
		sb.append(String.valueOf(pair.getLeft()));
		sb.append(String.valueOf(delimiter));
		sb.append(String.valueOf(pair.getRight()));
		return sb.toString();
	}
	
	public static Set<Pair<Integer,Integer>> splitStringAsPairSet(String text, String text_delimiter, String relation_delimiter){
		String[] tokens = text.split(text_delimiter);
		Set<Pair<Integer,Integer>> set = null;
		if(tokens != null && tokens.length > 0){
			set = new HashSet<Pair<Integer,Integer>>();
			for(String token: tokens){				
				set.add(splitStringAsPair(token, relation_delimiter));
			}			
		}
		return set;		
	}
	
	public static String concatinatePairSetAsString(Set<Pair<Integer,Integer>> set, String text_delimiter, String relation_delimiter){
		StringBuilder sb = new StringBuilder();
		for(Iterator<Pair<Integer,Integer>> it = set.iterator(); it.hasNext();){
			String pair = concatinatePairAsString(it.next(), relation_delimiter);
			sb.append(pair);
			if(it.hasNext())sb.append(text_delimiter);
		}
		return sb.toString();
	}
	
	public static Map splitNodesAsMap(NodeList list, boolean isAccessibilities){
		Map map                	= null;
		NamedNodeMap named_map 	= null;
		Object key 				= null;
		Set value  				= null;
		String text				= null;
		if(list!= null && list.getLength() > 0){
			map = new HashMap();
			for(int i = 0; i < list.getLength(); i++){
				Node node   = list.item(i);
				text = node.getTextContent(); 
				named_map = node.getAttributes();				
				if(isAccessibilities){ //accessibilities
					key    = named_map.getNamedItem("agent").getTextContent();
					key    = Integer.parseInt(key.toString());
					value  = splitStringAsPairSet(text, text_delimiter_regexp, relation_delimiter_regexp);
				}else{ //valuations
					key = named_map.getNamedItem("formula").getTextContent();
					value  = splitStringAsIntegerSet(text, text_delimiter_regexp);
				}
				map.put(key, value);
			}			
		}
		return map;
	}
	
	//xml2kripke
	public static KripkeModel xml2kripke(Element e){
		Node worlds_node = xml2worlds(e);
		Node agents_node = xml2agents(e);
		NodeList accessibility_node_list = xml2accessibilities(e);
		NodeList valuation_node_list = xml2valuations(e);
		
		//generate kripke model
		Set<Integer> worlds = splitStringAsIntegerSet(worlds_node.getTextContent(), text_delimiter_regexp);
		Set<Integer> agents = splitStringAsIntegerSet(agents_node.getTextContent(), text_delimiter_regexp);
		Map<Integer, Set<Pair<Integer,Integer>>> accessibilities = splitNodesAsMap(accessibility_node_list, true);
		Map<String, Set<Integer>> valuations = splitNodesAsMap(valuation_node_list, false);
		
		//generate 
		return new KripkeModel<Integer, Integer, String>(worlds, agents, accessibilities, valuations);
	}
	
	//kripke2xml 
	public static Element kripke2xml(Document doc, KripkeModel kripke_model){ 
		//construct xml document
		Element worlds = worlds2xml(doc, kripke_model.getWorlds());
		Element agents = agents2xml(doc, kripke_model.getAgents());
		Element[] accessibilities = accessibilities2xml(doc, kripke_model.getAccessibilities());
		Element valuations = valuations2xml(doc, kripke_model.getValuations());
		
		Element model  = doc.createElement("model");
		model.setAttribute("type", "kripke");
		model.setAttribute("id", String.valueOf(kripke_model.getId()));
		model.appendChild(worlds);
		model.appendChild(agents);
		for(Element a: accessibilities)
			model.appendChild(a);
		model.appendChild(valuations);
		return model;
	}
	
	//xml2channel
	//channel2xml
	
	//valuation2matrix
	public static SparseMatrix valuation2matrix(List<Integer> sorted_worlds, Map<String, Set<Integer>> valuations){		
		Set<String> formulas = valuations.keySet();
		int wsize = sorted_worlds.size();
		int fsize = formulas.size();
		
		SparseMatrix matrix = SparseMatrix.factory.zeros(fsize, wsize); //row, col
		//matrix.setRowLabel(row, label);
		//matrix.setColumnLabel(col, label);
		for(String formula: formulas){
			Set<Integer> set = valuations.get(formula);
			if(set != null){
				for(Integer world: set){
					//toarray蠢�隕�
				}
			}
		}
		
		return matrix;
	}
	
	//matrix2valuation
	//access2matrix
	public static SparseMatrix[] accessibilities2matrix(Map<Integer, Set<Pair<Integer,Integer>>> accessibilities){
		Set<Integer> agents = accessibilities.keySet();
		int wsize = 0;
		
		List<SparseMatrix> list = new ArrayList<SparseMatrix>();
		for(int agent: agents){
			//
			SparseMatrix matrix = SparseMatrix.factory.zeros(wsize, wsize); //row, col
		}
		
		return list.toArray(new SparseMatrix[0]);
	}
	
	//matrix2access
	
	
	
	///for swing
	//table2matrix
	public static SparseMatrix table2matrix (ExtendedTableModelEx model) {
		int row = model.getRowCount();
		int col = model.getColumnCount();
		SparseMatrix matrix = SparseMatrix.factory.zeros(row, col); //row, col
		
		for(int i = 0; i < row; i++){ 
			for(int j = 0; j < col; j++){
				//System.out.println(i + ", " + j + ", " + model.getValueAt(i, j));
				try{
					String data = model.getValueAt(i, j).toString();
					//if(data.isEmpty())data = "0";
					if(!data.isEmpty()){
						int value = Integer.parseInt(data);
						//System.out.println(value);
						matrix.setAsInt(value, i, j); //(val, row, col)						
					}
				}catch(NumberFormatException e){ e.printStackTrace(); return null; }
			}
		}
		return matrix;
	}
	
	//matrix2table	
	public static void matrix2table(SparseMatrix matrix, ExtendedTableModelEx model){
		Iterable<long[]> coordinates = matrix.availableCoordinates();
		int row = model.getRowCount();
		int col = model.getColumnCount();
		
		for(int i = 0; i < row; i++){
			for(int j = 0; j < col; j++){
				model.setValueAt(0, i, j);
			}
		}
		
		for(long[] coordinate: coordinates){
			row = (int)coordinate[0];
			col = (int)coordinate[1];
			int value = matrix.getAsInt(row, col);
			//if(!isLinearAlgebra && (value != 0)){ value = 1; }
			model.setValueAt(value, row, col);
			//System.out.println(row + ", " + col + ", " + matrix.getAsInt(row, col));
		}
	}
	
	//pprint(matrix)
	
	//kripke2tex
	public static String kripke2tex(KripkeModel kripke_model){
		return "";
	}
*/

	
	/*
	//proposition2int
	public static int prop2int(String proposition, String delimiter){
		String[] tokens = proposition.split(delimiter);
		int res = -1;
		int i   = 0;
		if(tokens.length > 1){
			res = 1;
		}
		try{ res = Integer.parseInt(tokens[i]); }catch(NumberFormatException e){}
		return res;
	}*/
	
	/*	
	public static SparseMatrix matrix2zeromatrix(SparseMatrix matrix){
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		SparseMatrix zero_matrix = SparseMatrix.factory.zeros(row, col);
		
		return zero_matrix;
	}
	
	public static SparseMatrix zeromatrix(long row, long col){
		return SparseMatrix.factory.zeros(row, col);
	}
	
	//matrix calculation ----
		
	public static SparseMatrix complement(SparseMatrix matrix){
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		int value = 0;
		SparseMatrix matrix_c = SparseMatrix.factory.zeros(row, col);
		
		for(int i = 0; i < row; i++){
			for(int j = 0; j < col; j++){
				value = matrix.getAsInt(i,j); 
				if(value > 0){
					matrix_c.setAsInt(0, i, j);
				}else{
					matrix_c.setAsInt(1, i, j);
				}
			}
		}
		return matrix_c;
	}
		
	public static SparseMatrix mbelief_of(SparseMatrix mat_R_a, SparseMatrix mat_V_p){ 
		SparseMatrix mat_B_a_p = complement((SparseMatrix)mat_R_a.mtimes(complement(mat_V_p)));
		return mat_B_a_p;
	}
	
	public static SparseMatrix arr2vector(Integer[] arr, int size, boolean isColumn){
		SparseMatrix matrix;
		
		if(isColumn) matrix = SparseMatrix.factory.zeros(size, 1);
		else matrix = SparseMatrix.factory.zeros(1, size);
		
		for(int i = 0; i < arr.length; i++){
			int value = arr[i]; //i-th column/row
			if(isColumn) matrix.setAsInt(1, value-1, 0); //value, row, col
			else matrix.setAsInt(1, 0, value-1);
			
		}
		return matrix;
	}*/
	
	/*
	public static SparseMatrix test(SparseMatrix col_vector){
		long size = col_vector.getRowCount();
		SparseMatrix matrix_diagonalized = SparseMatrix.factory.zeros(size, size);
		
		Iterable<long[]> coordinates = col_vector.availableCoordinates(); //蠎ｧ讓�
		for(long[] coordinate: coordinates){
			long row = coordinate[0];
			long col = coordinate[1];
			matrix_diagonalized.setAsInt(1, row, row);
		}
		return matrix_diagonalized;
	}*/
	
	/*
	 * TODO: this will be used as a part of search functions
	public static boolean is5(SparseMatrix R){
		Iterable<long[]> coordinates0 = R.availableCoordinates();
		Iterable<long[]> coordinates1 = R.availableCoordinates();
		
		long i = -1;
		long j = -1;
		long k = -1;
		//System.out.println("--- is it 5? ---");
		for(long[] coordinate0: coordinates0){
			for(long[] coordinate1: coordinates1){
				if(coordinate0[0] == coordinate1[0]){//for any (i,j) and (i,k) of i
					i = coordinate0[0];
					j = coordinate0[1];
					k = coordinate1[1];
					if((R.getAsInt(i,j) > 0) && (R.getAsInt(i,k) > 0)){ // (i,j) and (i,k) are 1
						//System.out.println("checking euclidian for (" + i +"," + j + ") and (" + i + "," + k + ")");
						if(R.getAsInt(k,j) < 1 || R.getAsInt(j,k) < 1){ //not euclidian 
							//System.out.println("failed: j=" + j + ", k=" + k);
							//System.out.println("---> this is not 5.");
							return false;
						}else{// (j,k) and (k,j) elements are all 1's
							; //do nothing.
						} 
					}
				}				
			}
		}
		//System.out.println("---> this is 5.");
		return true;
	}
	*/ 
	 
	/*
	public static boolean isD(SparseMatrix R){ //Serial
		Iterable<long[]> coordinates = R.availableCoordinates();
		long row = R.getRowCount();
		
		outside:
		for(int i = 0; i < row; i++){
			for(long[] coordinate: coordinates){
				if(i == (int)coordinate[0]){ //row
					continue outside;
				}
			}
			return false;
		}
		return true;
	}
	*/
	
	/*
	class ComboBoxChangeActionG implements ActionListener{
		protected JComboBox comboBox;
		protected Map<Integer, ExtendedTableModelEx> map;
		protected ExtendedTableModelEx model = null; //current
		protected TableModelListener table_model_listener = null;

		public ComboBoxChangeActionG(JComboBox comboBox, Map<Integer, ExtendedTableModelEx> map){
			this.comboBox = comboBox;
			this.map = map;
			graph_update();
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			graph_update();
		}
		
		public void graph_update(){
			if(graph_frame != null){
				//model update
				int key = (int)comboBox.getSelectedItem();
				ExtendedTableModelEx newModel = map.get(key);
				if(model != null && table_model_listener != null){//remove old listener
					model.removeTableModelListener(table_model_listener); 
				}
				model = newModel;
				table_model_listener = new TableChangeActionG(model);
				model.addTableModelListener(table_model_listener);

				//rewrite graph
				int row = newModel.getRowCount();
				int col = newModel.getColumnCount();
				graph_frame.postNodeChanges(col);
				for(int i = 0; i < col; i++){
					for(int j = 0; j < row; j++){
						try{
							String data = model.getValueAt(j, i).toString();
							if(!data.isEmpty()){
								int value = Integer.parseInt(data);
								if(value < 1){ graph_frame.postDelEdge(i, j); }
							}
						}catch(NumberFormatException e1){ e1.printStackTrace();}
					}
				}
			}			
		}
	}*/
	
	/*
	class TableChangeActionG implements TableModelListener{

		protected ExtendedTableModelEx model = null; //current
		
		public TableChangeActionG(ExtendedTableModelEx model){
			this.model = model;
		}
		
		@Override
		public void tableChanged(TableModelEvent e) {
			int col = e.getColumn();
			int first_row = e.getFirstRow();
			int last_row  = e.getLastRow();
			//System.out.println(first_row + "->" + last_row);
			for(int row = first_row; row <= last_row; row++){
				try{
					String data = model.getValueAt(row, col).toString();
					//if(data.isEmpty())data = "0";
					if(!data.isEmpty()){
						int value = Integer.parseInt(data);
						if(graph_frame != null){
							if(0 < value){graph_frame.postAddEdge(col, row);}
							else{graph_frame.postDelEdge(col, row);}					
						}
					}
				}catch(NumberFormatException e1){ e1.printStackTrace();}
			}
		}
	}*/

	/*
	public String transform_model_simple(){
		StringBuilder sb = new StringBuilder();
		int card_W = (int) editor_panel.world_spinner.getValue();
		int card_G = (int) editor_panel.agent_spinner.getValue();
		int card_P = (int) editor_panel.proposition_spinner.getValue();
		
		sb.append("W " + card_W + "\n");
		sb.append("G " + card_G + "\n");
		for(int a = 0; a < card_G; a++){
			sb.append("R " + a + "\n");

			MatrixTableModel relation_a_model  	= editor_panel.relation_map.get(a+1);
			SparseMatrix R_a = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(relation_a_model));
			sb.append(R_a.toIntMatrix() + "\n");
		}
		
		for(int w = 0; w < card_W; w++){
			sb.append("C " + w + "\n");
			
			MatrixTableModel channel_model = (MatrixTableModel) editor_panel.channel_map.get(w+1);			
			SparseMatrix c_w = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(channel_model));
			sb.append(c_w.toIntMatrix().toString() + "\n");
		}
		
		sb.append("P " + card_P + "\n");
		MatrixTableModel valuation_model = (MatrixTableModel) editor_panel.valuation_table.getModel();
		SparseMatrix V = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(valuation_model));
		sb.append(V.toIntMatrix() + "\n");
		
		System.out.println(sb.toString());
		return sb.toString();
	}*/

	/*
	public JFrame getGraphFrame(){
		if(graph_frame == null){
			graph_frame = new GraphFrame();
			graph_frame.setVisible(true);
			addListenersG();
			//graph_frame.postNodeChanges(num); 
		}
		return graph_frame;
	}	
	
	public void addListenersG(){
		model_panel.relation_comboBox.addActionListener(new ComboBoxChangeActionG(model_panel.relation_comboBox, model_panel.relation_map));
	}*/

	/*
	class TableSizeChangeAction extends WorkerRunAction{
		
		protected JSpinner spinner = null;
		protected int value = -1;
		protected MatrixTable table = null;
		protected MatrixTableModel model = null;
		protected Map<Integer, MatrixTableModel> map = null;
		protected boolean isColumn = false;
		protected String header = "";
		
		//Note: Valuation table
		public TableSizeChangeAction(JComponent parent, String caption, JSpinner spinner, MatrixTable table, MatrixTableModel model, String header, boolean isColumn){
			super(parent, caption);
			this.spinner 	= spinner;
			this.table 		= table;
			this.model   	= model;
			this.value 		= (Integer)spinner.getValue();
			this.header		= header;
			this.isColumn 	= isColumn;
		}
		
		//Note: Relation table and Channel table 
		public TableSizeChangeAction(JComponent parent, String caption, JSpinner spinner, MatrixTable table, Map<Integer, MatrixTableModel> map, String header, boolean isColumn){
			super(parent, caption);
			this.spinner 	= spinner;
			this.table 		= table;
			this.map   		= map;
			this.value 		= (Integer)spinner.getValue();
			this.header		= header;
			this.isColumn 	= isColumn;
		}

		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new TableSizeChangeWorker(progress_panel, parent, true, spinner, table, model, map, value, header, isColumn);
		}	
		
		@Override
		public void stateChanged(ChangeEvent e) { 
			/*
			int next_value = (Integer)spinner.getValue();
			int diff = Math.abs(value-next_value);
			
			if(diff < multi_thread_threshold){ doActionByEDT(); } //single thread execution
			else{ doAction(); } //multi-thread execution*/
		/*	doActionByEDT();
		}
		
		protected void doActionByEDT(){ //for single thread execution (by Event dispatch thread of Swing)
			worker = new TableSizeChangeWorker(null, parent, false, spinner, table, model, map, value, header, isColumn);
			TableSizeChangeWorker worker_local = (TableSizeChangeWorker)worker;
			worker_local.doTask();
			value = worker_local.value;			
		}
	}*/

	
	/*
	class TableSizeChangeWorker extends SimpleWorker{
		protected JSpinner spinner = null;
		protected int value = -1;
		protected MatrixTable table = null;
		protected MatrixTableModel model = null; //Note: Valuation table
		protected Map<Integer, MatrixTableModel> map = null; //Note: Relation table and Channel table
		protected boolean isColumn = false;
		protected String header = "";
		protected final boolean isMultiThreaded;

		public TableSizeChangeWorker(JComponent parent, JComponent root, boolean isMultiThreaded, JSpinner spinner, MatrixTable table, MatrixTableModel model, Map<Integer, MatrixTableModel> map, int value, String header, boolean isColumn) {
			super(parent, root);
			this.isMultiThreaded = isMultiThreaded;
			this.spinner = spinner;
			this.table = table;
			this.model = model;
			this.map = map;
			this.value = value;
			this.header = header;
			this.isColumn = isColumn;
		}
				
		@Override
		public void doTask(){
			/*
			if(isMultiThreaded){ update_multi(); }
			else{ update_single(); }
			*/
			/*
			SwingUtilities.invokeLater(new Runnable(){

				@Override
				public void run() {
					update_single();
				}
				
			});*/
	/*
			update_single();
		}
		
		protected synchronized void update_multi(){// for multi-thread execution
			//Generate new table model
			int next_value = (Integer)spinner.getValue();
			value = next_value;
			renewTableModels(value, isColumn);
		}
		
		protected void renewTableModels(int next_value, boolean isColumn){
			if(Objects.nonNull(map)){ //Note: Relation table and Channel table
				Set<Integer> keys = map.keySet();
				initTask(keys.size());
				boolean isFirst = true;
				for(final Integer key: keys){
					MatrixTableModel old_model = map.get(key);
					final MatrixTableModel new_model = renewTableModel(next_value, old_model, isColumn);
					copyTableModel(new_model, old_model);
					SwingUtilities.invokeLater(new Runnable(){
						@Override
						public void run() {
							map.put(key, new_model);
							
						}
					});
					progress(); 
				}				
			}else{ //Note: Valuation table
				initTask(1); 
				MatrixTableModel old_model = model;
				final MatrixTableModel new_model = renewTableModel(next_value, old_model, isColumn);
				copyTableModel(new_model, old_model);
				
				SwingUtilities.invokeLater(new Runnable(){
					@Override
					public void run() {
						table.setModel(new_model);
					}
				});
				progress();
			}		
		}
		
		
		protected MatrixTableModel renewTableModel(int next_value, MatrixTableModel old_model, boolean isColumn){
			int row_size = 0;
			int col_size = 0;
			String row_header = old_model.getRowHeader();
			String col_header = old_model.getColumnHeader();
			if(isColumn){
				row_size = old_model.getRowCount();
				col_size = next_value;			
			}else{
				row_size = next_value;
				col_size = old_model.getColumnCount();
			}
			return install_table_model(row_header, col_header, row_size, col_size, table, false);
		}
		
		protected void copyTableModel(MatrixTableModel new_model, MatrixTableModel old_model){
			//copy data
			int row_size = new_model.getRowCount();
			int col_size = new_model.getColumnCount();
			
			int old_row_size = old_model.getRowCount();
			int old_col_size = old_model.getColumnCount();
			int data = 0;
			for(int i = 0; i < row_size; i++){
				if(i < old_row_size){
					for(int j = 0; j < col_size; j++){
						data = 0;
						if(j < old_col_size){ data = (int)old_model.getValueAt(i, j); 
							new_model.setValueAt(data, i, j);
						} else{ break; }
					}					
				}else{ break; }
			}
		}
		
		protected synchronized void update_single(){ //for single thread execution
			int next_value = (Integer)spinner.getValue();
			if(next_value < value){
				int diff = value-next_value;
				if(map != null){ //Note: Relation table and Channel table
					Set<Integer> keys = map.keySet();
					initTask(keys.size());
					for(Integer key: keys){ removeLine(map.get(key), diff); progress(); }
				}else{initTask(1); removeLine(model, diff); progress(); } //Note: Valuation table
			}else if(value < next_value){//Note: Relation table and Channel table
				int diff = next_value-value;
				if(map != null){ 
					Set<Integer> keys = map.keySet();
					initTask(keys.size());
					for(Integer key: keys){ addLine(map.get(key), diff); progress(); }
				}else{initTask(1); addLine(model, diff); progress(); } //Note: Valuation table
			}			

			value = next_value;			
		}
		
		protected synchronized void removeLine(MatrixTableModel model, int diff){
			if(isColumn){ 
				if(model.getColumnCount() > diff){
						//this does not work -> new Timer(DELAY, new CellDeleteAction(table, table.convertColumnIndexToView(model.getColumnCount() -1), isColumn)).start();
						model.removeColumns(diff); 
					}
				}else{ 
					if(model.getRowCount() > diff){
						//this does not work -> new Timer(DELAY, new CellDeleteAction(table, table.convertRowIndexToView(model.getRowCount()-1), isColumn)).start();
						model.removeRows(diff); 
					}
			}
		}
		
		protected synchronized void addLine(final MatrixTableModel model, int diff){ 
			if(isColumn){ 
				model.addColumns(header, diff);
				new Timer(DELAY, new CellAddAction(table, table.convertColumnIndexToView(model.getColumnCount() -1), isColumn)).start();
			} else{ 
				model.addRows(header, diff);
				new Timer(DELAY, new CellAddAction(table, table.convertRowIndexToView(model.getRowCount() -1), isColumn)).start();
			}
		}
	}*/

}
