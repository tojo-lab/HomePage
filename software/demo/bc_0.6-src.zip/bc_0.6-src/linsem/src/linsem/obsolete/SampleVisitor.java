package linsem.obsolete;

import java.util.Map;

import linsem.ast.ASTVisitor;
import linsem.ast.AndFormulaNode;
import linsem.ast.AtomicFormulaNode;
import linsem.ast.AtomicProgramNode;
import linsem.ast.ChlFormulaNode;
import linsem.ast.ChoiceProgramNode;
import linsem.ast.CmpProgramNode;
import linsem.ast.ExprNode;
import linsem.ast.ExprStmtNode;
import linsem.ast.ImpFormulaNode;
import linsem.ast.LiteralNode;
import linsem.ast.MultiModalFormulaNode;
import linsem.ast.NegFormulaNode;
import linsem.ast.OrFormulaNode;
import linsem.ast.TestProgramNode;

public class SampleVisitor implements ASTVisitor<Boolean, Boolean, Boolean>{
	
	protected Map<String, Boolean> map;
	
	public SampleVisitor(Map<String, Boolean> map){
		super();
		this.map = map;
	}

	@Override
	public Boolean visit(ExprStmtNode node) {
		ExprNode expr = node.expr();
		return expr.accept(this);
	}

	/*
	@Override
	public Boolean visit(TernaryOpNode node) {
		return false;
	}

	@Override
	public Boolean visit(BinaryOpNode node) {
		return false;
	}

	@Override
	public Boolean visit(UnaryOpNode node) {
		return false;
	}

	 */

	@Override
	public Boolean visit(ImpFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.accept(this);
		boolean bright= right.accept(this);
		return (!bleft || bright);
	}

	@Override
	public Boolean visit(OrFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.accept(this);
		boolean bright= right.accept(this);
		return (bleft || bright);
	}

	@Override
	public Boolean visit(AndFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.accept(this);
		boolean bright= right.accept(this);
		return (bleft && bright);
	}

	
	@Override
	public Boolean visit(IacFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.accept(this);
		boolean bright= right.accept(this);
		return true; //TODO:
	}

	@Override
	public Boolean visit(CmfFormulaNode node) {
		ExprNode left = node.left();
		ExprNode l_center = node.l_center();
		ExprNode r_center = node.r_center();
		ExprNode right = node.right();
		boolean bleft = left.accept(this);
		boolean blcenter = l_center.accept(this);
		boolean brcenter = r_center.accept(this);
		boolean bright= right.accept(this);
		return true; //TODO:
	}
	/*
	@Override
	public Boolean visit(BelFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.accept(this);
		boolean bright= right.accept(this);
		return true; //TODO:
	}*/

	@Override
	public Boolean visit(NegFormulaNode node) {
		ExprNode right = node.right();
		boolean bright = right.accept(this);
		return !bright;
	}

	@Override
	public Boolean visit(ChlFormulaNode node) {
		LiteralNode left = (LiteralNode)node.left();
		LiteralNode right = (LiteralNode)node.right();
		String from = left.value();
		String to   = right.value();
		String key  = "\\chl{"+ from + "}{"+ to +"}";
		if(map.containsKey(key)){
			boolean res = map.get(key);
			return res;
		}
		return false;
	}

	@Override
	public Boolean visit(AtomicFormulaNode node) {
		String key = node.value();
		if(key != null && map.containsKey(key)){
			boolean res = map.get(key);
			return res;
		}
		return false;
	}
	
	@Override
	public Boolean visit(LiteralNode node) {
		return false;
	}

	@Override
	public Boolean visit(MultiModalFormulaNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.acceptAsP(this); //modality 
		boolean bright= right.accept(this);
		return bright;
	}

	/*
	@Override
	public Boolean visit(IacProgramNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.accept(this);
		boolean bright= right.accept(this);
		return true; //TODO:
	}

	@Override
	public Boolean visit(CmfProgramNode node) {
		ExprNode left = node.left();
		ExprNode center = node.center();
		ExprNode right = node.right();
		boolean bleft = left.accept(this);
		boolean bcenter = center.accept(this); 
		boolean bright= right.accept(this);
		return true; //TODO:
	}*/

	@Override
	public Boolean visit(CmpProgramNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.acceptAsP(this);
		boolean bright= right.acceptAsP(this);
		return true; //TODO:
	}

	@Override
	public Boolean visit(ChoiceProgramNode node) {
		ExprNode left = node.left();
		ExprNode right = node.right();
		boolean bleft = left.acceptAsP(this);
		boolean bright= right.acceptAsP(this);
		return true; //TODO:
	}

	@Override
	public Boolean visit(TestProgramNode node) {
		ExprNode right = node.right();
		boolean bright= right.accept(this);
		return true; //TODO:
	}

	@Override
	public Boolean visit(AtomicProgramNode node) {
		ExprNode right = node.right();
		boolean bright= right.accept(this);
		return true; //TODO:
	} 
}