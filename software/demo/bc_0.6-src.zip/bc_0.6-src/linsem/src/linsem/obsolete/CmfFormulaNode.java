package linsem.obsolete;

import linsem.ast.ASTVisitor;
import linsem.ast.ExprNode;
import linsem.ast.QuaternaryOpNode;

public class CmfFormulaNode extends QuaternaryOpNode{

	public CmfFormulaNode(String op, ExprNode left, ExprNode l_center, ExprNode r_center, 
			ExprNode right) {
		super(op, left, l_center, r_center, right);
	}

	@Override
	public <S, E, P> E accept(ASTVisitor<S,E,P> visitor) {
		return visitor.visit(this);
	}

	@Override
	public <S, E, P> P acceptAsP(ASTVisitor<S, E, P> visitor) {
		return null;
	}
}

/*
public class CmfFormulaNode extends TernaryOpNode{

	public CmfFormulaNode(String op, ExprNode left, ExprNode center,
			ExprNode right) {
		super(op, left, center, right);
	}

	@Override
	public <S, E> E accept(ASTVisitor<S, E> visitor) {
		return visitor.visit(this);
	}
}
*/