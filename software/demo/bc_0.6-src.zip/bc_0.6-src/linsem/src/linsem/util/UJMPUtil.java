package linsem.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.swing.table.TableModel;

import org.ujmp.core.Matrix;
import org.ujmp.core.calculation.Calculation;
import org.ujmp.core.matrix.SparseMatrix;

public class UJMPUtil {
	
//TODO: for basic operations ------------
	//matrix2bmatrix
	public static SparseMatrix matrix2boolmatrix(SparseMatrix matrix){
		Iterable<long[]> coordinates = matrix.availableCoordinates();
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		
		for(long[] coordinate: coordinates){
			row = (int)coordinate[0];
			col = (int)coordinate[1];
			int value = matrix.getAsInt(row, col);
			if(value > 0) matrix.setAsInt(1, row, col);
			//System.out.println(row + ", " + col + ", " + matrix.getAsInt(row, col));
		}		
		return matrix;
	}
	
	public static void setMatrixLabels(SparseMatrix m, String[] row_labels, String[] col_labels){
		setAxisLabels(m, row_labels, true);
		setAxisLabels(m, col_labels, false);
	}
	
	public static void setAxisLabels(SparseMatrix m, String[] labels, boolean isRow){
		for(int i = 0; i < labels.length; i++){
			if(isRow) m.setRowLabel(i, labels[i]);
			else m.setColumnLabel(i, labels[i]);
		}		
	}

	public static String[] getAxisLabels(SparseMatrix m, boolean isRow){
		long num = 0;
		if(isRow) num = m.getRowCount();
		else num = m.getColumnCount(); 
		
		List<String> list = new ArrayList<String>();
		for(int i = 0; i < num; i++){
			if(isRow) list.add(m.getRowLabel(i));
			else list.add(m.getColumnLabel(i));
		}		
		return list.toArray(new String[0]);
	}
	
	public static SparseMatrix matrix2sparse(Matrix matrix){
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		
		SparseMatrix smatrix = SparseMatrix.factory.zeros(row, col);
		for(int i = 0; i < row; i++){
			for(int j = 0; j < col; j++){
				smatrix.setAsInt(matrix.getAsInt(i, j), i,j);
			}
		}
		return smatrix;
	}
	
	public static int get_index(String str, String delim){
		int index = str.indexOf(delim);
		if(index < 0) index = 0;
		String tmp = str.substring(index + 1);
		return Integer.parseInt(tmp);
	}
		
// for frame property checker ------------------------	
	public static boolean isT(SparseMatrix R){ //Reflexive
		long size = R.getRowCount();
		SparseMatrix E = (SparseMatrix) SparseMatrix.factory.eye(size, size);
		SparseMatrix R_plus_E = matrix2boolmatrix((SparseMatrix) R.plus(E));
		return R.equals(R_plus_E);
	}
	
	public static boolean isB(SparseMatrix R){ //Symmetric
		SparseMatrix t_R = (SparseMatrix) R.transpose();
		return R.equals(t_R);		
	}
	
	public static boolean is4(SparseMatrix R){ //Transitive
		SparseMatrix R_2 = matrix2boolmatrix((SparseMatrix) R.mtimes(R));
		SparseMatrix R_2_plus_R = matrix2boolmatrix((SparseMatrix) R_2.plus(R));
		return R.equals(R_2_plus_R);		
	}
	
	public static boolean isD(SparseMatrix R){ //Serial
		long row = R.getRowCount();
		SparseMatrix ones = (SparseMatrix) SparseMatrix.factory.ones(row, 1);
		SparseMatrix R_times_ones = matrix2boolmatrix((SparseMatrix)R.mtimes(ones));
		
		return ones.equals(R_times_ones);
	}
	
	public static boolean is5(SparseMatrix R){ //Euclidian //TODO:
		SparseMatrix t_R_times_R = matrix2boolmatrix((SparseMatrix)((SparseMatrix)R.transpose()).mtimes(R));
		SparseMatrix t_R_times_R_plus_R = matrix2boolmatrix((SparseMatrix)t_R_times_R.plus(R));
		return R.equals(t_R_times_R_plus_R);		
	}

// for Model generator ------------------
	
	public static void zeros(SparseMatrix matrix){
		fillMatrix(matrix, 0);
	}
	
	public static void ones(SparseMatrix matrix){
		fillMatrix(matrix, 1);
	}
	
	public static void fillMatrix(SparseMatrix matrix, int num){
		fillMatrix(matrix, num, false, false);
	}	

	public static void fillMatrixRandom(SparseMatrix matrix){
		fillMatrix(matrix, 1, false, true);
	}
	
	public static void diagonalize(SparseMatrix matrix){
		fillMatrix(matrix, 0, true, false);
	}
	
	public static void fillMatrix(SparseMatrix matrix, int num, boolean isDiagonalize, boolean isRandom){
		long row = matrix.getRowCount();
		long col = matrix.getColumnCount();
		for(int i = 0; i < row; i++){
			for(int j = 0; j < col; j++){
				if(!isRandom) {
					matrix.setAsInt(num, i, j);
				}else{
					if(Math.random() > 0.5) { matrix.setAsInt(num, i, j);}
					else{ matrix.setAsInt(0, i, j);}
				}
				
				if(i == j && isDiagonalize){
					matrix.setAsInt(1, i, j);
				}
			}
		}
	}
	
	public static SparseMatrix toT(SparseMatrix R){
		long size = R.getRowCount();
		SparseMatrix E = (SparseMatrix) SparseMatrix.factory.eye(size, size);
		return matrix2boolmatrix((SparseMatrix) R.plus(E));
	}
	
	public static SparseMatrix toB(SparseMatrix R){
		SparseMatrix t_R = (SparseMatrix) R.transpose();
		return matrix2boolmatrix((SparseMatrix) R.plus(t_R));
	}
	
	public static SparseMatrix to4(SparseMatrix R){
		System.out.println("Sorry, this function is under construction.");
		long size = R.getRowCount();
		SparseMatrix ones = (SparseMatrix) SparseMatrix.factory.ones(size, size);
		return ones;
	}
	
	public static SparseMatrix toD(SparseMatrix R){
		System.out.println("Sorry, this function is under construction.");
		//SparseMatrix R_T = toT(R);
		//bool_complement(R_T, true);
		long size = R.getRowCount();
		SparseMatrix ones = (SparseMatrix) SparseMatrix.factory.ones(size, size);
		return ones; 
	}
	
	public static SparseMatrix to5(SparseMatrix R){
		System.out.println("Sorry, this function is under construction.");
		long size = R.getRowCount();
		SparseMatrix ones = (SparseMatrix) SparseMatrix.factory.ones(size, size);
		return ones;
	}
			
// TODO: Def. of Boolean matrix operations ---------------------------
// new definitions	
// FIXME: resultant vector should contains an axis label.
	
	public static SparseMatrix bool_atomic_formula(SparseMatrix matrix, long i, boolean verbose){
		long row = matrix.getRowCount();
		SparseMatrix vresult = matrix2sparse(matrix.subMatrix(Calculation.LINK, 0, i, row-1, i));
		
		String[] row_labels = UJMPUtil.getAxisLabels(matrix, true);
		String[] col_labels = UJMPUtil.getAxisLabels(matrix, false);
		UJMPUtil.setMatrixLabels(vresult, row_labels, col_labels);

		if(verbose){
			if(Objects.nonNull(vresult)){
				System.out.println("-+-+-+-");
				System.out.println("V := ");
				System.out.println(matrix);
				System.out.println("======");
				System.out.println(col_labels[0] + " = ");
				System.out.println(vresult);				
			}
		}
		return vresult;
	}
	
	public static SparseMatrix bool_complement(SparseMatrix mright, boolean verbose){
		// returns matrix of `negation'.
		long row = mright.getRowCount();
		long col = mright.getColumnCount();
		SparseMatrix ones = (SparseMatrix)SparseMatrix.factory.ones(row, col);
		SparseMatrix mresult = matrix2boolmatrix((SparseMatrix)ones.minus(mright));
		
		String[] row_labels = UJMPUtil.getAxisLabels(mright, true);
		String[] col_labels_r = UJMPUtil.getAxisLabels(mright, false);
		String[] col_labels = { "(\\neg " + col_labels_r[0] +")" };
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);
		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("X := \n" + col_labels_r[0] + " = ");
			System.out.println(mright);
			System.out.println("======");
			System.out.println("\\neg X = \n" + col_labels[0] + " = ");
			System.out.println(mresult);
		}
		return mresult;
	}
	
	public static SparseMatrix bool_or(SparseMatrix mleft, SparseMatrix mright, boolean verbose){
		// returns matrix of `or'
		SparseMatrix mresult = matrix2boolmatrix((SparseMatrix) mleft.plus(mright));
		
		String[] row_labels = UJMPUtil.getAxisLabels(mleft, true);
		String[] col_labels_l = UJMPUtil.getAxisLabels(mleft, false);
		String[] col_labels_r = UJMPUtil.getAxisLabels(mright, false);
		String[] col_labels = { "(" + col_labels_l[0] + " \\lor " + col_labels_r[0] + ")"};
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);		

		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("X := \n" + col_labels_l[0] + " = ");
			System.out.println(mleft);
			System.out.println("------");
			System.out.println("Y:= \n" + col_labels_r[0] + " = ");
			System.out.println(mright);
			System.out.println("======");
			System.out.println("X \\lor Y = \n" + col_labels[0] + " = ");
			System.out.println(mresult);			
		}
		return mresult;
	}

	public static SparseMatrix bool_and(SparseMatrix mleft, SparseMatrix mright, boolean verbose){
		// retruns matrix of `and'.
		SparseMatrix mresult = bool_complement(bool_or(bool_complement(mleft, verbose), bool_complement(mright, verbose), verbose), verbose);
		
		String[] row_labels = UJMPUtil.getAxisLabels(mleft, true);
		String[] col_labels_l = UJMPUtil.getAxisLabels(mleft, false);
		String[] col_labels_r = UJMPUtil.getAxisLabels(mright, false);
		String[] col_labels = { "(" + col_labels_l[0] + " \\land " + col_labels_r[0] + ")"};
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);		

		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("X := \n" + col_labels_l[0] + " = ");
			System.out.println(mleft);
			System.out.println("------");
			System.out.println("Y := \n" + col_labels_r[0] + " = ");
			System.out.println(mright);
			System.out.println("======");
			System.out.println("X \\land Y = \n" + col_labels[0] + " = ");
			System.out.println(mresult);			
		}
		return mresult;
	}
	
	public static SparseMatrix bool_impl(SparseMatrix mleft, SparseMatrix mright, boolean verbose){
		// retruns truth set of `implication' (p \\to q)
		SparseMatrix mresult = bool_or(bool_complement(mleft, verbose), mright, verbose);
		
		String[] row_labels = UJMPUtil.getAxisLabels(mleft, true);
		String[] col_labels_l = UJMPUtil.getAxisLabels(mleft, false);
		String[] col_labels_r = UJMPUtil.getAxisLabels(mright, false);
		String[] col_labels = { "(" + col_labels_l[0] + " \\to " + col_labels_r[0] + ")"};
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);
		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("X := \n" + col_labels_l + " = ");
			System.out.println(mleft);
			System.out.println("------");
			System.out.println("Y := \n" + col_labels_r + " = ");
			System.out.println(mright);
			System.out.println("======");
			System.out.println("X \\to Y = \n" + col_labels[0] + " = ");
			System.out.println(mresult);			
		}
		return mresult;
	}
	
	public static SparseMatrix bool_chl(String from, String to, Map<String, SparseMatrix> C, boolean verbose){
		// returns truth set of `channel constant' (\\chl{a}{b})
		
		int i = 0; // row of resultant vector.
		Set<String> W = C.keySet();
		List<String> w_labels = new ArrayList<String>();
		w_labels.addAll(W);
		SparseMatrix res = SparseMatrix.factory.zeros(W.size(), 1); //this is a vector.
		for(Iterator<String> iter = W.iterator(); iter.hasNext(); ){
			String w = iter.next();
			
			//System.out.println(w);
			SparseMatrix chl = C.get(w);
			Long col = chl.getColumnForLabel(from);
			Long row = chl.getRowForLabel(to);
			if(col < 0 || row < 0) return null; // this is error.
			int num  = chl.getAsInt(row, col);
			
			res.setAsInt(num, i, 0);
			i++;
		}
		SparseMatrix mresult = matrix2boolmatrix(res);
		
		String[] row_labels = w_labels.toArray(new String[0]);
		String[] col_labels = {"\\chl{" + from + "}{" + to + "}"};
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);
		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("C := ");
			System.out.println(C);
			System.out.println("=======");
			System.out.println(col_labels[0] + " = ");
			System.out.println(mresult);
		}
		return mresult;
	}
	
	public static SparseMatrix bool_modal(SparseMatrix R, SparseMatrix col_vector, boolean verbose){
		SparseMatrix mresult = bool_complement(matrix2boolmatrix((SparseMatrix)R.mtimes(bool_complement(col_vector, false))), false);
		
		String   label_R    = R.getLabel();
		String[] row_labels = UJMPUtil.getAxisLabels(col_vector, true);
		String[] col_labels_v = UJMPUtil.getAxisLabels(col_vector, false);
		String[] col_labels = { "([" + label_R + "] " + col_labels_v[0] + ")"};
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);
		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("R_a := \n" + label_R + " = ");
			System.out.println(R);
			System.out.println(" X:= \n" + col_labels_v[0] + " = ");
			System.out.println(col_vector);
			System.out.println("=======");
			System.out.println("[R_a]X = \n" + col_labels[0] + " = ");
			System.out.println(mresult);
		}		
		return mresult;
	}

	public static SparseMatrix bool_modal_dia(SparseMatrix R, SparseMatrix col_vector, boolean verbose){
		//SparseMatrix mresult = matrix2boolmatrix((SparseMatrix)R.mtimes(col_vector));
		SparseMatrix mresult = bool_complement(bool_modal(R, bool_complement(col_vector , false), false), false);
		
		String   label_R    = R.getLabel();
		String[] row_labels = UJMPUtil.getAxisLabels(col_vector, true);
		String[] col_labels_v = UJMPUtil.getAxisLabels(col_vector, false);
		String[] col_labels = { "(<" + label_R + "> " + col_labels_v[0] + ")"};
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);

		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("R_a := \n" + label_R + " = ");
			System.out.println(R);
			System.out.println("X := \n" + col_labels_v[0] + " = ");
			System.out.println(col_vector);
			System.out.println("=======");
			System.out.println("<R_a>X = \n" + col_labels[0] + " = ");
			System.out.println(mresult);
		}
		return mresult;
	}
	
	public static SparseMatrix bool_atomic_program(Map<String, SparseMatrix>R, String key, boolean verbose){
		SparseMatrix R_a = R.get(key);
		String label = "\\rel{" + key + "}";
		R_a.setLabel(label);
		if(verbose){
			if(Objects.nonNull(R_a)){
				System.out.println("-+-+-+-");
				System.out.println("R := ");
				System.out.println(R);
				System.out.println("======");
				System.out.println(label + " = ");
				System.out.println(R_a);				
			}
		}
		return R_a;
	}
	
	public static SparseMatrix bool_choice(SparseMatrix mleft, SparseMatrix mright, boolean verbose){
		SparseMatrix mresult = matrix2boolmatrix((SparseMatrix) mleft.plus(mright));
		
		String[] row_labels = UJMPUtil.getAxisLabels(mleft, true);
		String[] col_labels = UJMPUtil.getAxisLabels(mleft, false);
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);
		
		String label_l = mleft.getLabel();
		String label_r = mright.getLabel();
		String label = "(" + label_l + " \\cup " + label_r + ")";
		mresult.setLabel(label);
		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("R_a := \n" + label_l + " = ");
			System.out.println(mleft);
			System.out.println("------");
			System.out.println("R_b := \n" + label_r + " = ");
			System.out.println(mright);
			System.out.println("======");
			System.out.println("R_a \\cup R_b = \n" + label + " = ");
			System.out.println(mresult);			
		}
		return mresult;
	}
	
	public static SparseMatrix bool_composition(SparseMatrix mleft, SparseMatrix mright, boolean verbose){
		//SparseMatrix mresult = bool_complement(bool_or(bool_complement(mleft, verbose), bool_complement(mright, verbose), verbose), verbose);
		SparseMatrix mresult = matrix2boolmatrix((SparseMatrix)mleft.mtimes(mright));
		
		String[] row_labels = UJMPUtil.getAxisLabels(mleft, true);
		String[] col_labels = UJMPUtil.getAxisLabels(mleft, false);
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);		

		String label_l = mleft.getLabel();
		String label_r = mright.getLabel();
		String label = "(" + label_l + " \\; " + label_r + ")";
		mresult.setLabel(label);
		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("R_a := \n" + label_l + " = ");
			System.out.println(mleft);
			System.out.println("------");
			System.out.println("R_b := \n" + label_r + " = ");
			System.out.println(mright);
			System.out.println("======");
			System.out.println("R_a \\; R_b = \n" + label + " = ");
			System.out.println(mresult);			
		}
		return mresult;
	}
	
	public static SparseMatrix bool_test(SparseMatrix col_vector, boolean verbose){
		long size = col_vector.getRowCount();
		SparseMatrix matrix_diagonalized = SparseMatrix.factory.zeros(size, size);
		
		Iterable<long[]> coordinates = col_vector.availableCoordinates();
		for(long[] coordinate: coordinates){
			long row = coordinate[0];
			long col = coordinate[1];
			matrix_diagonalized.setAsInt(1, row, row);
		}
		
		String[] row_labels = UJMPUtil.getAxisLabels(col_vector, true);
		String[] col_labels = UJMPUtil.getAxisLabels(col_vector, false);
		UJMPUtil.setMatrixLabels(matrix_diagonalized, row_labels, row_labels);
		
		String label = "(\\?" + col_labels[0] + ")";
		matrix_diagonalized.setLabel(label);
	
		
		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("X := \n" + col_labels[0] + " = ");
			System.out.println(col_vector);
			System.out.println("=======");
			System.out.println("\\?X = \n" + label + " = ");
			System.out.println(matrix_diagonalized);
		}
		return matrix_diagonalized;
	}
	
	public static SparseMatrix bool_test_complement(SparseMatrix square_matrix, boolean verbose){
		long size = square_matrix.getRowCount();
		int value = 0;
		SparseMatrix mresult = SparseMatrix.factory.zeros(size, size);
		
		for(int i = 0; i < size; i++){
			value = square_matrix.getAsInt(i,i);
			if(value > 0){
				mresult.setAsInt(0, i, i);
			}else{
				mresult.setAsInt(1, i, i);
			}
		}
		
		String[] row_labels = UJMPUtil.getAxisLabels(square_matrix, true);
		String[] col_labels = UJMPUtil.getAxisLabels(square_matrix, false);
		UJMPUtil.setMatrixLabels(mresult, row_labels, col_labels);
		
		String label_sq = square_matrix.getLabel();
		String label = "\\neg (" + label_sq + ")";
		mresult.setLabel(label);
		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("\\?X := \n" + label_sq + " = ");			
			System.out.println("=======");
			System.out.println("\\neg (\\?X) = \n" + label + " = ");
		}
		
		return mresult;
	}
	
	public static SparseMatrix bool_cmf(SparseMatrix X, SparseMatrix Y, SparseMatrix R_b, SparseMatrix Z, boolean verbose){
		//String[] w_labels = getAxisLabels(X, true);
		
		String label_X = X.getLabel();
		String label_Y = Y.getLabel();
		String label_R_b = R_b.getLabel();
		String label_Z = Z.getLabel();

		if(verbose){
			System.out.println("-+-+-+-");
			System.out.println("X := \n" + label_X + " = ");
			System.out.println(X);
			System.out.println("-------");
			System.out.println("Y := \n" + label_Y + " = ");
			System.out.println(Y);
			System.out.println("-------");
			System.out.println("R_b := \n" + label_R_b + " = ");
			System.out.println(R_b);
			System.out.println("-------");
			System.out.println("Z := \n" + label_Z + " = ");
			System.out.println(Z);
			System.out.println("=======");
		}
		//SparseMatrix XY = matrix2boolmatrix((SparseMatrix)X.mtimes(Y));
		//setMatrixLabels(XY, w_labels, w_labels);
		SparseMatrix XY = bool_composition(X, Y, false);
		if(verbose){
			System.out.println("XY = \n" + XY.getLabel() + " = ");
			System.out.println(XY);
			System.out.println("-------");
						
		}
		//SparseMatrix XY_R_b = matrix2boolmatrix((SparseMatrix)XY.mtimes(R_b));
		//setMatrixLabels(XY_R_b, w_labels, w_labels);
		SparseMatrix XY_R_b = bool_composition(XY, R_b, false);
		if(verbose){
			System.out.println("XY_R_b = \n" + XY_R_b.getLabel() + " = ");
			System.out.println(XY_R_b);
			System.out.println("-------");			
		}
		//SparseMatrix R_b_updated_succ = matrix2boolmatrix((SparseMatrix)XY_R_b.mtimes(Z));
		//setMatrixLabels(R_b_updated_succ, w_labels, w_labels);
		SparseMatrix R_b_updated_succ = bool_composition(XY_R_b, Z, false);
		if(verbose){
			System.out.println("XYR_bZ = \n" + R_b_updated_succ.getLabel() + " = ");
			System.out.println(R_b_updated_succ);
			System.out.println("-------");			
		}

		//SparseMatrix R_b_updated_fail = matrix2boolmatrix((SparseMatrix)test_complement(XY).mtimes(R_b)); 
		//setMatrixLabels(R_b_updated_fail, w_labels, w_labels);
		SparseMatrix negXY = bool_test_complement(XY, false); //Note: X and Y are program term, so we should use special test_complement function.
		if(verbose){
			System.out.println("\\neg XY = \n" + negXY.getLabel() + " = ");
			System.out.println(negXY);	
			System.out.println("-------");
		}
		SparseMatrix R_b_updated_fail = bool_composition(negXY, R_b, false);
		if(verbose){
			System.out.println("((\\neg XY))R_b = \n" + R_b_updated_fail.getLabel() + " = ");
			System.out.println(R_b_updated_fail);
			System.out.println("-------");
		}
		//SparseMatrix R_b_updated      = matrix2boolmatrix((SparseMatrix)R_b_updated_succ.plus(R_b_updated_fail));
		//setMatrixLabels(R_b_updated, w_labels, w_labels);
		SparseMatrix R_b_updated = bool_choice(R_b_updated_succ, R_b_updated_fail, false);
		if(verbose){
			System.out.println("=======");
			System.out.println("R'_b = \n" + R_b_updated.getLabel() + " = ");
			System.out.println(R_b_updated);
		}
		return R_b_updated;
	}
	
	public static SparseMatrix bool_iac(SparseMatrix formula, SparseMatrix agents){
		System.out.println("Note: Current version does not support \\iac operator.");
		return null;
	}
	
//TODO: for swing adapter functions -------------------- 
		//table2matrix
		public static SparseMatrix table2matrix (TableModel model) {
			int row = model.getRowCount();
			int col = model.getColumnCount();
			SparseMatrix matrix = SparseMatrix.factory.zeros(row, col); //row, col
			
			for(int i = 0; i < row; i++){ 
				for(int j = 0; j < col; j++){
					//System.out.println(i + ", " + j + ", " + model.getValueAt(i, j));
					try{
						Object obj = model.getValueAt(i, j);
						String data;  
						if(obj == null){ data = "0"; } //NOTE: this was a bug because of the null obj made a trouble.
						else {data = obj.toString(); }
						if(!data.isEmpty()){
							int value = Integer.parseInt(data);
							//System.out.println(value);
							matrix.setAsInt(value, i, j); //(val, row, col)						
						}
					}catch(NumberFormatException e){ e.printStackTrace(); return null; }
				}
			}
			return matrix;
		}
		
		//matrix2table	
		public static void matrix2table(SparseMatrix matrix, TableModel model){
			Iterable<long[]> coordinates = matrix.availableCoordinates();
			int row = model.getRowCount();
			int col = model.getColumnCount();
			
			for(int i = 0; i < row; i++){
				for(int j = 0; j < col; j++){
					model.setValueAt(0, i, j);
				}
			}
			
			for(long[] coordinate: coordinates){
				row = (int)coordinate[0];
				col = (int)coordinate[1];
				int value = matrix.getAsInt(row, col);
				//if(!isLinearAlgebra && (value != 0)){ value = 1; }
				model.setValueAt(value, row, col);
				//System.out.println(row + ", " + col + ", " + matrix.getAsInt(row, col));
			}
		}		
}
