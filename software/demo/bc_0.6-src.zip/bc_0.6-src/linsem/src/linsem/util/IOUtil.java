package linsem.util;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

public class IOUtil {
	
	public static int exec(String... args){
		ProcessBuilder pb = new ProcessBuilder();
		pb.command(args);
		Process proc = null;
		try {
			proc = pb.start();
			int ret = proc.waitFor();
			return ret;
		} catch (IOException e) {
			e.printStackTrace();
			return -1;
		} catch (InterruptedException e) {
			//e.printStackTrace();
			if(Objects.nonNull(proc)){ proc.destroyForcibly(); }
			System.out.println("exec: interrupted");
			return -1;
		}
	}
	
	
	public static boolean writeTextFile(String path, String txt){
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new PrintWriter(new File(path)));
			bw.write(txt);
			bw.flush();
			bw.close();
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public static boolean openFile(String path){
		Desktop d = Desktop.getDesktop();
		try {
			d.open(new File(path));
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
}
