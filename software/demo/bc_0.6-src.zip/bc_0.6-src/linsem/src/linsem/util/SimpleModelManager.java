package linsem.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.ujmp.core.matrix.SparseMatrix;

public class SimpleModelManager {

	protected String id;
	protected Double ver;
	protected File file;
	protected final static String FORMAT = "SIMPLE";

	//For loader
	public static enum State {Default, Matrix_R, Matrix_C, Matrix_V};
	State state;
	protected int num = -1;
	protected int i  = 0;
	protected SparseMatrix matrix;
	
	//Data
	protected int card_W = -1;
	protected int card_G = -1;
	protected int card_P = -1;
	protected Map<Integer, SparseMatrix> R;
	protected Map<Integer, SparseMatrix> C;
	protected SparseMatrix V;
	protected List<String> history;
	
	//for load
	public SimpleModelManager(File file){
		this.file  = file;
		this.state = State.Default;
		this.R     = new LinkedHashMap<Integer, SparseMatrix>();
		this.C 	   = new LinkedHashMap<Integer, SparseMatrix>();
		this.history = new ArrayList<String>();
	}
	
	//for save
	public SimpleModelManager(String id, double ver, File file, int card_W, int card_G, int card_P, Map<Integer, SparseMatrix> R, Map<Integer, SparseMatrix> C, SparseMatrix V, List<String> history){
		this.id		= id;
		this.ver 	= ver;
		this.file   = file;
		this.card_W = card_W;
		this.card_G = card_G;
		this.card_P = card_P;
		this.R = R;
		this.C = C;
		this.V = V;
		this.history = history;
	}
	
	public void save() throws IOException{
		StringBuilder sb = new StringBuilder();

		//Meta
		sb.append("// Generator: " + id + "\r\n");
		sb.append("// Version: " + ver + "\r\n");
		sb.append("// Format: " + FORMAT + "\r\n");
		sb.append("// Date: " + new Date() + "\r\n");
		sb.append("\r\n");
		
		//Syntax
		sb.append("// The syntax of this file is defined as follows: " + "\r\n");
		sb.append("// W [Number of the possible worlds]" + "\r\n");
		sb.append("// G [Number of the agents]" + "\r\n");
		sb.append("// P [Number of the atomic propositions]" + "\r\n");
		sb.append("// R [Agent id] \\n [Matrix of R (row: from world, col: to world)]" + "\r\n");
		sb.append("// C [World id] \\n [Matrix of C (row: to agent, col: from agent)]" + "\r\n");
		sb.append("// V \\n [Matrix of valuation (row: world, col: proposition id)]" + "\r\n");
		sb.append("// H [History of input command]" + "\r\n");
		sb.append("// // [a comment line]" + "\r\n");
		sb.append("\r\n");
		
		//Data
		sb.append("W " + card_W + "\r\n");
		sb.append("G " + card_G + "\r\n");
		sb.append("P " + card_P + "\r\n");

		for(int a = 0; a < card_G; a++){
			sb.append("R " + a + "\r\n");
			SparseMatrix R_a = R.get(a);
			sb.append(R_a.toIntMatrix() + "\r\n");
		}
		
		for(int w = 0; w < card_W; w++){
			sb.append("C " + w + "\r\n");
			SparseMatrix C_w = C.get(w);
			sb.append(C_w.toIntMatrix().toString() + "\r\n");
		}
		
		sb.append("V " + "\r\n");
		sb.append(V.toIntMatrix() + "\r\n");
		sb.append("\r\n");
		
		for(String h: history){
			sb.append("H \"" + h + "\"" + "\r\n");
		}
		
		IOUtil.writeTextFile(file.getAbsolutePath(), sb.toString());
	}
		
	public void load() throws Exception{
		BufferedReader buf = new BufferedReader(new FileReader(file));
		String input;
		while((input = buf.readLine())!=null){
			load_line_simple(input);
		}
		buf.close();
		System.out.println("load " + file.getAbsolutePath());
		printAll();
	}
	
	public void printAll(){
		System.out.println("W=" + card_W);
		System.out.println("G=" + card_G);
		System.out.println("P=" + card_P);
		for(Integer key: R.keySet()){
			System.out.println("R_" + key + ":\n" + R.get(key));
		}		
		for(Integer key: C.keySet()){
			System.out.println("C_" + key + ":\n" + C.get(key));
		}
		System.out.println("V:\n" + V);
	}
	
	public void load_line_simple(String input) throws Exception{
		input = input.trim();
		if(input.isEmpty())return; //to skip empty sequence.
		String[] args = input.split("[\\s]+");
		
		switch(state){
		case Default:
			load_params(input, args);
			break;
		case Matrix_R:
			load_matrix_row(args, card_W, card_W); 
			break;
		case Matrix_C:
			load_matrix_row(args, card_G, card_G); 
			break;
		case Matrix_V:
			load_matrix_row(args, card_W, card_P); 
			break;
		default:
		}
		
	}
	
	public void load_params(String input, String[] args) throws Exception{
		String command = args[0];
		switch(command){
		case "W":
			card_W = load_simple_param(args);
			break;
		case "G":
			card_G = load_simple_param(args);
			break;
		case "P":
			card_P = load_simple_param(args);
			break;
		case "R":	
			num     = load_simple_param(args);
			state  = State.Matrix_R;
			matrix = SparseMatrix.factory.zeros(card_W, card_W);
			break;
		case "C":
			num     = load_simple_param(args);
			state  = State.Matrix_C;
			matrix = SparseMatrix.factory.zeros(card_G, card_G);
			break;
		case "V":
			num	   = 0;
			state  = State.Matrix_V;
			matrix = SparseMatrix.factory.zeros(card_W, card_P);
			break;
		case "U": //user defined button (formula?)
			//TODO:
			break; //History
		case "H":
			load_history_param(input);
			break;
		case "c":
		case "//": //this is reserved for comment. skip.
			break;
		default:
			if(command.startsWith("c") || command.startsWith("//")){ ; } //skip
			else{ throw new Exception("Invalid parameter " + command);}
		}
	}
	
	public int load_simple_param(String[] args) throws NumberFormatException{
		String arg;
		if(args.length > 1){
			arg = args[1];
			return (int)Double.parseDouble(arg);
		}
		return -1;
	}
	
	public void load_history_param(String input) throws Exception{
		int begin = input.indexOf("\"");
		int end   = input.lastIndexOf("\"");
		if(begin < 0 || end < 0 || begin + 1 == end || end <= begin){ throw new Exception("Invalid parameter " + input); }
		String command = input.substring(begin + 1, end);
		history.add(command);
		//reset_loader_state();
	}
	
	public void load_matrix_row(String[] args, int row_max, int col_max) throws Exception{
		if(row_max < 1 || col_max < 1) throw new Exception("Matrix size is not loaded yet.");
		if(num < 0) throw new Exception("Invalid id.");
		if(args.length != col_max) {
			
			System.err.println(state);
			System.err.println("id = " + num);
			System.err.println("args.len = " + args.length);
			System.err.println("row_max = " + row_max);
			System.err.println("col_max  = " + col_max);
			System.err.println("i = " + i);
			for(String arg: args) System.err.println(arg);
			
			throw new Exception("Invalid column size.");
		}
		
		if(i < row_max){
			for(int j = 0; j < col_max; j++){
				int value = (int)Double.parseDouble(args[j]);
				matrix.setAsInt(value, i, j);
			}
			i++;//update index of rows
		}
		
		if(i >= row_max){
			switch(state){
				case Matrix_R:
					R.put(num, matrix);
				break;
				case Matrix_C:
					C.put(num, matrix);
				break;
				case Matrix_V:
					V = matrix;
				break;
			}
			reset_loader_state();
		}
	}
		
	public void reset_loader_state(){
		num= -1;
		i = 0;
		matrix = null;
		state = State.Default;		
	}
	

	public int get_W() {
		return card_W;
	}

	public int get_G() {
		return card_G;
	}

	public int get_P() {
		return card_P;
	}

	public Map<Integer, SparseMatrix> getR() {
		return R;
	}
	
	public Map<Integer, SparseMatrix> getC() {
		return C;
	}

	public SparseMatrix getV(){
		return V;
	}
	
	public List<String> getHistory(){
		return history;
	}
}
