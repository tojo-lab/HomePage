package linsem.ast;

public class IacProgramNode extends BinaryOpNode {

	public IacProgramNode(String op, ExprNode left, ExprNode right) {
		super(op, left, right);
	}

	@Override
	public <S, E, P> E accept(ASTVisitor<S, E, P> visitor) {
		return null;
	}

	@Override
	public <S, E, P> P acceptAsP(ASTVisitor<S, E, P> visitor) {
		return visitor.visit(this);
	}

	
}
