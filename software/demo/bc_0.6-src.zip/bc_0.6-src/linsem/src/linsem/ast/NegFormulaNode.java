package linsem.ast;

public class NegFormulaNode extends UnaryOpNode{

	public NegFormulaNode(String op, ExprNode right) {
		super(op, right);
	}

	@Override
	public <S, E, P> E accept(ASTVisitor<S,E,P> visitor) {
		return visitor.visit(this);
	}

	@Override
	public <S, E, P> P acceptAsP(ASTVisitor<S, E, P> visitor) {
		return null;
	}	
}
