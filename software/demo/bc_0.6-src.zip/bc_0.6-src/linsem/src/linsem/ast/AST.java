package linsem.ast;

import java.util.List;

public class AST extends Node {
	
	protected Location loc;
	protected List<StmtNode> list;
	
	public AST(Location loc, List<StmtNode> list){
		super();
		this.loc  = loc;
		this.list = list;
	}
	
	public StmtNode[] stmts(){
		return list.toArray(new StmtNode[0]);
	}

	@Override
	public Location location() {
		return this.loc;
	}

	@Override
	protected void _dump(Dumper d) {
		d.printNodeList("Statements", list);
	}
	
}
