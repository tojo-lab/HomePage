package linsem.ast;

public interface Dumperable {
	 void dump(Dumper d);
}
