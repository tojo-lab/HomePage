package linsem.ast;

public class CmfProgramNode extends TernaryOpNode{

	public CmfProgramNode(String op, ExprNode left, LiteralNode center, LiteralNode right) {
		super(op, left, center, right);
	}

	@Override
	public <S, E, P> E accept(ASTVisitor<S, E, P> visitor) {
		return null;
	}

	@Override
	public <S, E, P> P acceptAsP(ASTVisitor<S, E, P> visitor) {
		return visitor.visit(this);
	}

}
