package linsem.ast;

import java.io.PrintStream;


public abstract class Node implements Dumperable{
	
	public Node(){}
	
	abstract public Location location();
	
	public void dump(){
		dump(System.out);
	}
	
	public void dump(PrintStream ps){
		dump(new Dumper(ps));
	}
	
	@Override
	public void dump(Dumper d) {
		d.printClass(this, location());
		_dump(d);
	}

	abstract protected void _dump(Dumper d);
	
}
