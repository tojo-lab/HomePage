package linsem.ast;

public abstract class StmtNode extends Node{

	protected Location loc;
	
	public StmtNode(Location loc){
		this.loc = loc;
	}
	
	@Override
	public Location location() {
		return loc;
	}

	public abstract <S,E,P> S accept(ASTVisitor<S,E,P> visitor);
}
