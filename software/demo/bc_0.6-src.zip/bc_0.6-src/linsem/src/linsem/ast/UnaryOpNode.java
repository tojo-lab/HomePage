package linsem.ast;

public abstract class UnaryOpNode extends ExprNode{
	protected String op;
	protected ExprNode right;
	
	public UnaryOpNode(String op, ExprNode right){
		super();
		this.op 	= op;
		this.right	= right;
	}

	@Override
	public Location location() {
		return right.location();
	}

	@Override
	protected void _dump(Dumper d) {
		d.printMember("op", op);
		d.printMember("right", right);
	}
	
	public String op(){
		return op;
	}
	
	public ExprNode right(){
		return right;
	}

}
