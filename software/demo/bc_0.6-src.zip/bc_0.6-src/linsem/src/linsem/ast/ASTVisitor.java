package linsem.ast;

public interface ASTVisitor <S,E,P> {
	//We divide the type of output for visit function as follows:
	//S: type for ExprStmt (final return value)
	//E: type for formula
	//P: type for program term

	public S visit(ExprStmtNode node);
	
	/*
	public E visit(TernaryOpNode node);
	public E visit(BinaryOpNode node);
	public E visit(UnaryOpNode node);
	*/
	//formula
	public E visit(ImpFormulaNode node);
	public E visit(OrFormulaNode node);
	public E visit(AndFormulaNode node);
	//public E visit(IacFormulaNode node);
	//public E visit(CmfFormulaNode node);
	//public E visit(BelFormulaNode node);
	public E visit(MultiModalFormulaNode node);
	public E visit(MultiModalFormulaNodeD node);
	public E visit(NegFormulaNode node);
	public E visit(ChlFormulaNode node);
	public E visit(AtomicFormulaNode node);
	public E visit(LiteralNode node);

	//program term
	public P visit(IacProgramNode node);
	public P visit(CmfProgramNode node);
	public P visit(ChoiceProgramNode node);
	public P visit(CmpProgramNode node);
	public P visit(TestProgramNode node);
	public P visit(AtomicProgramNode node);
    
}
