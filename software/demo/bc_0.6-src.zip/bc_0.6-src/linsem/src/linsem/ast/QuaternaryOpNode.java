package linsem.ast;

public abstract class QuaternaryOpNode extends ExprNode{
	protected String op;
	protected ExprNode left, l_center, r_center, right;
	
	public QuaternaryOpNode(String op, ExprNode left, ExprNode l_center, ExprNode r_center, ExprNode right){
		super();
		this.op 	= op;
		this.left	= left;
		this.l_center = l_center;
		this.r_center = r_center;
		this.right	= right;
	}
	
	@Override
	public Location location() {
		return left.location();
	}

	@Override
	protected void _dump(Dumper d) {
		d.printMember("op", op);
		d.printMember("left", left);
		d.printMember("l_center", l_center);
		d.printMember("r_center", r_center);
		d.printMember("right", right);
	}

	public String op(){
		return op;
	}
	
	public ExprNode left(){
		return left;
	}

	public ExprNode l_center(){
		return l_center;
	}
	
	public ExprNode r_center(){
		return r_center;
	}

	public ExprNode right(){
		return right;
	}
	
}
