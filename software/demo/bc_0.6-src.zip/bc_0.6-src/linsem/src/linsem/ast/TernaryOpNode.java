package linsem.ast;

public abstract class TernaryOpNode extends ExprNode{
	protected String op;
	protected ExprNode left, center, right;
	
	public TernaryOpNode(String op, ExprNode left, ExprNode center, ExprNode right){
		super();
		this.op 	= op;
		this.left	= left;
		this.center = center;
		this.right	= right;
	}

	@Override
	public Location location() {
		return left.location();
	}

	@Override
	protected void _dump(Dumper d) {
		d.printMember("op", op);
		d.printMember("left", left);
		d.printMember("center", center);
		d.printMember("right", right);
	}
	
	public String op(){
		return op;
	}
	
	public ExprNode left(){
		return left;
	}

	public ExprNode center(){
		return center;
	}

	public ExprNode right(){
		return right;
	}

}
