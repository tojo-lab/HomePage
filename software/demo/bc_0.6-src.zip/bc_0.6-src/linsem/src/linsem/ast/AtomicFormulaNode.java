package linsem.ast;

public class AtomicFormulaNode extends LiteralNode{

	public AtomicFormulaNode(Location loc, String value) {
		super(loc, value);
	}

	@Override
	public <S, E, P> E accept(ASTVisitor<S,E,P> visitor) {
		return visitor.visit(this);
	}

}
