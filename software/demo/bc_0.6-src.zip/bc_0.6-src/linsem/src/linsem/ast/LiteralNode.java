package linsem.ast;

public class LiteralNode extends ExprNode{

	protected Location loc;
	protected String value; 
	
	public LiteralNode(Location loc, String value){
		this.loc = loc;
		this.value = value;
	}
	
	@Override
	public Location location() {
		return loc;
	}

	@Override
	protected void _dump(Dumper d) {
		d.printMember("value", value);
	}
	
	public String value(){
		return value;
	}

	public <S, E, P> E accept(ASTVisitor<S,E,P> visitor){
		return visitor.visit(this);
	}

	@Override
	public <S, E, P> P acceptAsP(ASTVisitor<S, E, P> visitor) {
		return null;
	}

}
