package linsem.ast;

public abstract class ExprNode extends Node{
	 public abstract <S,E,P> E accept(ASTVisitor<S,E,P> visitor);    //E: accept as formula
	 public abstract <S,E,P> P acceptAsP(ASTVisitor<S,E,P> visitor); //P: accept as program term
}
