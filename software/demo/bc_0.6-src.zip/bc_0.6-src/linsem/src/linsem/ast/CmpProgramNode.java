package linsem.ast;

public class CmpProgramNode extends BinaryOpNode{
	//for 'composition'

	public CmpProgramNode(String op, ExprNode left, ExprNode right) {
		super(op, left, right);
	}
	
	@Override
	public <S, E, P> E accept(ASTVisitor<S,E,P> visitor) {
		return null; //this is not formula, so it does not return truth value etc. 
	}

	@Override
	public <S, E, P> P acceptAsP(ASTVisitor<S, E, P> visitor) {
		return visitor.visit(this);
	}
}
