package linsem.ast;

public class ExprStmtNode extends StmtNode{
	
	protected ExprNode expr;
	
	public ExprStmtNode(Location loc, ExprNode expr){
		super(loc);
		this.expr = expr;
	}

	@Override
	protected void _dump(Dumper d) {
		d.printMember("expr", expr);
	}
	
	public ExprNode expr(){
		return expr;
	}

	@Override
	public <S, E, P> S accept(ASTVisitor<S, E, P> visitor) {
		return visitor.visit(this);
	}

}
