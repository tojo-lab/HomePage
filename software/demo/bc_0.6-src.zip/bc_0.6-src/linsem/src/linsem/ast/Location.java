package linsem.ast;

import linsem.parser.Token;

public class Location {
	protected String sourceName;
	protected Token tok;
	
	public Location(String sourceName, Token tok){
		this.sourceName = sourceName;
		this.tok = tok;
	}
	
	public String toString(){
		return sourceName + ":" + tok.beginLine;
	}
	
}
