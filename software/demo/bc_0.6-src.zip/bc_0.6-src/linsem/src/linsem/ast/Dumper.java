package linsem.ast;

import java.io.PrintStream;
import java.util.List;

public class Dumper {
	protected int indent;
	protected PrintStream ps;
	
	static final protected String indentString = "\t";
	
	public Dumper(PrintStream ps){
		this.ps 	= ps;
		this.indent = 0;
	}
	
	public void printClass(Object obj, Location loc){
		printIndent();
		ps.println("<" + obj.getClass().getSimpleName() + "> (" + loc + ")");
	}

	public void printMember(String name, String value){
		printIndent();
		ps.println(name + ": " + value);
	}
	
	public void printMember(String name, Dumperable node){
		printIndent();
		if(node == null) ps.println(name + ": null");
		else{
			ps.println(name + ":");
			indent();
			node.dump(this);
			outdent();
		}
	}

	public void printNodeList(String name, List<? extends Dumperable> nodes) {
		printIndent();
		ps.println(name + ":");
		indent();
		for(Dumperable node: nodes){
			node.dump(this);
		}
		outdent();
	}
	
    protected void indent() { indent++; }
    protected void outdent() { indent--; }
	
	protected void printIndent(){
		int cnt = indent;
		while(cnt > 0){
			ps.print(indentString);
			cnt--;
		}
	}

}
