package linsem.gui.table;

import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;

public class MatrixTableModel extends DefaultTableModel{
	private static final long serialVersionUID = 8645540423207864564L;

	public enum ResetMode{ZEROS, ONES, DIAGONALIZE};
	
	private final DefaultListModel rowListModel; 
	public final ResetMode resetMode;
	protected String row_header;
	protected String col_header; 
	
	public static MatrixTableModel newInstance(String row_header, String col_header, int row_size, int col_size){
		Object[][] emptyData = new Object[row_size][col_size];
		String[] rowHeaders = getStringRange(row_header, 1, row_size + 1);
		String[] colHeaders = getStringRange(col_header, 1, col_size + 1);
		return new MatrixTableModel(emptyData, row_header, col_header, colHeaders, rowHeaders, ResetMode.DIAGONALIZE);
	}	
	
	protected MatrixTableModel(Object[][] obj, String row_header, String col_header, String[] colHeaders, String[] rowHeaders, ResetMode resetMode){
		super(obj, colHeaders);
		this.row_header = row_header;
		this.col_header = col_header;
		this.resetMode = resetMode;
		rowListModel = new DefaultListModel();
		setRowIdentifiers(rowHeaders);
		/*
		for(int i = 0; i < rowHeaders.length; i++){
			String header = "";
			if(rowHeaders[i] != null){
				header = rowHeaders[i];
			}
			rowListModel.add(i, header);
		}*/		
		reset();
	}
	
	protected static Integer[] range(int begin, int end) {
		if (begin < end) {
			Integer[] arr = new Integer[end - begin];
			for (int i = 0; i + begin < end; i++) {
				arr[i] = i + begin;
			}
			return arr;
		}
		return null;
	}

	protected static String[] getStringRange(String prefix, int begin, int end){
		Integer[] suffix = range(begin, end);
		int size = suffix.length;
		String[] data = new String[size];
		for(int i = 0; i < size; i++){
			data[i] = prefix + suffix[i].toString();
		}
		return data;
	}
	
	public void setRowIdentifiers(String[] rowHeaders){
		for(int i = 0; i < rowHeaders.length; i++){
			String header = "";
			if(rowHeaders[i] != null){
				header = rowHeaders[i];
			}
			rowListModel.add(i, header);
		}				
	}
	
	public void setTableIdentifiers(String[] colHeaders, String[] rowHeaders){
		setColumnIdentifiers(colHeaders);
		setRowIdentifiers(rowHeaders);
	}
	
	public void addRow(Object[] obj){
		addRow("", obj);
	}
	
	public void addRow(String header){
		addRow(header, null);
	}
	
	public void addRow(String header, Object[] obj){
		super.addRow(obj);
		rowListModel.addElement(header);
		
	}
	
	public void addRows(String header_prefix, int addSize){
		int currentSize = getRowCount();
		for(int i = currentSize; i < currentSize+addSize; i++){
			addRow(header_prefix + String.valueOf(i+1));
		}
		expandTable(0);
	}
	
	public void removeRow(int index){
		super.removeRow(index);
		rowListModel.remove(index);
	}
	
	public void removeRows(int removeSize){
		int currentSize = rowListModel.getSize();
		rowListModel.setSize(currentSize-removeSize);
		this.setRowCount(currentSize-removeSize);
	}
	
	public DefaultListModel getRowListModel(){
		return rowListModel; //bug?
	}
	
	public void addColumns(String header_prefix, int addSize){
		int currentSize = getColumnCount();
		for(int i = currentSize; i < currentSize+addSize; i++){
			addColumn(header_prefix + String.valueOf(i+1));
		}
		expandTable(0);
	}
	
	public void removeColumns(int removeSize){
		int currentSize = this.getColumnCount();
		this.setColumnCount(currentSize-removeSize);
	}
	
	public void reset(){
		switch(resetMode){
		case ZEROS:
			zeros();
			break;
		case ONES:
			ones();
			break;
		case DIAGONALIZE:
			diagonalize();
			break;
		}
	}
	
	public void zeros(){
		fillTable(0);
	}
	
	public void ones(){
		fillTable(1);
	}
	
	public void fillTable(int num){
		fillTable(num, false, false);
	}	

	public void fillTableRandom(){
		fillTable(1, false, true);
	}
	
	public void diagonalize(){
		fillTable(0, true, false);
	}

	public void fillTable(int num, boolean isDiagonalize, boolean isRandom){
		int row = getRowCount();
		int col = getColumnCount();
		for(int i = 0; i < row; i++){
			for(int j = 0; j < col; j++){
				if(!isRandom) {
					setValueAt(num, i, j);
				}else{
					if(Math.random() > 0.5) {setValueAt(num, i, j);}
					else{setValueAt(0, i, j);}
				}
				
				if(i == j && isDiagonalize){
					setValueAt(1, i, j);
				}
			}
		}
	}
	
	public void expandTable(int num){
		int row = getRowCount();
		int col = getColumnCount();
		for(int i = 0; i < row; i++){
			for(int j = 0; j < col; j++){
				Object obj = getValueAt(i,j);
				if(obj == null){ //TODO: 
					setValueAt(num, i,j);
				}
			}
		}		
	}
	
	public boolean isSquare(){
		int col = getColumnCount();
		int row = getRowCount();
		return col == row;
	}
	
	public boolean isVector(){
		int col = getColumnCount();
		int row = getRowCount();
		return (col == 1) || (row == 1);
	}
	
	public String getRowHeader(){
		return row_header;
	}
	
	public String getColumnHeader(){
		return col_header;
	}
}
