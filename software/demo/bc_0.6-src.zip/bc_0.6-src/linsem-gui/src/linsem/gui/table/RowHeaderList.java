package linsem.gui.table;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Objects;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.table.JTableHeader;

//from: http://terai.xrea.jp/Swing/TableRowHeader.html
public class RowHeaderList<E> extends JList<E> {
	private static final long serialVersionUID = 6646349525836043318L;

	protected final JTable table;
	protected final ListSelectionModel tableSelection;
	protected final ListSelectionModel rowListSelection;
	protected int rollOverRowIndex = -1;
	protected int pressedRowIndex = -1;

	public RowHeaderList(ListModel<E> model, JTable table) {
		super(model);
		this.table = table;
		setFixedCellHeight(table.getRowHeight());
		setCellRenderer(new RowHeaderRenderer<E>(table.getTableHeader()));
		RollOverListener roListener = new RollOverListener();
		addMouseListener(roListener);
		addMouseMotionListener(roListener);
		tableSelection = table.getSelectionModel();
		rowListSelection = getSelectionModel();
	}
	
	class RowHeaderRenderer<E> extends JLabel implements ListCellRenderer<E> {
		private static final long serialVersionUID = -6128468757418528805L;
		private final JTableHeader header;
		
		public RowHeaderRenderer(JTableHeader header) {
			super();
			this.header = header;
			this.setOpaque(true);
			this.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 2, Color.GRAY.brighter()));
			this.setHorizontalAlignment(CENTER);
			this.setForeground(header.getForeground());
			this.setBackground(header.getBackground());
			this.setFont(header.getFont());
		}

		@Override
		public Component getListCellRendererComponent(JList<? extends E> list,
				E value, int index, boolean isSelected, boolean cellHasFocus) {
			if(index == pressedRowIndex){
				setBackground(Color.GRAY);
			}else if(index == rollOverRowIndex){
				setBackground(Color.WHITE);
			}else if(isSelected){
				setBackground(Color.GRAY.brighter());
			}else{
				setForeground(header.getForeground());
				setBackground(header.getBackground());
			}
			setText(Objects.toString(value, ""));
			return this;
		}

	}

	class RollOverListener extends MouseAdapter {
		@Override
		public void mouseExited(MouseEvent e) {
			if (pressedRowIndex < 0) {
				rollOverRowIndex = -1;
				repaint();
			}
		}
		
		@Override
		public void mouseMoved(MouseEvent e){
			int row = locationToIndex(e.getPoint());
			if(row != rollOverRowIndex){
				rollOverRowIndex = row;
				repaint();
			}
		}
		
		@Override
		public void mouseDragged(MouseEvent e){
			if(pressedRowIndex >= 0){
				int row = locationToIndex(e.getPoint());
				int start = Math.min(row, pressedRowIndex);
				int end = Math.max(row, pressedRowIndex);
				tableSelection.clearSelection();
				rowListSelection.clearSelection();
				tableSelection.addSelectionInterval(start, end);
				rowListSelection.addSelectionInterval(start, end);
				repaint();
			}
		}
		
		@Override
		public void mousePressed(MouseEvent e){
			int row = locationToIndex(e.getPoint());
			if(row == pressedRowIndex) return;
			rowListSelection.clearSelection();
			table.changeSelection(row, 0, false, false);
			table.changeSelection(row, table.getColumnCount()-1, false, true);
			pressedRowIndex = row;
		}
		
		@Override
		public void mouseReleased(MouseEvent e){
			rowListSelection.clearSelection();
			pressedRowIndex = -1;
			rollOverRowIndex = -1;
			repaint();
		}
	}
	
}

