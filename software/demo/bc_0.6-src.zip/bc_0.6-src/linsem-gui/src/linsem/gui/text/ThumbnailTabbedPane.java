package linsem.gui.text;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JToolTip;
import javax.swing.LookAndFeel;

public class ThumbnailTabbedPane extends JTabbedPane {
    
	protected int curr = -1;
    protected double scale = .85;
    
    public ThumbnailTabbedPane(){
    	super();
    }
    
    public ThumbnailTabbedPane(double scale){
    	this.scale = scale;
    }
    
    protected Component getTabThumbnail(int index) {
        Component comp = getComponentAt(index);
        Icon icon = null;
        if (comp instanceof JPanel) {
            Dimension d = comp.getPreferredSize();
            int new_width = (int) (d.width  * scale);
            int new_hight = (int) (d.height * scale);
            BufferedImage image = new BufferedImage(new_width, new_hight, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = image.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.scale(scale, scale);
            comp.paint(g);
            g.dispose();
            icon = new ImageIcon(image);
        } else if (comp instanceof JLabel) {
            icon = ((JLabel) comp).getIcon();
        }
        return new JLabel(icon);
    }
    
    @Override 
    public JToolTip createToolTip() {
        int index = curr;
        if (index < 0) return null;

        final JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder());
        panel.add(new JLabel(getTitleAt(index)), BorderLayout.NORTH);
        panel.add(getTabThumbnail(index));

        JToolTip tooltip = new JToolTip() {
        	@Override 
            public Dimension getPreferredSize() {
                Insets i = getInsets();
                Dimension d = panel.getPreferredSize();
                return new Dimension(d.width + i.left + i.right, d.height + i.top + i.bottom);
            }
        };
        tooltip.setComponent(this);
        LookAndFeel.installColorsAndFont(panel, "ToolTip.background", "ToolTip.foreground", "ToolTip.font");
        tooltip.setLayout(new BorderLayout());
        tooltip.add(panel);
        return tooltip;
    }
    
    @Override 
    public String getToolTipText(MouseEvent e) {
        int index = indexAtLocation(e.getX(), e.getY());
        String str = (curr == index) ? super.getToolTipText(e) : null;
        curr = index;
        return str;
    }
    
    public void setScale(double scale){
    	this.scale = scale;
    }
    
    public double getScale(){
    	return scale;
    }
}