package linsem.gui.thread;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;


public class SimpleWorker extends SwingWorker<String, ProgressData>{

	protected boolean isPausing;
	protected boolean isBlinking = false;
	protected JComponent parent;
	protected JComponent root;
	protected int start_interval = 300;
	protected int pause_interval = 500;
	protected boolean isDisposeAfterDone = true;
	protected int curr = 0;
	protected int task_size = 0;
	protected String title = "";
	protected long start_time = 0;
	protected boolean verbose_flag;
	
	public SimpleWorker(JComponent parent, JComponent root){
		this.parent = parent;
		this.root   = root;
		this.verbose_flag = true;
		if(Objects.nonNull(parent)){ this.title  = parent.getName(); }
	}
	
	public SimpleWorker(JComponent parent, JComponent root, String title){
		this(parent, root);
		this.title = title;
	}

	public SimpleWorker(JComponent parent, JComponent root, String title, boolean isDisposeAfterDone){
		this(parent, root, title);
		this.isDisposeAfterDone = isDisposeAfterDone;
	}
	
	@Override
	protected void process(List<ProgressData> chunks){ //Handled by event dispatch thread (EDT)
		if(isCancelled()) return;
		/*
		if(!parent.isDisplayable()){
			//process: DISPOSE_ON_CLOSE
			cancel(true);
			return;
		}*/
		
		for(ProgressData chunk: chunks){
			switch(chunk.state){
				case MAIN: 
					//bar.setValue((Integer)chunk.value); 
					setProgress((Integer)chunk.value);
					break;
				case LOG:
					System.out.println((String)chunk.value);
					break;
				case WORK:
					System.out.print((String)chunk.value);
					break;
				case PAUSE:
					blink((Boolean)chunk.value);
					break;
				default:
					throw new AssertionError("Unknown state");
			}
		}
	}
	
	
	public void blink(boolean isAppend){
		/*
		
		if(isAppend){
			calc_panel.stream_area.append(".");
		}else{
			try{
				Document doc = calc_panel.stream_area.getDocument();
				doc.remove(doc.getLength() - 1, 1);
			}catch(BadLocationException e){ e.printStackTrace(); } 
		}*/
	}
	
	@Override
	protected String doInBackground() { //Handled by working thread
		if(verbose_flag){ System.out.println("Thread : " + Thread.currentThread().getName() + "(" + Thread.currentThread().getId() + ")"); }
		//try{ Thread.sleep(start_interval); }catch(InterruptedException e){ return "Interrupted."; }
		try{ doTask(); }catch(Exception e){ if(isDisposeAfterDone){ removeParent(); } }
		return "Done";
	}
	
	protected void doTask(){
		initTask(50);
		publish(new ProgressData(WorkerState.LOG, "Size of task: " + task_size));
		publish(new ProgressData(WorkerState.LOG, "\n---------------\n"));
		curr = 0;
		while(curr <= task_size && !isCancelled()){ //Main loop
			if(isPausing){
				try{ Thread.sleep(pause_interval); }catch(InterruptedException e){ break; }
				publish(new ProgressData(WorkerState.PAUSE, isBlinking));
				isBlinking ^= true;
				continue;
			}
			try{ Thread.sleep(50); }catch(InterruptedException e){ break; }
			//setProgress(100 * curr / size);
			publish(new ProgressData(WorkerState.WORK, "."));
			progress();
		}			
	}	
	
	public void initTask(int task_size){
		start_time = System.currentTimeMillis();
		curr = 0;
		this.task_size = task_size;
		setProgress(0);
	}
	
	public void addTask(int task_size){
		this.task_size += task_size;
	}
	
	public void progress(){
		publish(new ProgressData(WorkerState.MAIN, 100 * curr / task_size));
		curr++;
	}
				
	@Override
	public void done(){
		/*
		if(!parent.isDisplayable()){
			cancel(true);
			return;
		}*/
		try {
			if(isCancelled())System.out.println("Cancelled" + getTitle());
			else { if(verbose_flag){ System.out.println(get() + getTitle()); }}
		} catch (InterruptedException | ExecutionException e) { e.printStackTrace(); }
		if(isDisposeAfterDone){ removeParent(); }
	}
		
	public void pause(){
		isPausing ^= true;
	}
	
	public boolean isPaused(){
		return isPausing;
	}
	
	public boolean isBlinking(){
		return isBlinking;
	}
	
	protected void removeParent(){
		SwingUtilities.invokeLater(new Runnable(){
			@Override
			public void run() {
				if(Objects.nonNull(parent)){
					parent.setVisible(false);
					if(Objects.nonNull(root)){
						root.remove(parent);
						root.getRootPane().revalidate();
						//System.out.println("root removed.");
					}
				}
			}			
		});
	}
	
	public String getTitle(){
		return title;
	}
	
	public long getStartTime(){
		return start_time;
	}
	
	public int getTaskSize(){
		return task_size;
	}
	
	public int getCurrentDoneTask(){
		return curr;
	}
	
	protected void setVerbose(boolean b){
		this.verbose_flag = b;
	}
	
	protected boolean isVerbose(){
		return this.verbose_flag;
	}
}