package linsem.gui.rpi;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import linsem.gui.EditorPanel;
import linsem.gui.text.ThumbnailTabbedPane;

public class RPiEditorPanel extends EditorPanel{

	protected JTabbedPane tabbed_pane = null;
	protected JPanel model_panel = null;
	protected static final Font default_font = new Font(Font.SERIF, Font.PLAIN, 32);
	
	@Override
	public void initPanel(){
		setPreferredSize(new Dimension(640, 400));
		add(getTabbedPane());
		world_spinner.setPreferredSize(new Dimension(80, 30));
		agent_spinner.setPreferredSize(new Dimension(80, 30));
		proposition_spinner.setPreferredSize(new Dimension(80, 30));
		relation_table.setRowHeight(50);
		relation_table.setFont(default_font);
		channel_table.setRowHeight(50);
		channel_table.setFont(default_font);
		valuation_table.setRowHeight(50);
		valuation_table.setFont(default_font);
	}
	
	public JTabbedPane getTabbedPane(){
		if(tabbed_pane == null){
			tabbed_pane = newDefaultTabbedPane();
			tabbed_pane.addTab("<html><h4>Model</h4></html>", null, getModelPanel(), "dummy");
			tabbed_pane.addTab("<html><h4>Relation</h4></html>", null, getRelationPanel(), "dummy");
			tabbed_pane.addTab("<html><h4>Channel</h4></html>", null, getChannelPanel(), "dummy");
			tabbed_pane.addTab("<html><h4>Valuation</h4></html>", null, getValuationPanel(), "dummy");			
		}
		return tabbed_pane;
	}
	
	public JPanel getModelPanel(){
		if(model_panel == null){
			model_panel = new JPanel();
			//model_panel.setLayout(new BoxLayout(model_panel, BoxLayout.Y_AXIS));
			model_panel.setLayout(new BorderLayout(0, 0));
			model_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			model_panel.setAlignmentY(Component.TOP_ALIGNMENT);
			model_panel.add(getToolbarPanel(), BorderLayout.NORTH);
			JPanel panel = new JPanel();
			panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			panel.setAlignmentY(Component.TOP_ALIGNMENT);
			model_panel.add(panel, BorderLayout.CENTER);
			//panel.setLayout(new BorderLayout(0, 0));
			panel.add(getWorldPanel());
			panel.add(getAgentPanel());			
		}
		return model_panel;
	}
	
	public JTabbedPane newDefaultTabbedPane(){
		JTabbedPane tabbed_pane = new ThumbnailTabbedPane();
		tabbed_pane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		tabbed_pane.setAlignmentX(Component.LEFT_ALIGNMENT);
		tabbed_pane.setAlignmentY(Component.TOP_ALIGNMENT);
		return tabbed_pane;
	}
}
