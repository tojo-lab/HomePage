package linsem.gui.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorTest implements Runnable{

	protected int id;
	
	public ExecutorTest(int id){
		this.id = id;
	}

	@Override
	public void run() {
		System.out.println("run(" + id + ")#begin - " + Thread.currentThread().getId());
		try{ Thread.sleep(1000); }catch(InterruptedException e){ System.out.println("run(" + id + ")#interrupted - " + Thread.currentThread().getId()); }
		System.out.println("run(" + id + ")#end - " + Thread.currentThread().getId());
	}
	
	
	public static void main(String... args){
		test(Executors.newSingleThreadExecutor());
		try { Thread.sleep(5000); } catch (InterruptedException e) { e.printStackTrace(); }
		System.out.println("---");
		test(Executors.newFixedThreadPool(3));
		try { Thread.sleep(5000); } catch (InterruptedException e) { e.printStackTrace(); }
		System.out.println("---");
		test(Executors.newCachedThreadPool());
	}
	
	public static void test(ExecutorService exec){
		System.out.println("main()#init - " + exec.getClass().getSimpleName());
		
		for(int i = 0; i < 5; i++){
			System.out.println("main(" + i + ")#submit - " + Thread.currentThread().getId());
			exec.submit(new ExecutorTest(i));
		}
		exec.shutdown();		
	}
	
}
