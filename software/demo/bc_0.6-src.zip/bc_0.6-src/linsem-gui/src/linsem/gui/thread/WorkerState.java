package linsem.gui.thread;

public enum WorkerState {
	MAIN, SUB, LOG, WORK, PAUSE
}
