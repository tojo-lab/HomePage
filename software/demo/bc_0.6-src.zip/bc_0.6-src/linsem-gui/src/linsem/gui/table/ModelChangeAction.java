package linsem.gui.table;

import javax.swing.JFrame;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

public class ModelChangeAction implements ChangeListener, TableModelListener{
	
	protected JFrame parent;
	public static final String CHANGED_MARK = "*";
	
	public ModelChangeAction(JFrame parent){
		this.parent = parent;
	}
	
	@Override
	public void tableChanged(TableModelEvent e) {
		notifyModelChanged();
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		notifyModelChanged();
		
	}
	
	public void notifyModelChanged(){
		String title = parent.getTitle();
		if(!title.isEmpty() && !title.endsWith(CHANGED_MARK))parent.setTitle(title + " " + CHANGED_MARK);
	}

	
}