package linsem.gui.text;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import javax.swing.JTextArea;

public class StreamRedirectArea extends JTextArea{
	
	private static final long serialVersionUID = -6989991968156352615L;

	protected RedirectOutputStream stream;
	//protected RedirectOutputStream errStream;
	
	public StreamRedirectArea(){
		super();
		stream = new RedirectOutputStream(this);
		//errStream = new RedirectOutputStream(this);
	}
	
	public void setSystemStream(){
		System.setOut(new PrintStream(stream));
		//System.setErr(new PrintStream(stream));
		//System.setErr(new PrintStream(errStream));
	}
	
	public void flush(){
		this.append(stream.toString());
		setCaretPosition(getDocument().getLength()); //TODO: this should be option
		stream.reset();
		//this.append(errStream.toString());
		//errStream.reset();
	}
	
	class RedirectOutputStream extends ByteArrayOutputStream{
		
		protected StreamRedirectArea area;
		
		public RedirectOutputStream(StreamRedirectArea area){
			super();
			this.area = area;
		}
		
		public synchronized void write(int buf){
			super.write(buf);
			area.flush();
		}
		
		public synchronized void write(byte[] buf, int offset, int len){
			super.write(buf, offset, len);
			area.flush();
		}
		
		public void write(byte[] buf) throws IOException {
			super.write(buf);
			area.flush();
		}
	}
}
