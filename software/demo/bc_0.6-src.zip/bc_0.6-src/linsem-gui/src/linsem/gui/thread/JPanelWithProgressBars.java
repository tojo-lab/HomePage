package linsem.gui.thread;

import javax.swing.JLabel;
import javax.swing.JProgressBar;

public interface JPanelWithProgressBars {
	public JProgressBar getMianBar();
	public JLabel getMainTimeLabel();
	public JProgressBar getSubBar();
	public JLabel getSubTimeLabel();
}
