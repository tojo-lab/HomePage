package linsem.gui.table;

import javax.swing.JTable;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

public class MatrixTable extends JTable{
	
	public void stopCellEditing(){
		if(isEditing())
			getCellEditor().stopCellEditing();		
	}

	public void clearTable(){
		stopCellEditing();
		TableModel model = getModel();
		if(model instanceof MatrixTableModel){
			((MatrixTableModel)model).reset();
		}
		revalidate();			
	}
	
	public JTableHeader getTableColumnHeader(){
		return getTableHeader();
	}
	
	public RowHeaderList getTableRowHeader(){
		TableModel model = getModel();
		if(model instanceof MatrixTableModel){
			return new RowHeaderList(((MatrixTableModel)model).getRowListModel(), this);
		}else{
			return null;
		}
	}
	
}
