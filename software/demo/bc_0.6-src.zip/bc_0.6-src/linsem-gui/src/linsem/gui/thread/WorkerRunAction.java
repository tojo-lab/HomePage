package linsem.gui.thread;

import java.awt.event.ActionEvent;
import java.util.Objects;
import java.util.concurrent.ExecutorService;

import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public 	class WorkerRunAction extends AbstractAction implements ChangeListener{

	protected JComponent parent;
	protected String caption;
	protected ExecutorService executor;
	protected SimpleWorker worker;
	protected boolean multi_thread_flag;
	protected boolean verbose_flag;
	
	public WorkerRunAction(JComponent parent, String caption, ExecutorService executor){
		super("run");
		this.parent  = parent;
		this.caption = caption;
		this.executor = executor;
		this.multi_thread_flag = true;
		this.verbose_flag = true;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		doAction();
	}
	
	@Override
	public void stateChanged(ChangeEvent e) {
		doAction();
	}
	
	protected void doAction(){
		SimpleProgressPanel progress_panel = newProgressPanel();
		parent.add(progress_panel);
		
		//Install listeners
		worker = newSimpleWorker(progress_panel);
		worker.setVerbose(this.verbose_flag);
		progress_panel.pause_button.addActionListener(new WorkerPauseAction(worker));
		progress_panel.cancel_button.addActionListener(new WorkerCancelAction(worker));
		worker.addPropertyChangeListener(newPropertyChangeListener(progress_panel));
		
		if(Objects.nonNull(executor) && multi_thread_flag){
			if(this.verbose_flag) { System.out.println("Submit task: " + caption + "(serial execution)"); }
			executor.submit(worker);
		}else{
			if(this.verbose_flag) { System.out.println("Execute task: " + caption); }
			worker.execute();
			//worker.doInBackground();
			//NOTE: 
			//If we call following doInBackground method directly, then the method will be processed by Event dispatch thread.
			//However, due to some multi-thread issue, it does not work correctly.
		}
		parent.getRootPane().revalidate();
	}
	
	protected SimpleProgressPanel newProgressPanel(){
		return new SimpleProgressPanel(caption);
	}
	
	protected SimpleWorker newSimpleWorker(JComponent progress_panel){
		return new SimpleWorker(progress_panel, parent);
	}
	
	protected ProgressListener newPropertyChangeListener(JPanelWithProgressBars progress_panel){
		return new ProgressListener(progress_panel.getMianBar(), progress_panel.getMainTimeLabel());
	}

	public void setMultiThreadExecution(boolean b){
		this.multi_thread_flag = b;
	}
	
	public boolean isMultiThreaded(){
		return this.multi_thread_flag;
	}
	
	public void setVerbose(boolean b){
		//System.out.println("verbose option changed#" + caption + ": " + b);
		this.verbose_flag = b;
	}
	
	public boolean isVerbose(){
		return this.verbose_flag;
	}
}
