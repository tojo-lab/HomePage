package linsem.gui.thread;

import java.awt.event.ActionEvent;
import java.util.Objects;

import javax.swing.AbstractAction;
import javax.swing.JButton;

public 	class WorkerPauseAction extends AbstractAction{
	
	protected SimpleWorker worker;
	
	public WorkerPauseAction(SimpleWorker worker){
		super("pause");
		this.worker = worker;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton)e.getSource();
		if(Objects.nonNull(worker)){
			btn.setText(worker.isCancelled() || worker.isPaused() ? "pause" : "resume");				
			worker.pause();
		}else{
			btn.setText("pause");
		}	
	}
}		
