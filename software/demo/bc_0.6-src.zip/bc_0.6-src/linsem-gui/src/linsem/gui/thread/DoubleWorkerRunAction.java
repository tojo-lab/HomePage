package linsem.gui.thread;

import java.util.concurrent.ExecutorService;

import javax.swing.JComponent;

public 	class DoubleWorkerRunAction extends WorkerRunAction{
	
	public DoubleWorkerRunAction(JComponent parent, String caption, ExecutorService executor) {
		super(parent, caption, executor);
	}
	
	@Override
	protected SimpleProgressPanel newProgressPanel(){
		return new DoubleProgressPanel(caption);
	}
	
	@Override
	protected SimpleWorker newSimpleWorker(JComponent progress_panel){
		return new DoubleWorker(progress_panel, parent);
	}
	
	@Override
	protected ProgressListener newPropertyChangeListener(JPanelWithProgressBars progress_panel){
		return new DoubleProgressListener(progress_panel.getMianBar(), progress_panel.getSubBar(), progress_panel.getMainTimeLabel(), progress_panel.getSubTimeLabel());
	}
}	
