package linsem.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;

import linsem.gui.table.MatrixTable;
import linsem.gui.table.MatrixTableModel;


public class EditorPanel extends JPanel {

	private static final long serialVersionUID = 1551203646278150873L;
	
	//GUI components
	protected JPanel toolBar_panel 		= null;
	protected JPanel world_panel 		= null;
	protected JPanel agent_panel 		= null;
	protected JPanel relation_panel 	= null;
	protected JPanel channel_panel 		= null;
	protected JPanel valuation_panel 	= null;
	
	//Tool bars
	protected JToolBar model_toolBar    = null;
	protected JToolBar relation_toolBar = null;
	protected JToolBar channel_toolBar  = null;
	protected JToolBar valuation_toolBar= null;

	//for Kripke model
	protected JSpinner world_spinner   	= null;
	protected JSpinner agent_spinner   	= null;
	protected JSpinner channel_spinner 	= null;
	protected JSpinner proposition_spinner = null;
	
	protected MatrixTable relation_table 	= null;
	protected MatrixTable channel_table  	= null;
	protected MatrixTable valuation_table	= null;

	protected Map<Integer, MatrixTableModel> relation_map	= null;
	protected Map<Integer, MatrixTableModel> channel_map  	= null;
	
	//for table headers
	JScrollPane relation_scrollpane = null;
	JScrollPane channel_scrollpane  = null;
	JScrollPane valuation_scrollpane = null;
	
	//for table model selector
	protected JComboBox<Integer> relation_comboBox 	= null;
	protected JComboBox<Integer> channel_comboBox 	= null;
	
	//for model generate buttons
	protected JButton random_frame_button 	= null;
	protected JButton random_model_button 	= null;
	protected JButton reflexive_button 		= null;
	protected JButton symmetric_button 		= null;
	protected JButton transitive_button		= null;
	protected JButton serial_button			= null;
	protected JButton euclidean_button		= null;
	protected JButton reset_button			= null;
	
	//for preferences
	protected int default_size = 5;
	protected static Color TopColor = new Color(220, 220, 255); //Color.LIGHT_GRAY
	protected static Color ErrColor = Color.PINK;
	protected static Color FocusColor = Color.LIGHT_GRAY;
 

	public EditorPanel() {}
	
	public void initPanel(){
		setPreferredSize(new Dimension(480, 640));
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setTitle("<html><h3>Kripke Model</h3></html>");

		add(getToolbarPanel());
		add(getWorldPanel());
		add(getAgentPanel());
		add(getRelationPanel());
		add(getChannelPanel());
		add(getValuationPanel());		
	}

	public void setTitle(String title) {
		setBorder(new TitledBorder(null, title, TitledBorder.LEADING,
				TitledBorder.TOP, null, null));
	}
	
	public JPanel getToolbarPanel(){
		if (toolBar_panel == null){
			toolBar_panel = new JPanel();
			toolBar_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			toolBar_panel.setAlignmentY(Component.TOP_ALIGNMENT);
			FlowLayout flowLayout = (FlowLayout) toolBar_panel.getLayout();
			flowLayout.setAlignment(FlowLayout.LEFT);
			
			model_toolBar = new JToolBar();
			model_toolBar.setOrientation(SwingConstants.HORIZONTAL);
			toolBar_panel.add(model_toolBar);
			
			random_model_button = newDefaultButton(model_toolBar, "<html><b>Rand<sub>M</sub></b></html>", "Generate random model");
			random_frame_button = newDefaultButton(model_toolBar, "<html><b>Rand<sub>F</sub></b></html>", "Generate random frame");
			reflexive_button = newDefaultButton(model_toolBar, "<html><b>Refl<sub>F</sub></b></html>", "Generate reflexive frame");
			symmetric_button = newDefaultButton(model_toolBar, "<html><b>Sym<sub>F</sub></b></html>", "Generate symmetric frame");
			transitive_button = newDefaultButton(model_toolBar, "<html><b>Tran<sub>F</sub></b></html>", "Generate transitive frame");
			serial_button = newDefaultButton(model_toolBar, "<html><b>Seri<sub>F</sub></b></html>", "Generate serial frame");
			euclidean_button = newDefaultButton(model_toolBar, "<html><b>Eucli<sub>F</sub></b></html>", "Generate Euclidean frame");
			
			//TODO: if actions for these buttons are implemented, this should be shown.
			transitive_button.setVisible(false);
			serial_button.setVisible(false);
			euclidean_button.setVisible(false);
			
			reset_button = newDefaultButton(model_toolBar, "<html><b>Reset</b></html>", "Reset model");	
		}	
		return toolBar_panel;
	}
	
	public JPanel getWorldPanel() {
		if (world_panel == null) {
			world_panel = new JPanel();
			world_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			world_panel.setAlignmentY(Component.TOP_ALIGNMENT);
			FlowLayout flowLayout = (FlowLayout) world_panel.getLayout();
			flowLayout.setAlignment(FlowLayout.LEFT);

			JLabel label = new JLabel("<html><h4>Worlds(W) :</h4></html>");
			world_panel.add(label);			
			JLabel spinner_label = new JLabel("Number of worlds(#W)");
			world_panel.add(spinner_label);

			world_spinner = newDefaultSpinner(world_panel);
		}
		return world_panel;
	}

	public JPanel getAgentPanel() {
		if (agent_panel == null) {
			agent_panel = new JPanel();
			agent_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			agent_panel.setAlignmentY(Component.TOP_ALIGNMENT);
			FlowLayout flowLayout = (FlowLayout) agent_panel.getLayout();
			flowLayout.setAlignment(FlowLayout.LEFT);

			JLabel label = new JLabel("<html><h4>Agents(G) :</h4></html>");
			agent_panel.add(label);
			JLabel spinner_label = new JLabel("Number of agents(#G)");
			agent_panel.add(spinner_label);

			agent_spinner = newDefaultSpinner(agent_panel);
		}
		return agent_panel;
	}

	public JPanel getRelationPanel() {
		if (relation_panel == null) {
			relation_panel = new JPanel();
			relation_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			relation_panel.setAlignmentY(Component.TOP_ALIGNMENT);
			relation_panel.setLayout(new BorderLayout(0, 0));			

			JPanel panel = new JPanel();
			relation_panel.add(panel, BorderLayout.NORTH);
			panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			panel.setAlignmentY(Component.TOP_ALIGNMENT);
			FlowLayout flowLayout = (FlowLayout) panel.getLayout();			
			flowLayout.setAlignment(FlowLayout.LEFT);			
			
			JLabel label = new JLabel("<html><h4>Relations(R<sub>a</sub>)<sub>a &isin; G</sub> :</h4></html>");
			panel.add(label);

			JLabel combo_label = new JLabel("agent id");
			panel.add(combo_label);
			relation_comboBox = new JComboBox<Integer>();
			panel.add(relation_comboBox);
			
			relation_map = new HashMap<Integer, MatrixTableModel>();
			relation_table = newDefaultTable();			
			relation_table.setDefaultRenderer(Object.class, new CellRenderer());
			relation_scrollpane = new JScrollPane();
			relation_scrollpane.setViewportView(relation_table);
			relation_panel.add(relation_scrollpane, BorderLayout.CENTER);
			
			relation_toolBar = new JToolBar();
			panel.add(relation_toolBar);
			relation_toolBar.add(newTableDiaglnalizeButton("<html><b>E</b></html>", relation_table));
			relation_toolBar.add(newTableZerosButton("<html><b>0</b></html>", relation_table));
			relation_toolBar.add(newTableOnesButton("<html><b>1</b></html>", relation_table));
			relation_toolBar.add(newTableRandomsButton("<html><b>Rand<sub>R</sub></b></html>", relation_table));
		}
		return relation_panel;
	}

	public JPanel getChannelPanel() {
		if (channel_panel == null) {
			channel_panel = new JPanel();
			channel_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			channel_panel.setAlignmentY(Component.TOP_ALIGNMENT);
			channel_panel.setLayout(new BorderLayout(0, 0));

			JPanel panel = new JPanel();
			channel_panel.add(panel, BorderLayout.NORTH);
			panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			panel.setAlignmentY(Component.TOP_ALIGNMENT);
			FlowLayout flowLayout = (FlowLayout) panel.getLayout();			
			flowLayout.setAlignment(FlowLayout.LEFT);		

			JLabel label = new JLabel("<html><h4>Channels(C<sub>ab</sub>)<sub>a,b &isin; G</sub> :</h4></html>");
			panel.add(label);

			JLabel combo_label = new JLabel("world id");
			panel.add(combo_label);
			channel_comboBox = new JComboBox<Integer>();			
			panel.add(channel_comboBox);

			channel_map   = new HashMap<Integer, MatrixTableModel>();
			channel_table = newDefaultTable();			
			channel_table.setDefaultRenderer(Object.class, new CellRenderer());
			channel_scrollpane = new JScrollPane();
			channel_scrollpane.setViewportView(channel_table);			
			channel_panel.add(channel_scrollpane, BorderLayout.CENTER);
			
			channel_toolBar = new JToolBar();
			panel.add(channel_toolBar);
			channel_toolBar.add(newTableDiaglnalizeButton("<html><b>E</b></html>", channel_table));
			channel_toolBar.add(newTableZerosButton("<html><b>0</b></html>", channel_table));
			channel_toolBar.add(newTableOnesButton("<html><b>1</b></html>", channel_table));
			channel_toolBar.add(newTableRandomsButton("<html><b>Rand<sub>C</sub></b></html>", channel_table));
		}
		return channel_panel;
	}

	public JPanel getValuationPanel() {
		if (valuation_panel == null) {
			valuation_panel = new JPanel();
			valuation_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			valuation_panel.setAlignmentY(Component.TOP_ALIGNMENT);
			valuation_panel.setLayout(new BorderLayout(0, 0));

			JPanel panel = new JPanel();
			valuation_panel.add(panel, BorderLayout.NORTH);
			panel.setAlignmentX(Component.LEFT_ALIGNMENT);
			panel.setAlignmentY(Component.TOP_ALIGNMENT);
			FlowLayout flowLayout = (FlowLayout) panel.getLayout();			
			flowLayout.setAlignment(FlowLayout.LEFT);		

			JLabel label = new JLabel("<html><h4>Valuations(V) :</h4></html>");
			panel.add(label);
			JLabel spinner_label = new JLabel("Number of propositions(#Prop)");
			panel.add(spinner_label);

			proposition_spinner = newDefaultSpinner(panel);

			valuation_table = newDefaultTable();
			valuation_table.setDefaultRenderer(Object.class, new CellRenderer());
			valuation_scrollpane = new JScrollPane(); 
			valuation_scrollpane.setViewportView(valuation_table);
			valuation_panel.add(valuation_scrollpane, BorderLayout.CENTER);
			
			valuation_toolBar = new JToolBar();
			panel.add(valuation_toolBar);
			valuation_toolBar.add(newTableDiaglnalizeButton("<html><b>E</b></html>", valuation_table));
			valuation_toolBar.add(newTableZerosButton("<html><b>0</b></html>", valuation_table));
			valuation_toolBar.add(newTableOnesButton("<html><b>1</b></html>", valuation_table));
			valuation_toolBar.add(newTableRandomsButton("<html><b>Rand<sub>V</sub></b></html>", valuation_table));
		}
		return valuation_panel;
	}	
	
	public JButton newDefaultButton(JComponent parent, String caption, String toolTip){
		JButton button = new JButton(caption);
		button.setToolTipText(toolTip);
		//button.addActionListener(action);
		parent.add(button);
		Dimension d = parent.getMaximumSize();
		d.width = 45;
		button.setMaximumSize(d);
		return button;
	}
	
	public JSpinner newDefaultSpinner(JComponent parent){
		JSpinner spinner = new JSpinner();
		parent.add(spinner);
		SpinnerNumberModel model = new SpinnerNumberModel(new Integer(default_size), new Integer(1), null, new Integer(1));
		spinner.setModel(model);
		
		Dimension d = new Dimension(45, 20);
		spinner.setPreferredSize(d);
		
		return spinner;
	}
	
	public MatrixTable newDefaultTable(){
		final MatrixTable table = new MatrixTable() {
			@Override
			public String getToolTipText(MouseEvent e) {
				int row = rowAtPoint(e.getPoint());
				int col = columnAtPoint(e.getPoint());
				String tooltip = "from " + col + " to " + row + " value=" + this.getModel().getValueAt(row, col);
				return tooltip;
			}
		};
		table.setCellSelectionEnabled(true);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getTableHeader().setReorderingAllowed(false); //prohibit column exchange
		table.addFocusListener(new FocusAdapter(){
			public void focusLost(FocusEvent inEvent) { table.stopCellEditing(); }
		});
		
		return table;
	}
	
	public JButton newTableDiaglnalizeButton(String caption, final MatrixTable table){
		JButton button = new JButton(caption);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				TableModel model = table.getModel();
				System.err.println("current model -> " + model.toString());
				if(model instanceof MatrixTableModel){
					((MatrixTableModel)model).diagonalize();
					System.err.println("rel1 -> " + relation_map.get(1).toString());
				}
			}
			
		});
		return button;
	}
	
	public JButton newTableZerosButton(String caption, final MatrixTable table){
		JButton button = new JButton(caption);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				TableModel model = table.getModel();
				if(model instanceof MatrixTableModel){
					((MatrixTableModel)model).zeros();
				}
			}
			
		});
		return button;
	}
	
	public JButton newTableOnesButton(String caption, final MatrixTable table){
		JButton button = new JButton(caption);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				TableModel model = table.getModel();
				if(model instanceof MatrixTableModel){
					((MatrixTableModel)model).ones();
				}
			}
			
		});
		return button;
	}

	public JButton newTableRandomsButton(String caption, final MatrixTable table){
		JButton button = new JButton(caption);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				TableModel model = table.getModel();
				if(model instanceof MatrixTableModel){
					((MatrixTableModel)model).fillTableRandom();
				}
			}
			
		});
		return button;
	}
	
	class CellRenderer extends DefaultTableCellRenderer {
		
		private static final long serialVersionUID = 1L;

		public CellRenderer(){
			super();
		}
		
		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col) {
			super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
						        
			try{
				Object obj = table.getValueAt(row, col); 
				if(obj != null){
					int val = Integer.parseInt(obj.toString());
					switch(val){
					case 0:
						this.setBackground(table.getBackground());
						break;
					case 1: 
						this.setBackground(TopColor);
						break;
					default:
						this.setBackground(ErrColor);	
						break;
					}					
				}else{
					this.setBackground(ErrColor);
				}
			}
			catch(NumberFormatException ne){this.setBackground(ErrColor);}
			catch(ArrayIndexOutOfBoundsException ne){ ne.printStackTrace(); System.err.println("from CellRenderer"); }
	        
	        if(hasFocus) {
	            this.setBackground(FocusColor);
	        }
			return this; 
		}
		
	}
	
}
