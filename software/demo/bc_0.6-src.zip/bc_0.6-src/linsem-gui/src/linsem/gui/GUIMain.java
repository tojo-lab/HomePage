package linsem.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.KeyStroke;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import linsem.CUIMain;
import linsem.ast.AST;
import linsem.ast.StmtNode;
import linsem.gui.table.MatrixTable;
import linsem.gui.table.MatrixTableModel;
import linsem.gui.table.ModelChangeAction;
import linsem.gui.table.RowHeaderList;
import linsem.gui.thread.DoubleWorker;
import linsem.gui.thread.DoubleWorkerRunAction;
import linsem.gui.thread.SimpleWorker;
import linsem.gui.thread.WorkerRunAction;
import linsem.model.ChanneledKripkeModel;
import linsem.model.UJMPKripkeModel;
import linsem.parser.CalcVisitor;
import linsem.parser.ErrorHandler;
import linsem.parser.ParseException;
import linsem.parser.Parser;
import linsem.parser.TokenMgrError;
import linsem.util.IOUtil;
import linsem.util.SimpleModelManager;
import linsem.util.UJMPUtil;

import org.ujmp.core.matrix.SparseMatrix;

public class GUIMain extends JFrame {

	//Software identifier
	public static final String ID = "Belief Calculator";
	public static final double VERSION = CUIMain.version;
	private static final long serialVersionUID = 2271255134589658827L;
	
	//Main GUI components
	protected JPanel contentPane		 = null;
	protected EditorPanel editor_panel   = null;
	protected CalcPanel calc_panel 	= null;
	protected JMenuBar menuBar 		= null;
	protected JTextField status_bar = null;

	//for menu bar
	protected JMenuItem save_item 	= null;
	protected JMenuItem save_as_item= null;
	protected JMenuItem load_item   = null;
	protected JMenuItem open_dot_dir_item        = null;
	protected JMenuItem calc_truth_set_item 	 = null;
	protected JMenuItem calc_frame_property_item = null;
	protected JMenuItem viz_item 	= null;
	protected JMenuItem copy_item 	= null;
	protected JMenuItem new_model_item = null;
	protected JMenuItem random_frame_item = null;
	protected JMenuItem random_model_item = null;
	protected JMenuItem reflexive_item = null;
	protected JMenuItem symmetric_item = null;
	protected JMenuItem transitive_item  = null;
	protected JMenuItem serial_item    = null;
	protected JMenuItem euclidean_item = null;
	protected JMenuItem identity_model_item  = null;
	
	//for save/load
	protected static final String EXT_SIMPLE = "txt";
	protected File file = null;

	//for truth set calculator 
	protected ErrorHandler errHandler;	
	protected String last_formula = "";
	protected JCheckBoxMenuItem show_model_size_edit_item;
	protected JCheckBoxMenuItem show_model_item;
	protected JCheckBoxMenuItem verbose_item;
	protected JCheckBoxMenuItem show_ast_item;
	
	//for frame property checker
	protected JCheckBoxMenuItem reflexivity_item;
	protected JCheckBoxMenuItem symmetricity_item;
	protected JCheckBoxMenuItem transitivity_item;
	protected JCheckBoxMenuItem seriality_item;
	protected JCheckBoxMenuItem euclidianness_item;
	
	//for background execution
	protected JCheckBoxMenuItem bg_model_size_edit_item;
	protected JCheckBoxMenuItem bg_model_generation_item;
	protected JCheckBoxMenuItem bg_calc_item;
	protected JCheckBoxMenuItem bg_viz_item;

	//for edit actions
	protected WorkerRunAction relation_world_spinner_change_action;
	protected WorkerRunAction relation_agent_spinner_change_action;
	protected WorkerRunAction channel_agent_spinner_change_action;
	protected WorkerRunAction channel_world_spinner_change_action;
	protected WorkerRunAction proposition_world_spinner_change_action;
	protected WorkerRunAction proposition_proposition_spinner_change_action;
	
	//for shared actions
	protected ActionListener copy_action;
	protected ActionListener clear_action;
	protected ActionListener help_action;
	
	protected WorkerRunAction save_action;
	protected WorkerRunAction save_as_action;
	protected WorkerRunAction load_action;
	protected WorkerRunAction open_dot_dir_action;
	
	protected WorkerRunAction new_model_action;
	protected WorkerRunAction random_frame_action; 
	protected WorkerRunAction random_model_action; 
	protected WorkerRunAction identity_model_action; 
	protected WorkerRunAction reflexive_frame_action; 
	protected WorkerRunAction symmetric_frame_action;
	protected WorkerRunAction transitive_frame_action;
	protected WorkerRunAction serial_frame_action;
	protected WorkerRunAction euclidean_frame_action;
	
	protected WorkerRunAction calc_truth_set_action; 
	protected WorkerRunAction calc_frame_property_action; 
	protected WorkerRunAction viz_action; 
	
	//for Graphviz
	public static enum Layout {Auto, dot, circo, fdp, neato, osage, patchwork, twopi};
	protected Layout layout = Layout.Auto;
	protected String exec_path = "dot";
	protected int auto_threshold = 4;
	protected String graphviz_bin_path = ""; //This should be empty if there is a path to bin of Graphviz in `PATH'.
	protected String DOT_CPREFIX = "chl_w";
	protected String DOT_RPREFIX = "rel_a";
	protected String DOT_EXT = ".dot";
	protected String GRAPH_EXT = ".png";
	protected static String separator;
	protected static String crlf;
	protected final String DEFAULT_OUTPUT_DIR = "." + separator + "dot";
	protected String output_dir = DEFAULT_OUTPUT_DIR;
	protected JCheckBoxMenuItem open_graph_item = null;
	protected boolean isOpen = true;
	
	//for model generator
	public static enum GenModelMode {NewModel, RandomModel, RandomFrame, ReflexiveFrame, SymmetricFrame, TransitiveFrame, SerialFrame, EuclideanFrame, IdentityModel};
	
	//for preferences
	protected int gui_width		= 1200;
	protected int gui_height	= 960;
	protected String agent_prefix		= "a";
	protected String world_prefix		= "w";
	protected String proposition_prefix = "p";
	protected String delimiter			= "_";
	protected static int DELAY	= 10;
	//protected boolean showModelSizeEdit = false;
	protected boolean showModel = true;
	protected boolean isVerbose = true;
	protected boolean showAST   = true;
	
	//for background scheduler
	protected ExecutorService executor = null;
	
	static{
		 try{ separator = System.getProperty("file.separator");}catch(SecurityException e){ separator = "\\"; }
		 try{ crlf = System.getProperty("line.separator"); }catch(SecurityException e){ crlf = "\r\n"; }
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) { 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					GUIMain frame = new GUIMain();
					frame.initFrame();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Initialize the frame.
	 */
	public GUIMain() {
	}
	
	public void initFrame(){
		//for scheduler
		this.executor = Executors.newSingleThreadExecutor();
		
		setTitle(ID + "(ver. " + VERSION + ")");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		ShutdownHandler handler = new ShutdownHandler(this);
		addWindowListener(handler); 
		
		setBounds(100, 100, gui_width, gui_height);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		//JScrollPane scrollPane = new JScrollPane();
		//contentPane.add(scrollPane, BorderLayout.CENTER);

		JPanel panel = new JPanel();
		//scrollPane.setViewportView(panel);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		// for model editor
		editor_panel = new EditorPanel();
		editor_panel.initPanel();
		editor_panel.setAlignmentY(Component.TOP_ALIGNMENT);
		editor_panel.setLayout(new BoxLayout(editor_panel, BoxLayout.Y_AXIS));	
		
		// for control panel and outputs
		calc_panel = new CalcPanel();
		calc_panel.initPanel();
		calc_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
		calc_panel.setAlignmentY(Component.TOP_ALIGNMENT);
		
		JSplitPane splitPane = new JSplitPane();
		splitPane.setOneTouchExpandable(true);
		splitPane.setDividerSize(8);
		splitPane.setLeftComponent(editor_panel);
		splitPane.setRightComponent(calc_panel);
		splitPane.setDividerLocation(520);
		panel.add(splitPane, BorderLayout.CENTER);
		
		status_bar = new JTextField();
		status_bar.setText("Ready.");
		status_bar.setEditable(false);
		contentPane.add(status_bar, BorderLayout.SOUTH);
		//status_bar.setColumns(10);
		
		//for menu bar
		contentPane.add(getMainMenuBar(), BorderLayout.NORTH);
		
		//inject event actions
		install_shared_listeners();
		
		//final processing before launching
		setVerboseForModelSizeEdit(show_model_size_edit_item.isSelected());
		setBackgroundExecutionsForModelSizeEdit(bg_model_size_edit_item.isSelected());	
		setBackgroundExecutionsForModelGeneration(bg_model_generation_item.isSelected());	
		setBackgroundExecutionsForCalculation(bg_calc_item.isSelected());	
		setBackgroundExecutionsForVisualization(bg_viz_item.isSelected());
	}
	
	public JMenuBar getMainMenuBar(){
		if(menuBar == null){
			menuBar = new JMenuBar();
			
			JMenu file_menu = new JMenu("File");
			//file_menu.setMnemonic(KeyEvent.VK_F);
			menuBar.add(file_menu);

			new_model_item = newDefaultItem("New", null);
			file_menu.add(new_model_item);
			
			save_item = newDefaultItem("Save", null, KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
			file_menu.add(save_item);

			save_as_item = newDefaultItem("Save As", null);
			file_menu.add(save_as_item);
			
			load_item = newDefaultItem("Load", null);
			file_menu.add(load_item);
			
			open_dot_dir_item = newDefaultItem("Open Viz. save dir", null);
			file_menu.add(open_dot_dir_item);			
			
			/*
			JMenu export_menu = new JMenu("Export");
			export_menu.setEnabled(false);
			file_menu.add(export_menu);
			
			export_menu.add(newDefaultItem("Tex", null)); 
			*/
					
			file_menu.add(newDefaultItem("Exit", new ShutdownHandler(this)));

			JMenu edit_menu = new JMenu("Edit");
			menuBar.add(edit_menu);
			
			copy_item = newDefaultItem("Copy (console)", null);
			edit_menu.add(copy_item); 
			
			JMenu gen_menu = new JMenu("Generate");
			edit_menu.add(gen_menu);

			random_frame_item = newDefaultItem("Random(frame)", null);
			gen_menu.add(random_frame_item);
			
			random_model_item = newDefaultItem("Random(model)", null); 
			gen_menu.add(random_model_item);
			
			reflexive_item = newDefaultItem("Reflexive frame", null);
			gen_menu.add(reflexive_item);
			
			symmetric_item = newDefaultItem("Symmetric frame", null);
			gen_menu.add(symmetric_item);
			
			//FIXME: if following buttons are implemented, they should be added to gen_menu.
			transitive_item = newDefaultItem("Transitive frame", null);
			serial_item     = newDefaultItem("Serial frame", null);
			euclidean_item  = newDefaultItem("Euclidean frame", null);
			
			identity_model_item = newDefaultItem("Reset", null);
			edit_menu.add(identity_model_item);
			
			JMenu view_menu = new JMenu("View");
			menuBar.add(view_menu);
			
			view_menu.add(newDefaultViewItem("Status bar", status_bar));		
			
			JMenu toolBar_menu = new JMenu("Tool bar");
			view_menu.add(toolBar_menu);
			
			toolBar_menu.add(newDefaultViewItem("Model", editor_panel.model_toolBar));			
			toolBar_menu.add(newDefaultViewItem("Relations", editor_panel.relation_toolBar));					
			toolBar_menu.add(newDefaultViewItem("Channels", editor_panel.channel_toolBar));					
			toolBar_menu.add(newDefaultViewItem("Valuations", editor_panel.valuation_toolBar));							
			toolBar_menu.add(newDefaultViewItem("Formula", calc_panel.formula_toolBar));
			toolBar_menu.add(newDefaultViewItem("Program term", calc_panel.program_toolBar));
			toolBar_menu.add(newDefaultViewItem("Modal axiom", calc_panel.modal_axiom_toolBar));
			
			JMenu editor_menu = new JMenu("Editor");
			view_menu.add(editor_menu);
			
			editor_menu.add(newDefaultViewItem("Worlds", editor_panel.world_panel));
			editor_menu.add(newDefaultViewItem("Agents", editor_panel.agent_panel));
			editor_menu.add(newDefaultViewItem("Relations", editor_panel.relation_panel));
			editor_menu.add(newDefaultViewItem("Channels", editor_panel.channel_panel));
			editor_menu.add(newDefaultViewItem("Valuations", editor_panel.valuation_panel));

			JMenu calc_menu = new JMenu("Calculator");
			view_menu.add(calc_menu);
			
			calc_menu.add(newDefaultViewItem("Helper buttons", calc_panel.toolbar_panel));
			calc_menu.add(newDefaultViewItem("Parameter", calc_panel.param_panel));
			calc_menu.add(newDefaultViewItem("Console", calc_panel.console_panel));
			calc_menu.add(newDefaultViewItem("Control", calc_panel.control_panel));
			
			JMenu run_menu = new JMenu("Run");
			menuBar.add(run_menu);
			
			calc_truth_set_item = newDefaultItem("Calculate truth set", null);
			run_menu.add(calc_truth_set_item);
			calc_frame_property_item = newDefaultItem("Check frame properties", null);
			run_menu.add(calc_frame_property_item);
			viz_item = newDefaultItem("Run Graphviz", null);
			run_menu.add(viz_item);
			
			JSeparator run_separator = new JSeparator();
			run_menu.add(run_separator);
			
			JMenu option_menu = new JMenu("Option");
			run_menu.add(option_menu);
			
			JMenu frame_prop_menu = new JMenu("Frame properties");
			option_menu.add(frame_prop_menu);
			
			reflexivity_item = new JCheckBoxMenuItem("Reflexivity(T)");
			reflexivity_item.setSelected(true);
			frame_prop_menu.add(reflexivity_item);
			
			symmetricity_item = new JCheckBoxMenuItem("Symmetricity(B)");
			symmetricity_item.setSelected(true);
			frame_prop_menu.add(symmetricity_item);
			
			transitivity_item = new JCheckBoxMenuItem("Transitivity(4)");
			transitivity_item.setSelected(true);
			frame_prop_menu.add(transitivity_item);
			
			seriality_item = new JCheckBoxMenuItem("Seriality(D)");
			seriality_item.setSelected(true);
			frame_prop_menu.add(seriality_item);
			
			euclidianness_item = new JCheckBoxMenuItem("Euclidianness(5)");
			euclidianness_item.setSelected(true);
			frame_prop_menu.add(euclidianness_item);
			
			JMenu layout_option_menu = new JMenu("Layout algorithm");
			option_menu.add(layout_option_menu);
			
			final JRadioButtonMenuItem auto_item = new JRadioButtonMenuItem("Auto select");
			auto_item.setSelected(true);
			auto_item.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					if(auto_item.isSelected()){ layout = Layout.Auto; }
				}
				
			});
			layout_option_menu.add(auto_item);
			
			final JRadioButtonMenuItem dot_item = new JRadioButtonMenuItem("dot");
			dot_item.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					if(dot_item.isSelected()){ layout = Layout.dot; }
				}
				
			});
			layout_option_menu.add(dot_item);
			
			final JRadioButtonMenuItem circo_item = new JRadioButtonMenuItem("circo");
			circo_item.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					if(circo_item.isSelected()){ layout = Layout.circo; }
				}
				
			});
			layout_option_menu.add(circo_item);

			final JRadioButtonMenuItem fdp_item = new JRadioButtonMenuItem("fdp");
			fdp_item.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					if(fdp_item.isSelected()){ layout = Layout.fdp; }
				}
				
			});
			layout_option_menu.add(fdp_item);		

			final JRadioButtonMenuItem neato_item = new JRadioButtonMenuItem("neato");
			neato_item.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					if(neato_item.isSelected()){ layout = Layout.neato; }
				}
				
			});
			layout_option_menu.add(neato_item);		

			final JRadioButtonMenuItem osage_item = new JRadioButtonMenuItem("osage");
			osage_item.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					if(osage_item.isSelected()){ layout = Layout.osage; }
				}
				
			});
			layout_option_menu.add(osage_item);		
			
			final JRadioButtonMenuItem patchwork_item = new JRadioButtonMenuItem("patchwork");
			patchwork_item.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					if(patchwork_item.isSelected()){ layout = Layout.patchwork; }
				}
				
			});
			layout_option_menu.add(patchwork_item);		
			
			final JRadioButtonMenuItem twopi_item = new JRadioButtonMenuItem("twopi");
			twopi_item.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent e) {
					if(twopi_item.isSelected()){ layout = Layout.twopi; }
				}
				
			});
			layout_option_menu.add(twopi_item);		
			
			ButtonGroup group = new ButtonGroup();
			group.add(auto_item);
			group.add(dot_item);
			group.add(circo_item);
			group.add(fdp_item);
			group.add(neato_item);
			group.add(osage_item);
			group.add(patchwork_item);
			group.add(twopi_item);
			
			JMenu bg_execution_menu = new JMenu("Use serial execution manager");
			option_menu.add(bg_execution_menu);
			
			bg_model_size_edit_item = new JCheckBoxMenuItem("Model size changing");
			bg_model_size_edit_item.setSelected(false);
			bg_model_size_edit_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { 
					setBackgroundExecutionsForModelSizeEdit(bg_model_size_edit_item.isSelected());					
				}
			});		
			bg_execution_menu.add(bg_model_size_edit_item);
			
			bg_model_generation_item = new JCheckBoxMenuItem("Model/frame generation");
			bg_model_generation_item.setSelected(true);
			bg_model_generation_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { 
					setBackgroundExecutionsForModelGeneration(bg_model_generation_item.isSelected());					
				}
			});		
			bg_execution_menu.add(bg_model_generation_item);
			
			bg_calc_item = new JCheckBoxMenuItem("calculation");
			bg_calc_item.setSelected(true);
			bg_calc_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { 
					setBackgroundExecutionsForCalculation(bg_calc_item.isSelected());					
				}
			});		
			bg_execution_menu.add(bg_calc_item);

			bg_viz_item = new JCheckBoxMenuItem("visualization");
			bg_viz_item.setSelected(true);
			bg_viz_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { 
					setBackgroundExecutionsForVisualization(bg_viz_item.isSelected());					
				}
			});		
			bg_execution_menu.add(bg_viz_item);
			
			JMenu execution_log_menu = new JMenu("Execution log");
			option_menu.add(execution_log_menu);
			
			show_model_size_edit_item = new JCheckBoxMenuItem("Show log of model size editting");
			show_model_size_edit_item.setSelected(false);
			execution_log_menu.add(show_model_size_edit_item);
			show_model_size_edit_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { 
					setVerboseForModelSizeEdit(show_model_size_edit_item.isSelected());
				}
			});		
			
			show_model_item = newDefaultCheckBoxItem("Show model before calc truth set");
			execution_log_menu.add(show_model_item);
			show_model_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { showModel = show_model_item.isSelected(); }
			});

			verbose_item = newDefaultCheckBoxItem("Show intermediate process of calc truth set");
			execution_log_menu.add(verbose_item);
			verbose_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { isVerbose = verbose_item.isSelected(); }
			});
						
			show_ast_item = newDefaultCheckBoxItem("Show ast dump before calc truth set");
			execution_log_menu.add(show_ast_item);
			show_ast_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { showAST = show_ast_item.isSelected(); }
			});
			
			open_graph_item = newDefaultCheckBoxItem("Open graph file after Viz. execution");
			option_menu.add(open_graph_item);
			open_graph_item.addActionListener( new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) { isOpen = open_graph_item.isSelected(); }
			});
			
			
			JMenu help_menu = new JMenu("Help");
			menuBar.add(help_menu);
			
			JMenuItem help_item = new JMenuItem("Help");
			help_item.addActionListener(new HelpAction());
			help_menu.add(help_item);
			
			JMenuItem about_item = new JMenuItem("About");
			about_item.addActionListener(new AboutDialogAction(this));
			help_menu.add(about_item);
		}
		return menuBar;
	}
	
	public JMenuItem newDefaultItem(String caption, ActionListener listener){
		JMenuItem item = new JMenuItem(caption);
		item.addActionListener(listener);
		return item;
	}
	
	public JMenuItem newDefaultItem(String caption, ActionListener listener, KeyStroke stroke){
		JMenuItem item = newDefaultItem(caption, listener);
		item.setAccelerator(stroke);
		return item;
	}
	
	public JCheckBoxMenuItem newDefaultCheckBoxItem(String caption){
		JCheckBoxMenuItem item = new JCheckBoxMenuItem(caption);
		item.setSelected(true);
		return item;
	}
	
	public JCheckBoxMenuItem newDefaultViewItem(String caption, final JComponent target){
		final JCheckBoxMenuItem item = newDefaultCheckBoxItem(caption);
		item.addActionListener( new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) { target.setVisible(item.isSelected()); }
		});
		return item;
	}
	
	public JFileChooser newDefaultFileChooser(){
		String path = ".";
		if(file != null) path = file.getPath();
		JFileChooser chooser = new JFileChooser(path);
		FileFilter filter = new FileNameExtensionFilter("text file", EXT_SIMPLE);
		chooser.addChoosableFileFilter(filter);
		chooser.setAcceptAllFileFilterUsed(false);
		return chooser;
	}
	
	public void install_shared_listeners(){
		init_shared_actions();
		install_menu_item_listeners();
		install_editor_panel_listeners();
		install_calc_panel_listeners();
	}
	
	protected void init_shared_actions(){
		JComponent progress_panel = calc_panel.progress_panel;
		JTextArea area = calc_panel.stream_area;
		JTextField command_field = calc_panel.command_field;
		
		save_action 			= new SaveAction(progress_panel, "save", executor, false);
		save_as_action 			= new SaveAction(progress_panel, "save", executor, true);
		load_action 			= new LoadAction(progress_panel, "load", executor, this);
		open_dot_dir_action		= new OpenDotDirAction(progress_panel, "open output save directory", executor);
		
		copy_action 			= new CopyAction(area, command_field);
		clear_action			= new ClearAction(area, command_field);
		help_action				= new HelpAction();

		new_model_action   		= new ModelGenerateAction(progress_panel, "gen new model", executor, GenModelMode.NewModel);
		random_frame_action 	= new ModelGenerateAction(progress_panel, "gen random frame", executor, GenModelMode.RandomFrame);
		random_model_action 	= new ModelGenerateAction(progress_panel, "gen random model", executor, GenModelMode.RandomModel);
		identity_model_action  	= new ModelGenerateAction(progress_panel, "gen identity model", executor, GenModelMode.IdentityModel);
		reflexive_frame_action 	= new ModelGenerateAction(progress_panel, "gen reflexive frame", executor, GenModelMode.ReflexiveFrame);
		symmetric_frame_action 	= new ModelGenerateAction(progress_panel, "gen symmetric frame", executor, GenModelMode.SymmetricFrame);
		transitive_frame_action = new ModelGenerateAction(progress_panel, "gen transitive frame", executor, GenModelMode.TransitiveFrame);
		serial_frame_action 	= new ModelGenerateAction(progress_panel, "gen serial frame", executor, GenModelMode.SerialFrame); 
		euclidean_frame_action 	= new ModelGenerateAction(progress_panel, "gen Euclidean frame", executor, GenModelMode.EuclideanFrame);
		
		calc_truth_set_action 	= new CalcTruthSetAction(progress_panel, "calc truth set", executor, command_field);
		calc_frame_property_action = new CalcFramePropertyAction(progress_panel, "check frame property", executor, command_field);
		viz_action				= new VizAction(progress_panel, "run Graphviz", executor, command_field);
	}
	
	protected void install_menu_item_listeners(){
		//File menu
		new_model_item.addActionListener(new_model_action);
		save_item.addActionListener(save_action);
		save_as_item.addActionListener(save_as_action);
		load_item.addActionListener(load_action);
		open_dot_dir_item.addActionListener(open_dot_dir_action);
		
		//Edit menu
		copy_item.addActionListener(copy_action);
		random_frame_item.addActionListener(random_frame_action);
		random_model_item.addActionListener(random_model_action);
		identity_model_item.addActionListener(identity_model_action);
		reflexive_item.addActionListener(reflexive_frame_action);
		symmetric_item.addActionListener(symmetric_frame_action);
		
		//Run menu
		calc_truth_set_item.addActionListener(calc_truth_set_action);
		calc_frame_property_item.addActionListener(calc_frame_property_action);
		viz_item.addActionListener(viz_action);		
	}
	
	protected void install_editor_panel_listeners(){
		JSpinner world_spinner = editor_panel.world_spinner;
		JSpinner agent_spinner = editor_panel.agent_spinner;
		
		//World panel
		world_spinner.getModel().addChangeListener(new ModelChangeAction(this));
		
		//Agent panel
		agent_spinner.getModel().addChangeListener(new ModelChangeAction(this));
		
		//Relation panel
		install_relation_panel_listeners();
		
		//Channel panel
		install_channel_panel_listeners();
		
		//Valuation panel
		install_valuation_panel_listeners();
		
		//Tool bars 
		install_toolbar_listeners();
	}
	
	protected void install_relation_panel_listeners(){
		JSpinner world_spinner = editor_panel.world_spinner;
		JSpinner agent_spinner = editor_panel.agent_spinner;
		JComboBox<Integer> relation_comboBox = editor_panel.relation_comboBox;
		MatrixTable relation_table = editor_panel.relation_table;
		Map<Integer, MatrixTableModel> relation_map = editor_panel.relation_map;
		JScrollPane relation_scrollpane = editor_panel.relation_scrollpane;
		JComponent progress_panel = calc_panel.progress_panel;

		relation_comboBox.addActionListener(new ComboBoxChangeAction(relation_map, relation_table));
		setComboBoxModel(relation_comboBox, agent_spinner);
		agent_spinner.addChangeListener(new ComboBoxRenewAction(relation_comboBox));
		relation_table.addMouseListener(new CellMouseAction(relation_table));
		
		int world_size = (Integer) world_spinner.getValue();
		int agent_size = (Integer) agent_spinner.getValue();
		install_table_models(agent_size, relation_map, world_prefix + delimiter, world_prefix + delimiter, world_size, world_size, relation_table);
		install_table_headers(relation_scrollpane, relation_table);
		
		relation_world_spinner_change_action = new TableSizeFullChangeAction(progress_panel, "change world size (R)", executor, relation_scrollpane, world_spinner, relation_comboBox, relation_table, relation_map);
		relation_agent_spinner_change_action = new MapSizeChangeAction(progress_panel, "change agent size (R)", executor, agent_spinner, world_spinner, world_spinner, relation_map, agent_prefix + delimiter, agent_prefix + delimiter); 
		world_spinner.addChangeListener(relation_world_spinner_change_action);
		agent_spinner.addChangeListener(relation_agent_spinner_change_action);
	}
	
	protected void install_channel_panel_listeners(){
		JSpinner world_spinner = editor_panel.world_spinner;
		JSpinner agent_spinner = editor_panel.agent_spinner;
		JComboBox<Integer> channel_comboBox = editor_panel.channel_comboBox;
		MatrixTable channel_table = editor_panel.channel_table;
		Map<Integer, MatrixTableModel> channel_map = editor_panel.channel_map;
		JScrollPane channel_scrollpane = editor_panel.channel_scrollpane;	
		JComponent progress_panel = calc_panel.progress_panel;
		
		channel_comboBox.addActionListener(new ComboBoxChangeAction(channel_map, channel_table));
		setComboBoxModel(channel_comboBox, world_spinner);
		world_spinner.addChangeListener(new ComboBoxRenewAction(channel_comboBox));
		channel_table.addMouseListener(new CellMouseAction(channel_table));
		int agent_size = (Integer) agent_spinner.getValue();
		int world_size = (Integer) world_spinner.getValue();
		install_table_models(world_size, channel_map, agent_prefix + delimiter, agent_prefix + delimiter, agent_size, agent_size, channel_table);
		install_table_headers(channel_scrollpane, channel_table);
		
		channel_agent_spinner_change_action = new TableSizeFullChangeAction(progress_panel, "change agent size (C)", executor, channel_scrollpane, agent_spinner, channel_comboBox, channel_table, channel_map);
		channel_world_spinner_change_action = new MapSizeChangeAction(progress_panel, "change world size (C)", executor, world_spinner, agent_spinner, agent_spinner, channel_map, agent_prefix + delimiter, agent_prefix + delimiter);
		agent_spinner.addChangeListener(channel_agent_spinner_change_action);
		world_spinner.addChangeListener(channel_world_spinner_change_action);
	}
	
	protected void install_valuation_panel_listeners(){
		JSpinner world_spinner = editor_panel.world_spinner;
		JSpinner proposition_spinner = editor_panel.proposition_spinner;
		MatrixTable valuation_table = editor_panel.valuation_table;
		JScrollPane valuation_scrollpane = editor_panel.valuation_scrollpane;
		JComponent progress_panel = calc_panel.progress_panel;
		
		valuation_table.addMouseListener(new CellMouseAction(valuation_table));
		int proposition_size = (Integer) proposition_spinner.getValue();
		int world_size = (Integer) world_spinner.getValue();
		MatrixTableModel table_model = install_table_model(world_prefix + delimiter, proposition_prefix + delimiter, world_size, proposition_size, valuation_table, true);
		install_table_headers(valuation_scrollpane, valuation_table);
		
		proposition_world_spinner_change_action = new TableSizeHalfChangeAction(progress_panel, "change world size (V)", executor, valuation_scrollpane, world_spinner, proposition_spinner, valuation_table, table_model, false);
		proposition_proposition_spinner_change_action = new TableSizeHalfChangeAction(progress_panel, "change prop size (V)", executor, valuation_scrollpane, world_spinner, proposition_spinner, valuation_table, table_model, true); 
		world_spinner.addChangeListener(proposition_world_spinner_change_action);
		proposition_spinner.addChangeListener(proposition_proposition_spinner_change_action);
	}
	
	protected void install_table_models(int size, Map<Integer, MatrixTableModel> map, String row_header, String col_header, int row_size, int col_size, MatrixTable table){
		for(int i = 0; i < size; i++){
			MatrixTableModel table_model;
			table_model = install_table_model(row_header, col_header, row_size, col_size, table, i == 0);
			map.put(i+1, table_model);
		}
	}
	
	protected MatrixTableModel install_table_model(String row_header, String col_header, int row_size, int col_size, MatrixTable table, boolean setModel){
		MatrixTableModel table_model = MatrixTableModel.newInstance(row_header, col_header, row_size, col_size);
		table_model.addTableModelListener(new ModelChangeAction(this));
		if(setModel){ table.setModel(table_model); }
		return table_model;
	}
		
	protected void install_table_headers(JScrollPane scroll_pane, MatrixTable table){
		addRowHeader(scroll_pane, table);
		addColHeader(scroll_pane, table);
	}
	
	public void addColHeader(final JScrollPane scrollPane, MatrixTable table){
		JTableHeader colHeaders = table.getTableHeader();
		scrollPane.setColumnHeaderView(colHeaders);
		scrollPane.getColumnHeader().addChangeListener(new ChangeListener(){

			@Override
			public void stateChanged(ChangeEvent e) {
				JViewport viewport = (JViewport)e.getSource();
				scrollPane.getHorizontalScrollBar().setValue(viewport.getViewPosition().x);
			}
		});
	}
	
	public void addRowHeader(final JScrollPane scrollPane, MatrixTable table){
		RowHeaderList rowHeaders = table.getTableRowHeader();
		scrollPane.setRowHeaderView(rowHeaders);
		scrollPane.getRowHeader().addChangeListener(new ChangeListener(){

			@Override
			public void stateChanged(ChangeEvent e) {
				JViewport viewport = (JViewport)e.getSource();
				scrollPane.getVerticalScrollBar().setValue(viewport.getViewPosition().y);
			}
		});		
	}
	
	public Integer[] range(int begin, int end) {
		if (begin < end) {
			Integer[] arr = new Integer[end - begin];
			for (int i = 0; i + begin < end; i++) {
				arr[i] = i + begin;
			}
			return arr;
		}
		return null;
	}

	public Integer[] getSpinnerRange(JSpinner spinner) {
		int min = (Integer) ((SpinnerNumberModel) spinner.getModel())
				.getMinimum();
		int max = (Integer) ((SpinnerNumberModel) spinner.getModel())
				.getValue();
		Integer[] data = range(min, max + 1);
		return data;
	}
	
	public void setComboBoxModel(JComboBox<Integer> comboBox, JSpinner spinner) {
		Integer[] data = getSpinnerRange(spinner);
		comboBox.setModel(new DefaultComboBoxModel<Integer>(data));
		comboBox.setPreferredSize(new Dimension(50, 20)); //TODO: size should be parameterized.
	}

	
	protected void install_calc_panel_listeners(){
		JTextField command_field = calc_panel.command_field;
		
		//Param panel
		command_field.addActionListener(calc_truth_set_action);
		calc_panel.calc_truth_set_button.addActionListener(calc_truth_set_action);
		calc_panel.calc_frame_property_button.addActionListener(calc_frame_property_action);
		calc_panel.viz_button.addActionListener(viz_action);
		
		//Control panel
		calc_panel.copy_button.addActionListener(copy_action);
		calc_panel.clear_button.addActionListener(clear_action);
		calc_panel.help_button.addActionListener(help_action);		
	}
	
	protected void install_toolbar_listeners(){
		//Toolbar for model generation
		editor_panel.random_frame_button.addActionListener(random_frame_action);
		editor_panel.random_model_button.addActionListener(random_model_action);
		editor_panel.reflexive_button.addActionListener(reflexive_frame_action);
		editor_panel.symmetric_button.addActionListener(symmetric_frame_action);
		editor_panel.transitive_button.addActionListener(transitive_frame_action);
		editor_panel.serial_button.addActionListener(serial_frame_action);
		editor_panel.euclidean_button.addActionListener(euclidean_frame_action);
		editor_panel.reset_button.addActionListener(identity_model_action);
		
		//Toolbar for relation, channel and valuation
		
	}
	
	protected void setBackgroundExecutionsForModelSizeEdit(boolean b){
		relation_world_spinner_change_action.setMultiThreadExecution(b);
		relation_agent_spinner_change_action.setMultiThreadExecution(b);
		channel_agent_spinner_change_action.setMultiThreadExecution(b);
		channel_world_spinner_change_action.setMultiThreadExecution(b);
		proposition_world_spinner_change_action.setMultiThreadExecution(b);
		proposition_proposition_spinner_change_action.setMultiThreadExecution(b);	
	}
	
	protected void setBackgroundExecutionsForModelGeneration(boolean b){
		new_model_action.setMultiThreadExecution(b);
		random_frame_action.setMultiThreadExecution(b); 
		random_model_action.setMultiThreadExecution(b);
		identity_model_action.setMultiThreadExecution(b);
		reflexive_frame_action.setMultiThreadExecution(b);
		symmetric_frame_action.setMultiThreadExecution(b);
		transitive_frame_action.setMultiThreadExecution(b);
		serial_frame_action.setMultiThreadExecution(b);
		euclidean_frame_action.setMultiThreadExecution(b);
	}
	
	protected void setBackgroundExecutionsForCalculation(boolean b){
		calc_truth_set_action.setMultiThreadExecution(b); 
		calc_frame_property_action.setMultiThreadExecution(b); 
	}

	protected void setBackgroundExecutionsForVisualization(boolean b){
		viz_action.setMultiThreadExecution(b);		
	}
	
	protected void setVerboseForModelSizeEdit(boolean b){
		relation_world_spinner_change_action.setVerbose(b);
		relation_agent_spinner_change_action.setVerbose(b);
		channel_agent_spinner_change_action.setVerbose(b);
		channel_world_spinner_change_action.setVerbose(b);
		proposition_world_spinner_change_action.setVerbose(b);
		proposition_proposition_spinner_change_action.setVerbose(b);			
	}
	
//TODO: class of events/actions and helpful internal class are defined as follows: ---------------------
	
	class SaveAction extends WorkerRunAction{
		protected boolean saveAs;
		
		public SaveAction(JComponent parent, String caption, ExecutorService executor, boolean saveAs) {
			super(parent, caption, executor);
			this.saveAs = saveAs;
		}

		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new SaveWorker(progress_panel, parent, saveAs);
		}
	}
			
	class SaveWorker extends SimpleWorker{

		protected boolean saveAs;
		
		public SaveWorker(JComponent parent, JComponent root, boolean saveAs) {
			super(parent, root);
			this.saveAs = saveAs;
		}
		
		@Override
		public void doTask(){
			if(!saveAs)save_model();
			else save_model_as();
		}
		
		public void save_model(){
			if(file == null) {
				//new file
				save_model_as();
			}else{
				//overwrite
				try { save_model_simple(file); } catch (IOException e) { e.printStackTrace(); file = null; }
				System.out.println("The file has overwritten: " + file.getAbsolutePath());
			}
		}
		
		public void save_model_as(){
			JFileChooser chooser = newDefaultFileChooser();
			int selection = chooser.showSaveDialog(root);
			switch(selection){
			case JFileChooser.APPROVE_OPTION:
				file = chooser.getSelectedFile();
				if(Objects.nonNull(file) && file.exists()){
					int res = JOptionPane.showConfirmDialog(root, "A file already exists. Overwrite?", "Warning", JOptionPane.YES_NO_OPTION);
					if(res != JOptionPane.YES_OPTION) break;
				}else{
					String name = file.getName();
					if(!name.endsWith("." + EXT_SIMPLE)){
						file = new File(file.getAbsolutePath() + "." + EXT_SIMPLE);
					}
				}
				try {
					save_model_simple(file);			
				} catch (IOException e) {
					e.printStackTrace();
					file = null;
				}
				break;
			case JFileChooser.CANCEL_OPTION:
				// Cancel
			case JFileChooser.ERROR_OPTION:
				// Error
			default:
				//Note: currently, do nothing.
			}
		}
			
		public void save_model_simple(File file) throws IOException{
			initTask(6);
			
			int card_W = (int) editor_panel.world_spinner.getValue();
			int card_G = (int) editor_panel.agent_spinner.getValue();
			int card_P = (int) editor_panel.proposition_spinner.getValue();
			Map<Integer, MatrixTableModel> relation_map = editor_panel.relation_map;
			Map<Integer, MatrixTableModel> channel_map  = editor_panel.channel_map;
			MatrixTable valuation_table   = editor_panel.valuation_table;
			JComboBox<String> command_box = calc_panel.command_box; 
			progress(); //Step 1
			
			Map<Integer, SparseMatrix> R = new LinkedHashMap<Integer, SparseMatrix>();		
			for(int a = 0; a < card_G; a++){
				TableModel relation_a_model = relation_map.get(a+1);
				SparseMatrix R_a = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(relation_a_model));
				R.put(a, R_a);
			}
			progress(); //Step 2
			
			Map<Integer, SparseMatrix> C = new LinkedHashMap<Integer, SparseMatrix>();
			for(int w = 0; w < card_W; w++){
				TableModel channel_model = channel_map.get(w+1);			
				SparseMatrix C_w = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(channel_model));
				C.put(w, C_w);
			}	
			progress(); //Step 3
			
			TableModel valuation_model = valuation_table.getModel();
			SparseMatrix V = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(valuation_model));
			progress(); //Step 4

			List<String> history = new ArrayList<String>();
			int size = command_box.getModel().getSize();
			for(int i = 0; i < size; i++){
				history.add(command_box.getItemAt(i));
			}
			progress(); //Step 5
			
			//save
			SimpleModelManager manager = new SimpleModelManager(ID, VERSION, file, card_W, card_G, card_P, R, C, V, history);
			manager.save();
			progress(); //Final step 6
			
			//post process
			setTitle(ID + " - " + file.getAbsolutePath());
			System.out.println("The data has saved to " + file.getAbsolutePath());
		}
	}
	
	class LoadAction extends WorkerRunAction{

		protected JFrame frame;
		
		public LoadAction(JComponent parent, String caption, ExecutorService executor, JFrame frame) {
			super(parent, caption, executor);
			this.frame = frame;
		}
		
		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new LoadWorker(progress_panel, parent, frame);
		}
	}
	
	class LoadWorker extends SimpleWorker{

		protected JFrame frame;
		protected Map<Integer, MatrixTableModel> new_R;
		protected Map<Integer, MatrixTableModel> new_C;
		protected MatrixTableModel new_V;
		
		public LoadWorker(JComponent parent, JComponent root, JFrame frame) {
			super(parent, root);
			this.frame = frame;
		}
		
		@Override
		public void doTask(){
			load_model();
		}
		
		public void load_model(){
			JFileChooser chooser = newDefaultFileChooser(); 
			int selection = chooser.showOpenDialog(root);
			switch(selection){
			case JFileChooser.APPROVE_OPTION:
				file = chooser.getSelectedFile();
				try {
					load_model_simple(file);
					setTitle(ID + " - " + file.getAbsolutePath());
					
				} catch (Exception e) {
					e.printStackTrace();
					file = null;
				}
				
				break;
			case JFileChooser.CANCEL_OPTION:
				// Cancel
			case JFileChooser.ERROR_OPTION:
				// Error
			default:
				//Note: currently, do nothing.
			}		
		}
		
		public void load_model_simple(File file) throws Exception{
			initTask(7);
			
			//temporary stopping background model size updates
			boolean bg_flag = bg_model_size_edit_item.isSelected();
			setBackgroundExecutionsForModelSizeEdit(false);
			bg_model_size_edit_item.setSelected(false);
			
			SimpleModelManager manager = new SimpleModelManager(file);
			manager.load();
			progress(); //Step 1
			
			int card_W = manager.get_W();
			int card_G = manager.get_G();
			int card_P = manager.get_P();
			Map<Integer, SparseMatrix> R = manager.getR();
			Map<Integer, SparseMatrix> C = manager.getC();
			SparseMatrix V = manager.getV();
			List<String> history = manager.getHistory();
			progress(); //Step 2
			
			//Editor panel 
			editor_panel.world_spinner.setValue(card_W); //#W
			editor_panel.agent_spinner.setValue(card_G); //#G
			editor_panel.proposition_spinner.setValue(card_P); //#P
			progress(); //Step 3
			
			new_R =  new LinkedHashMap<Integer, MatrixTableModel>();
			reinstall_table_models(card_G, new_R, world_prefix + delimiter, world_prefix + delimiter, card_W, card_W, 1, editor_panel.relation_table);
			copyTableModels(new_R, R);
			install_table_headers(editor_panel.relation_scrollpane, editor_panel.relation_table);
			progress(); //Step 4
			
			new_C =  new LinkedHashMap<Integer, MatrixTableModel>();
			reinstall_table_models(card_W, new_C, agent_prefix + delimiter, agent_prefix + delimiter, card_G, card_G, 1, editor_panel.channel_table);
			copyTableModels(new_C, C);
			install_table_headers(editor_panel.channel_scrollpane, editor_panel.channel_table);
			progress(); //Step 5

			new_V = install_table_model(world_prefix + delimiter, proposition_prefix + delimiter, card_W, card_P, editor_panel.valuation_table, true);
			copyTableModel(new_V, V);
			install_table_headers(editor_panel.valuation_scrollpane, editor_panel.valuation_table);
			progress(); //Step 6
						
			//history
			DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>();
			for(String command: history){
					System.out.println("loaded command " + command);
					model.addElement(command);
			}
			calc_panel.command_box.setModel(model);
			
			//restore temporary setting
			setBackgroundExecutionsForModelSizeEdit(bg_flag);
			bg_model_size_edit_item.setSelected(bg_flag);
			
			progress(); //Final step 7
			
		}
		
		
		protected synchronized void reinstall_table_models(int size, Map<Integer, MatrixTableModel> map, String row_header, String col_header, int row_size, int col_size, int selected_item, MatrixTable table){
			addTask(size);
			for(int i = 0; i < size; i++){
				MatrixTableModel table_model;
				table_model = install_table_model(row_header, col_header, row_size, col_size, table, (i+1) == selected_item);
				map.put(i+1, table_model);
				progress();
			}
		}
		
		
		protected synchronized void copyTableModels(Map<Integer, MatrixTableModel> new_map, Map<Integer, SparseMatrix> old_map){
			Set<Integer> old_keys = old_map.keySet();
			
			for(Integer old_key: old_keys){
				if(new_map.containsKey(old_key + 1)){
					copyTableModel(new_map.get(old_key + 1), old_map.get(old_key));
				}
			}
		}

		protected synchronized void copyTableModel(MatrixTableModel new_model, SparseMatrix matrix_model){
			//copy data
			int row_size = new_model.getRowCount();
			int col_size = new_model.getColumnCount();
			String rowHeaders = new_model.getRowHeader();
			String colHeaders = new_model.getColumnHeader();
			
			/*
			System.err.println("row headers = " + rowHeaders);
			System.err.println("row size = " + row_size);
			System.err.println("col headers = " + colHeaders);
			System.err.println("col size = " + col_size);
			System.err.println("matrix= \n" + matrix_model.toString());
			*/
			
			MatrixTableModel old_model = MatrixTableModel.newInstance(rowHeaders, colHeaders, row_size, col_size);
			UJMPUtil.matrix2table(matrix_model, old_model);
			int data = 0;
			for(int i = 0; i < row_size; i++){
				for(int j = 0; j < col_size; j++){
					data = 0;
					data = (int)old_model.getValueAt(i, j);
					new_model.setValueAt(data, i, j);
				}					
			}
		}
		
		@Override
		public void done(){ //this is processed by Event dispatch thread
			SwingUtilities.invokeLater(new Runnable(){
				@Override
				public void run() {
					revalidate();
					editor_panel.relation_map.clear();
					copyMap(editor_panel.relation_map, new_R);
					editor_panel.channel_map.clear();
					copyMap(editor_panel.channel_map, new_C);
					install_table_headers(editor_panel.relation_scrollpane, editor_panel.relation_table);
					install_table_headers(editor_panel.channel_scrollpane, editor_panel.channel_table);
					install_table_headers(editor_panel.valuation_scrollpane, editor_panel.valuation_table);
					editor_panel.relation_comboBox.setSelectedIndex(0);
					editor_panel.channel_comboBox.setSelectedIndex(0);
					editor_panel.valuation_table.setModel(new_V);
					revalidate();
					done0();
				}
			});
		} 
		
		public void copyMap(Map<Integer, MatrixTableModel> original_map, Map<Integer, MatrixTableModel> new_map){
			Set<Integer> keys = new_map.keySet();
			original_map.clear();
			for(Integer key: keys){
				MatrixTableModel model = new_map.get(key); 
				original_map.put(key, model);
			}
		}
		
		protected void done0(){
			super.done();
		}
		
		
	}
	
	class OpenDotDirAction extends WorkerRunAction{
		
		public OpenDotDirAction(JComponent parent, String caption, ExecutorService executor) {
			super(parent, caption, executor);
		}
		
		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new OpenDotDirWorker(progress_panel, parent);
		}
		
	}
	
	class OpenDotDirWorker extends SimpleWorker{
		
		public OpenDotDirWorker(JComponent parent, JComponent root) {
			super(parent, root);

		}
		
		@Override
		public void doTask(){
			initTask(1);
			IOUtil.openFile(output_dir);
			progress();
		}
	}
	
	
	class AboutDialogAction implements ActionListener{
		protected JFrame owner;
		
		public AboutDialogAction(JFrame owner){
			this.owner = owner;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
				AboutDialog about = new AboutDialog(owner, ID, VERSION);
				about.setModal(true);
				about.setVisible(true);
		}
	}
	
	class CalcTruthSetAction extends DoubleWorkerRunAction{
		protected JTextField field;
		
		public CalcTruthSetAction(JComponent parent, String caption, ExecutorService executor, JTextField field){
			super(parent, caption, executor);
			this.field = field;
		}
		
		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new CalcTruthSetWorker(progress_panel, parent, field);
		}	
	}
	
	class CalcTruthSetWorker extends DoubleWorker{
		protected JTextField field;
		
		public CalcTruthSetWorker(JComponent parent, JComponent root, JTextField field) {
			super(parent, root);
			this.field = field;
		}
		
		@Override
		public void doTask(){
			try{
				String arg = field.getText();
				
				boolean res = false;
				if(arg == null || arg.isEmpty()){
					res = calc_truth_set(last_formula);
				}else{
					res = calc_truth_set(arg);
					if(res) { last_formula = arg; }
				}
				if(res){ field.setText(""); }	
			}catch(Exception e){ System.out.println("ERROR"); e.printStackTrace(); }
			field.requestFocusInWindow();
		}
				
		public boolean calc_truth_set(String arg){
			initTask(2);
			
			//calculate 
			System.out.println("<--- begin: truth set of " + arg + " --->");
			
			ChanneledKripkeModel<String, SparseMatrix> model = transform_model();
			progress(); //Step 1
			errHandler = new ErrorHandler(ID, System.out);
			boolean res = eval(arg, model, errHandler);
			//boolean res = eval(arg, editor_panel, errHandler);
			progress(); //Final step 2
			System.out.println("<---end: truth set of " + arg + " --->");
			return res;
		}
		
		public ChanneledKripkeModel<String, SparseMatrix> transform_model(){
			initSubTask(7);
			
			int card_W = (int) editor_panel.world_spinner.getValue();
			int card_G = (int) editor_panel.agent_spinner.getValue();
			int card_P = (int) editor_panel.proposition_spinner.getValue();
			subProgress(); //Step 1
			
			//For W -----
			String[] W = arrayOf("w_", 1, card_W);
			subProgress(); //Step 2

			//For G -----
			String[] G = arrayOf("a_", 1, card_G);
			subProgress(); //Step 3
			
			//For R ----- (Node: row=src, col=dest)
			Map<String, SparseMatrix> R = new LinkedHashMap<String, SparseMatrix>();
			for(int i = 0; i < G.length; i++){
				MatrixTableModel relation_a_model  	= editor_panel.relation_map.get(i+1);
				//System.out.println(i+1);
				//System.out.println(model_panel.relation_map);
				SparseMatrix R_a = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(relation_a_model));
				UJMPUtil.setMatrixLabels(R_a, W, W);
				
				String a = G[i];
				R.put(a, R_a);
			}
			subProgress(); //Step 4
			
			//For C ----- (Note: row=dest, col=src)
			Map<String, SparseMatrix> C = new LinkedHashMap<String, SparseMatrix>();
			for(int i = 0; i < W.length; i++){
				String w = W[i];
				MatrixTableModel channel_model = (MatrixTableModel) editor_panel.channel_map.get(i+1);			
				SparseMatrix c_w = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(channel_model));
				//SparseMatrix mat_C_a_b = Converter.arr2vector(C(a,b), card_W, true);
				UJMPUtil.setMatrixLabels(c_w, G, G);
				C.put(w, c_w);
			}
			subProgress(); //Step 5
			
			//For P -----
			String[] P = arrayOf("p_", 1, card_P);
			//SparseMatrix V = SparseMatrix.factory.zeros(card_W, card_P); //row, col
			MatrixTableModel valuation_model = (MatrixTableModel) editor_panel.valuation_table.getModel();
			SparseMatrix V = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(valuation_model));
			UJMPUtil.setMatrixLabels(V, W, P);
			subProgress(); //Step 6
			
			try {
				String name = "M";
				if(Objects.nonNull(file)){ name = file.getName(); }
				ChanneledKripkeModel<String, SparseMatrix> model = new UJMPKripkeModel<String>(name, W, G, R, C, P, V);
				subProgress(); //Final step 7
				return model;
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
				
		public String[] arrayOf(String prefix, int begin, int end){
			List<String> list = new ArrayList<String>();
			for(int i = begin; i <= end; i++){
				list.add(prefix + i);
			}
			return list.toArray(new String[0]);
		}
		public boolean eval(String formula, ChanneledKripkeModel<String, SparseMatrix> model, ErrorHandler errHandler){
			initSubTask(3);
			
			try{
				if(showModel){ System.out.println(model); }
				//System.out.println("---- begin parsing ----");
				Parser parser = Parser.newStringParser(formula, errHandler, false);
				AST ast = parser.parse_without_eof();
				subProgress(); //Step 1
				//System.out.println("---- end parsing ----");
				if(showAST){
					System.out.println("---- begin AST dump ----");
					ast.dump();
					System.out.println("---- end AST dump ----");					
				}
				subProgress(); //Step 2
				StmtNode[] stmts = ast.stmts(); 
				addSubTask(stmts.length);
				for(StmtNode stmt: stmts){
					System.out.println("---- begin stmt calculation----");
					eval_stmt(stmt, model);
					subProgress(); //Step N
					System.out.println("---- end stmt calculation ----");
				}
				subProgress(); //Final step N+1 
				return true;
			}catch(ParseException e){
				errHandler.error(e.getMessage());
				JOptionPane.showMessageDialog(root, e.getMessage(), "Parse error", JOptionPane.ERROR_MESSAGE);
				cancel(true);
			}catch(TokenMgrError | Exception e){
				//errHandler.error(e.getMessage());
				e.printStackTrace();
				cancel(true);
			}
			return false;
		}
		
		public void eval_stmt(StmtNode stmt, ChanneledKripkeModel<String, SparseMatrix> model){
			CalcVisitor visitor = new  CalcVisitor(model, isVerbose);
			SparseMatrix res = stmt.accept(visitor);
			if(Objects.nonNull(res)){
				UJMPUtil.setAxisLabels(res, model.getW().toArray(new String[0]), true);
				String[] col_labels = UJMPUtil.getAxisLabels(res, false);
				System.out.println("-+-+-+-");
				System.out.println("resultant truth set = \n" + col_labels[0] + " = ");
				System.out.println(res);
				if(visitor.isUpdated()){
					update_model(model);
					System.out.println("The model is updated!");
				}else{
					System.out.println("The model is NOT updated.");
				}
			}else{ throw new NullPointerException(); }
		}
		
		public void update_model(ChanneledKripkeModel<String, SparseMatrix> model){
			Map<String, SparseMatrix> updated_model = model.getR();
			Set<String> G = updated_model.keySet();
			for(Iterator<String> iter = G.iterator(); iter.hasNext(); ){
				String a = iter.next();
				SparseMatrix R_a = updated_model.get(a);
				int a_id = UJMPUtil.get_index(a, "_");
				MatrixTableModel R_a_model =  editor_panel.relation_map.get(a_id);
				UJMPUtil.matrix2table(R_a, R_a_model);
				
				editor_panel.relation_map.put(a_id, R_a_model);						
			}		
		}
		
		public Integer[] C(int a, int b){
			//for fix the index
			a--;
			b--;
			
			List<Integer> lst = new ArrayList<Integer>();
			int sharp_W = (Integer)editor_panel.world_spinner.getValue();
			
			MatrixTableModel channel_model;
			for(int i = 0; i < sharp_W; i++){
				channel_model = editor_panel.channel_map.get(i+1);
				int value = Integer.parseInt(channel_model.getValueAt(b, a).toString());
				if(value > 0)lst.add(i+1);
			}
			return (Integer[])lst.toArray(new Integer[0]);
		}		
	}
	
	class CalcFramePropertyAction extends DoubleWorkerRunAction{
		protected JTextField field;
		
		public CalcFramePropertyAction(JComponent parent, String caption, ExecutorService executor, JTextField field) {
			super(parent, caption, executor);
			this.field = field;
		}

		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new CalcFramePropertyWorker(progress_panel, parent, field);
		}	
	}
	
	class CalcFramePropertyWorker extends DoubleWorker{
		protected JTextField field;

		public CalcFramePropertyWorker(JComponent parent, JComponent root, JTextField field) {
			super(parent, root);
			this.field = field;
		}
		
		@Override
		public void doTask() {
			try{
				String arg = field.getText();
				if(arg.equals("all")){ calc_frame_property_all(); }
				else {
					initTask(1);
					
					try{ calc_frame_property(arg); }catch(Exception e){ System.out.println("ERROR"); e.printStackTrace();}
					progress(); //Final step 1
				}
				field.setText("");
				
			}catch(NumberFormatException ex){ ex.printStackTrace(); }
			field.requestFocusInWindow();
		}
		
		public String[] calc_frame_property_all(){
			Set<Integer> G = editor_panel.relation_map.keySet();
			List<String> list = new ArrayList<String>();
			initTask(G.size());
			
			for(Iterator<Integer> iter = G.iterator(); iter.hasNext(); ){
				int a = iter.next();
				String res = calc_frame_property("a_" + a);
				list.add(res);
				progress(); //N
			}
			return list.toArray(new String[0]);
		}
		
		public String calc_frame_property(String str){
			initSubTask(2 + countTaskSize());
			
			int i = -1;
			if(str == null || str.isEmpty()){
				i = Integer.parseInt(editor_panel.relation_comboBox.getSelectedItem().toString());
				str = "a_" + i;
			}else{
				i = UJMPUtil.get_index(str, "_");
			}
			
			//read input
			MatrixTableModel relation_i_model  	= editor_panel.relation_map.get(i);
			subProgress(); //Step 1
			
			//do calculation
			System.out.println("<---begin: frame property verification of \\rel{" + str + "}--->");
			SparseMatrix matrix_i = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(relation_i_model));
			StringBuilder sb = new StringBuilder();
			if(reflexivity_item.isSelected()){ printResult(sb, "Reflexivity(T)", "T", UJMPUtil.isT(matrix_i)); subProgress(); }
			if(symmetricity_item.isSelected()){ printResult(sb, "Symmetricity(B)", "B", UJMPUtil.isB(matrix_i)); subProgress(); }
			if(transitivity_item.isSelected()){ printResult(sb, "Transitivity(4)", "4", UJMPUtil.is4(matrix_i)); subProgress(); }
			if(seriality_item.isSelected()){ printResult(sb, "Seriality(D)", "D", UJMPUtil.isD(matrix_i)); subProgress(); }
			if(euclidianness_item.isSelected()){ printResult(sb, "Euclidianness(5)", "5", UJMPUtil.is5(matrix_i)); subProgress(); }
			
			//output
			//control_panel.frame_property_field.setText(sb.toString());
			String res = sb.toString();
			System.out.println("\\rel{" + str + "} satisfies: " + res);
			System.out.println("<---end: frame property verification of \\rel{" + str + "}--->");
			
			subProgress(); //Final step 2 + N
			return res;
		}
		
		public int countTaskSize(){
			int cnt = 0;
			if(reflexivity_item.isSelected()) cnt++;
			if(symmetricity_item.isSelected()) cnt++;
			if(transitivity_item.isSelected()) cnt++;
			if(seriality_item.isSelected()) cnt++;
			if(euclidianness_item.isSelected()) cnt++;
			return cnt;
		}
		
		public void printResult(StringBuilder sb, String title, String short_name, boolean isX){
			if(isX){ sb.append(short_name); System.out.println(title +"  ---> o"); }
			else { System.out.println(title + "  ---> x"); }
		}
	}
	
	class VizAction extends DoubleWorkerRunAction{
		protected JTextField field;
		
		public VizAction(JComponent parent, String caption, ExecutorService executor, JTextField field) {
			super(parent, caption, executor);
			this.field = field;
		}
		
		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new VizWorker(progress_panel, parent, field);
		}	
	}
	
	class VizWorker extends DoubleWorker{
		protected JTextField field;
		
		public VizWorker(JComponent parent, JComponent root, JTextField field) {
			super(parent, root);
			this.field = field;
		}

		@Override
		public void doTask() {
			try{
				String arg = field.getText();
				if(arg.equals("all")){ genGraphs(); }
				else {
					initTask(1);
					genGraph(arg);
					progress(); //Final step 1
				}
				field.setText("");
			}catch(NumberFormatException ex){ ex.printStackTrace(); }
			field.requestFocusInWindow();
		}		
		
		public void genGraphs(){
			initTask(2);
			
			//open directory dialogue 
			String dir = output_dir;
			
			genChannelGraphs(dir);
			progress(); //Step 1
			
			genRelationGraphs(dir);
			progress(); //Step 2
			//get all relation, channel, then transform them to graphviz format.
		}
		
		public void genGraph(String arg){
			initSubTask(1);
			
			String dir = output_dir;
			
			int i = -1;
			if(arg == null || arg.isEmpty()){ 
				i = Integer.parseInt(editor_panel.relation_comboBox.getSelectedItem().toString());
				genRelationGraph(dir, i);
			}else{
				if(arg.startsWith("a")){
					i = UJMPUtil.get_index(arg, "_");
					genRelationGraph(dir, i);
				}
				
				if(arg.startsWith("w")){
					i = UJMPUtil.get_index(arg, "_");
					genChannelGraph(dir, i);
				}
			}
			subProgress(); //Final step 1
		}
		
		public void genChannelGraphs(String dir){
			Set<Integer> keys = editor_panel.channel_map.keySet();
			initSubTask(keys.size());
			
			for(Integer key: keys){
				genChannelGraph(dir, key);
				subProgress();
			}
		}
		
		public void genChannelGraph(String dir, int w){
			String name = DOT_CPREFIX + w;
			MatrixTableModel model = editor_panel.channel_map.get(w);
			String txt = genChannelGraph(name, model);
			genGraph(dir, name, txt);		
		}
		
		public void genRelationGraphs(String dir){
			Set<Integer> keys = editor_panel.relation_map.keySet(); 
			initSubTask(keys.size());
			
			for(Integer key: keys){
				genRelationGraph(dir, key);
				subProgress();
			}
		}
		
		public void genRelationGraph(String dir, int a){
			String name = DOT_RPREFIX + a;
			MatrixTableModel relation_model  = editor_panel.relation_map.get(a);
			MatrixTableModel valuation_model = (MatrixTableModel) editor_panel.valuation_table.getModel();
			String txt = genRelationGraph(name, relation_model, valuation_model);
			
			//Note: For debug ---
			/*
			int row_size = relation_model.getRowCount();
			int col_size = relation_model.getColumnCount();
			for(int i = 0; i < row_size; i++){
				for(int j = 0; j < col_size; j++){
					System.err.println(i + "," + j + "=" + relation_model.getValueAt(i, j));						
				}
				System.err.println();
			}*/
			// -----
			
			genGraph(dir, name, txt);		
		}
		
		public void genGraph(String dir, String name, String txt){
			System.out.println("<---begin: Visualization for " + name + " --->");
			String dot_path = dir + separator + name + DOT_EXT;
			String png_path = dir + separator + name + GRAPH_EXT;
			boolean res = IOUtil.writeTextFile(dot_path, txt);
			if(!res){System.out.println("Dot file writing ERROR"); return;}
			System.out.println("file saved: " + dot_path);
			System.out.println("Executing Graphviz... ");
			exec_path = selectExec();
			System.out.println("Layout mode: " + layout);
			//System.out.println("Exectuion path: " + exec_path);
			System.out.println("Executing command: " + exec_path + " -Tpng " + dot_path + " -o " + png_path);
			int ret = IOUtil.exec(exec_path, "-Tpng", dot_path, "-o", png_path);
			if(ret < 0){System.out.println("Graphviz execution ERROR"); return; }
			if(isOpen){
				System.out.println("Opening output file: " + png_path);
				IOUtil.openFile(png_path); 
			}
			System.out.println("<---end: Visualization for " + name + " --->");
		}
		
		public String selectExec(){
			String exec_path = Layout.dot.toString();
			switch(layout){
			case Auto:
				int card_W = (int)editor_panel.world_spinner.getValue();
				int card_G = (int)editor_panel.agent_spinner.getValue();
				int card_P = (int)editor_panel.proposition_spinner.getValue();
				if(card_W > auto_threshold || card_G > auto_threshold || card_P > auto_threshold) {exec_path = Layout.circo.toString(); }
				else { exec_path = Layout.dot.toString(); }
				break;
			default: 
				exec_path = layout.toString();
				break;
			}
			return graphviz_bin_path + exec_path;
		}
		
		public String genChannelGraph(String name, MatrixTableModel model){
			StringBuilder sb = new StringBuilder();
			sb.append("digraph " + name + "{ " + crlf);
			sb.append("graph[label=\""+ name + "\"];" + crlf);
			String NODE_PREFIX = "a";
			//append channel
			int row = model.getRowCount();
			int col = model.getColumnCount();
			
			for(int i = 0; i < col; i++){ 
				boolean isSingle = false;
				for(int j = 0; j < row; j++){
					try{
						String data_from_to = model.getValueAt(j, i).toString();
						String data_to_from = model.getValueAt(i, j).toString();
						if(!data_from_to.isEmpty() && ! data_to_from.isEmpty()){
							int value_from_to = Integer.parseInt(data_from_to);
							int value_to_from = Integer.parseInt(data_to_from);
							int from = i + 1;
							int to   = j + 1;

							if(value_from_to > 0){
								if(value_to_from > 0){
									if(j > i){
										sb.append("\t" + NODE_PREFIX + from + " -> " + NODE_PREFIX + to);
										sb.append(" [dir=\"both\"]" + ";" + crlf);
									}else if (j == i){
										sb.append("\t" + NODE_PREFIX + from + " -> " + NODE_PREFIX + to + ";" + crlf);
									}else{ ; }
								}else{
									sb.append("\t" + NODE_PREFIX + from + " -> " + NODE_PREFIX + to + ";" + crlf);
								}
								
							}else{
								if(!isSingle) {
									sb.append("\t"+ NODE_PREFIX + from + ";" + crlf);
									isSingle = true;
								}
							}
						}
					}catch(NumberFormatException e){ e.printStackTrace(); return null; }
				}
			}
			sb.append("}");
			return sb.toString();
		}
		
		public String genRelationGraph(String name, MatrixTableModel relation_model, MatrixTableModel valuation_model){
			StringBuilder sb = new StringBuilder();
			sb.append("digraph " + name + "{ " + crlf);
			sb.append("graph[rankdir=LR, compound=true, label=\""+ name + "\"];" + crlf);
			String NODE_PREFIX = "w";
			//append channel
			int row = relation_model.getRowCount();
			int col = relation_model.getColumnCount();
			
			for(int i = 0; i < row; i++){ 
				boolean isSingle = false;
				for(int j = 0; j < col; j++){
					try{
						Object from_to = relation_model.getValueAt(i, j);
						Object to_from = relation_model.getValueAt(j, i);
						String data_from_to = from_to.toString();
						String data_to_from = to_from.toString();
						if(!data_from_to.isEmpty() && ! data_to_from.isEmpty()){
							int value_from_to = Integer.parseInt(data_from_to);
							int value_to_from = Integer.parseInt(data_to_from);
							int from = i + 1;
							int to   = j + 1;
							//cluster
							sb.append("\tsubgraph cluster_" + NODE_PREFIX + from + "{" + crlf);
							sb.append("\t\tpenwidth=0;" + crlf);
							int vrow = i;
							int vcol = valuation_model.getColumnCount();
							StringBuilder sbf = new StringBuilder();
							for(int k = 0; k < vcol; k++){
								String data_prop = valuation_model.getValueAt(vrow, k).toString();
								int value_prop = Integer.parseInt(data_prop);
								int prop_id = k + 1;
								if(value_prop > 0) sbf.append("p" + prop_id);
								else sbf.append("~p" + prop_id);
								if(k+1 < vcol)sbf.append(",");
							}
							sb.append("\t\tlabel=\"\" " + crlf);
							sb.append("\t\t" + NODE_PREFIX + from + "[label=\"{" + sbf.toString() + "}\\n\\n" + NODE_PREFIX + from + "\"];" + crlf);
							sb.append("\t}" + crlf);
							
							//link
							if(value_from_to > 0){
								if(value_to_from > 0){
									if(j > i){
										sb.append("\t" + NODE_PREFIX + from + " -> " + NODE_PREFIX + to);
										sb.append(" [dir=\"both\"]" + ";" + crlf);
									}else if (j == i){
										sb.append("\t" + NODE_PREFIX + from + " -> " + NODE_PREFIX + to + ";" + crlf);
									}else{ ; }
								}else{
									sb.append("\t" + NODE_PREFIX + from + " -> " + NODE_PREFIX + to + ";" + crlf);
								}
								
							}else{
								if(!isSingle) {
									sb.append("\t"+ NODE_PREFIX + from + ";" + crlf);
									isSingle = true;
								}
							}
						}
					}catch(NumberFormatException e){ e.printStackTrace(); return null; }
				}
			}
			sb.append("}");
			return sb.toString();
		}
	}
	
	class ModelGenerateAction extends WorkerRunAction{
		protected GenModelMode mode;
		
		public ModelGenerateAction(JComponent parent, String caption, ExecutorService executor, GenModelMode mode) {
			super(parent, caption, executor);
			this.mode = mode;
		}
		
		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new ModelGenerateWorker(progress_panel, parent, mode);
		}	
	}
	
	class ModelGenerateWorker extends SimpleWorker{
		protected final GenModelMode mode;
		
		public ModelGenerateWorker(JComponent parent, JComponent root, GenModelMode mode) {
			super(parent, root);
			this.mode = mode;
		}
		
		@Override
		public void doTask() {
			initTask(1);
			try{
				switch(mode){
				case NewModel:
					new_model();
					break;
				case RandomFrame:
					random_frame();
					break;
				case RandomModel:
					random_model();
					break;
				case IdentityModel:
					reset_model();
					break;
				case ReflexiveFrame:
				case SymmetricFrame: 
				case TransitiveFrame:
				case SerialFrame:
				case EuclideanFrame:
					genCustomFrame(mode);
					break;
				default:
					throw new Exception("Invalid mode");
				}
			}catch(Exception e){}
			progress();
		}
				
		public void new_model() throws Exception{
			addTask(1);
			file = null;
			setTitle(ID);
			reset_model();
			progress();
		}
		
		public void random_frame() throws Exception{
			Collection<MatrixTableModel> relation_models = editor_panel.relation_map.values();
			Collection<MatrixTableModel> channel_models = editor_panel.channel_map.values(); 
			
			addTask(relation_models.size());
			addTask(channel_models.size());
			
			for(MatrixTableModel model: relation_models){
				fillTableModel(model, GenModelMode.RandomFrame);
				progress();
			}
			
			for(MatrixTableModel model: channel_models){
				fillTableModel(model, GenModelMode.RandomFrame);
				progress();
			}			
		}

		public void random_model() throws Exception{
			addTask(1);
			random_frame();
			MatrixTableModel model = (MatrixTableModel) editor_panel.valuation_table.getModel();			
			fillTableModel(model, GenModelMode.RandomModel);
			progress();
		}
		
		public void reset_model() throws Exception{
			Collection<MatrixTableModel> relation_models = editor_panel.relation_map.values();
			Collection<MatrixTableModel> channel_models = editor_panel.channel_map.values(); 

			addTask(relation_models.size());
			addTask(channel_models.size());		
			addTask(1);
			addTask(1);
			
			//Model panel
			for(MatrixTableModel model: relation_models){
				fillTableModel(model, GenModelMode.IdentityModel);
				progress();
			}
			
			for(MatrixTableModel model: channel_models){
				fillTableModel(model, GenModelMode.IdentityModel);
				progress();
			}
			
			MatrixTableModel model = (MatrixTableModel) editor_panel.valuation_table.getModel();
			fillTableModel(model, GenModelMode.IdentityModel);
			progress();

			editor_panel.world_spinner.setValue(5); //#W
			editor_panel.agent_spinner.setValue(5); //#G
			editor_panel.proposition_spinner.setValue(5); //#P
			progress();
		}
		
		protected void fillTableModel(MatrixTableModel model, GenModelMode mode) throws Exception{
			//SparseMatrix matrix = UJMPUtil.table2matrix(model);
			switch(mode){
			case RandomFrame:
			case RandomModel:
				model.fillTableRandom();
				//UJMPUtil.fillMatrixRandom(matrix);
				break;
			case IdentityModel:
				model.diagonalize();
				//UJMPUtil.diagonalize(matrix);
				break;
			default:
				throw new Exception("Invalid mode");
			}
			//UJMPUtil.matrix2table(matrix, model);
		}		
		
		public void genCustomFrame(GenModelMode mode){
			Collection<MatrixTableModel> models = editor_panel.relation_map.values();
			addTask(models.size());
			for(MatrixTableModel model: models){
				model.fillTableRandom();
				SparseMatrix R = UJMPUtil.table2matrix(model);
				R = UJMPUtil.toT(R);
				switch(mode){
				case ReflexiveFrame:
					R = UJMPUtil.toT(R);
					break;
				case SymmetricFrame: 
					R = UJMPUtil.toB(R);
					break;
				case TransitiveFrame:
					R = UJMPUtil.to4(R);
					break;
				case SerialFrame:
					R = UJMPUtil.toD(R);
					break;
				case EuclideanFrame:
					R = UJMPUtil.to5(R);
					break;
				default: 
				}
				UJMPUtil.matrix2table(R, model);				
				progress(); 			
			}	
		}
	}
	
	
	class TableSizeFullChangeAction extends WorkerRunAction{
		protected JScrollPane scrollpane     = null;
		protected JSpinner spinner           = null;
		protected JComboBox<Integer> combo   = null;
		protected MatrixTable table          = null;
		protected Map<Integer, MatrixTableModel> map = null;
		
		public TableSizeFullChangeAction(JComponent parent, String caption, ExecutorService executor, JScrollPane scrollpane, JSpinner spinner, JComboBox<Integer> combo, MatrixTable table, Map<Integer, MatrixTableModel> map) {
			super(parent, caption, executor);
			this.scrollpane  = scrollpane;
			this.spinner     = spinner;
			this.combo       = combo;
			this.table       = table;
			this.map         = map;
		}
		
		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new TableSizeFullChangeWorker(progress_panel, parent, scrollpane, spinner, combo, table, map);
		}
		
	}
	
	class TableSizeFullChangeWorker extends SimpleWorker{
		protected JScrollPane scrollpane     = null;
		protected JSpinner spinner           = null;
		protected JComboBox<Integer> combo   = null;
		protected MatrixTable table          = null;
		protected Map<Integer, MatrixTableModel> map     = null;
		
		//for processing
		protected Map<Integer, MatrixTableModel> new_map = null;
		protected Map<Integer, MatrixTableModel> old_map = null;
		
		public TableSizeFullChangeWorker(JComponent parent, JComponent root, JScrollPane scrollpane, JSpinner spinner, JComboBox<Integer> combo, MatrixTable table, Map<Integer, MatrixTableModel> map) {
			super(parent, root);
			this.scrollpane = scrollpane;
			this.spinner    = spinner;
			this.combo      = combo;
			this.table      = table;
			this.map        = map;
		}
		
		@Override
		public void doTask(){
			update(); 
		}
		
		protected void update(){
			int next_size = (Integer)spinner.getValue();
			int selected_item = (Integer)combo.getSelectedItem();
			
			if(Objects.nonNull(map)){ //Note: Relation table and Channel table
				Set<Integer> keys = map.keySet();
				
				int agent_size = keys.size();
				initTask(1);
				
				//Copy old data
				old_map = new LinkedHashMap<Integer, MatrixTableModel>();
				int i = 0;
				String row_header = "";
				String col_header = "";
				for(Integer key: keys){
					MatrixTableModel model = map.get(key); 
					old_map.put(key, model);
					if(i++ == 0){ 
						row_header = model.getRowHeader(); 
						col_header = model.getColumnHeader(); 
					}
				}
				
				//install_table_models
				new_map = new LinkedHashMap<Integer, MatrixTableModel>();
				reinstall_table_models(agent_size, new_map, row_header, col_header, next_size, next_size, selected_item, table);
				
				//copy models
				copyTableModels(new_map, old_map);
				progress();
			}
		}
		
		protected synchronized void reinstall_table_models(int size, Map<Integer, MatrixTableModel> map, String row_header, String col_header, int row_size, int col_size, int selected_item, MatrixTable table){
			addTask(size);
			for(int i = 0; i < size; i++){
				MatrixTableModel table_model;
				table_model = install_table_model(row_header, col_header, row_size, col_size, table, (i+1) == selected_item);
				map.put(i+1, table_model);
				progress();
			}
		}
		
		protected synchronized void copyTableModels(Map<Integer, MatrixTableModel> new_map, Map<Integer, MatrixTableModel> old_map){
			Set<Integer> new_keys = new_map.keySet();
			
			for(Integer key: new_keys){
				if(old_map.containsKey(key)){
					copyTableModel(new_map.get(key), old_map.get(key));
				}
			}
		}
		
		protected synchronized void copyTableModel(MatrixTableModel new_model, MatrixTableModel old_model){
			//copy data
			int row_size = new_model.getRowCount();
			int col_size = new_model.getColumnCount();
			
			int old_row_size = old_model.getRowCount();
			int old_col_size = old_model.getColumnCount();
			int data = 0;
			for(int i = 0; i < row_size; i++){
				if(i < old_row_size){
					for(int j = 0; j < col_size; j++){
						data = 0;
						if(j < old_col_size){ data = (int)old_model.getValueAt(i, j); 
							new_model.setValueAt(data, i, j);
						} else{ break; }
					}					
				}else{ break; }
			}
		}
		
		@Override
		public void done(){ //this is processed by Event dispatch thread
			SwingUtilities.invokeLater(new Runnable(){
				@Override
				public void run() {
					copyMap();
					install_table_headers(scrollpane, table);
					done0();
				}
			});
		} 
		
		public void copyMap(){
			Set<Integer> keys = new_map.keySet();
			map.clear();
			for(Integer key: keys){
				MatrixTableModel model = new_map.get(key); 
				map.put(key, model);
			}
			
		}
		
		protected void done0(){
			super.done();
		}
	}
	
	class TableSizeHalfChangeAction extends WorkerRunAction{
		protected JScrollPane scrollpane     = null;
		protected JSpinner row_spinner       = null;
		protected JSpinner col_spinner       = null;
		protected MatrixTable table          = null;
		protected MatrixTableModel model     = null;
		protected boolean isColumn = false;
		
		public TableSizeHalfChangeAction(JComponent parent, String caption, ExecutorService executor, JScrollPane scrollpane, JSpinner row_spinner, JSpinner col_spinner, MatrixTable table, MatrixTableModel model, boolean isColumn) {
			super(parent, caption, executor);
			this.scrollpane  = scrollpane;
			this.row_spinner = row_spinner;
			this.col_spinner = col_spinner;
			this.table       = table;
			this.model       = model;
			this.isColumn    = isColumn;
		}
		
		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new TableSizeHalfChangeWorker(progress_panel, parent, scrollpane, row_spinner, col_spinner, table, model, isColumn);
		}		
	}

	class TableSizeHalfChangeWorker extends SimpleWorker{
		protected JScrollPane scrollpane     = null;
		protected JSpinner row_spinner       = null;
		protected JSpinner col_spinner       = null;
		protected JComboBox<Integer> combo   = null;
		protected MatrixTable table          = null;
		protected MatrixTableModel model     = null;
		protected MatrixTableModel new_model = null;
		protected MatrixTableModel old_model = null;
		protected boolean isColumn = false;
		
		public TableSizeHalfChangeWorker(JComponent parent, JComponent root, JScrollPane scrollpane, JSpinner row_spinner, JSpinner col_spinner, MatrixTable table, MatrixTableModel model, boolean isColumn) {
			super(parent, root);
			this.scrollpane = scrollpane;
			this.row_spinner = row_spinner;
			this.col_spinner = col_spinner;
			this.table   = table;
			this.model   = model;
			this.isColumn = isColumn;
		}
		
		@Override
		public void doTask(){
			/*
			SwingUtilities.invokeLater(new Runnable(){
				@Override
				public void run() {
					update();
				}
			});
			*/
			update();
		}
		
		protected void update(){//Note: for Valuation table
			int next_row_size = (Integer)row_spinner.getValue();
			int next_col_size = (Integer)col_spinner.getValue();
			
			if(Objects.nonNull(model)){
				initTask(1);
				
				//Copy old data
				String row_header = "";
				String col_header = "";

				old_model = model; 
				row_header = old_model.getRowHeader(); 
				col_header = old_model.getColumnHeader(); 
			
				//install_table_model
				new_model = install_table_model(row_header, col_header, next_row_size, next_col_size, table, true);
				
				//copy model
				copyTableModel(new_model, old_model);
				progress();
			}
		}
		
		@Override 
		public void done(){
			SwingUtilities.invokeLater(new Runnable(){

				@Override
				public void run() {
					model = new_model;
					install_table_headers(scrollpane, table);
					done0();//hack!
				}
				
			});
		}
		
		protected synchronized void copyTableModel(MatrixTableModel new_model, MatrixTableModel old_model){
			//copy data
			int row_size = new_model.getRowCount();
			int col_size = new_model.getColumnCount();
			
			int old_row_size = old_model.getRowCount();
			int old_col_size = old_model.getColumnCount();
			int data = 0;
			for(int i = 0; i < row_size; i++){
				if(i < old_row_size){
					for(int j = 0; j < col_size; j++){
						data = 0;
						if(j < old_col_size){ data = (int)old_model.getValueAt(i, j); 
							new_model.setValueAt(data, i, j);
						} else{ break; }
					}					
				}else{ break; }
			}
		}
		
		protected void done0(){
			super.done();
		}
	}
	
	class MapSizeChangeAction extends WorkerRunAction{
		protected Map<Integer, MatrixTableModel> map;
		protected JSpinner spinner = null;
		protected JSpinner col_spinner = null;
		protected JSpinner row_spinner = null;
		protected int value = -1;		
		protected String row_header = "";
		protected String col_header = "";
		
		public MapSizeChangeAction(JComponent parent, String caption, ExecutorService executor, JSpinner spinner, JSpinner col_spinner, JSpinner row_spinner, Map<Integer, MatrixTableModel> map, String row_header, String col_header){
			super(parent, caption, executor);
			this.map		= map;
			this.spinner 	= spinner;
			this.col_spinner = col_spinner;
			this.row_spinner = row_spinner;
			this.value 		= (Integer)spinner.getValue();
			this.row_header = row_header;
			this.col_header = col_header;
		}
		
		@Override
		protected SimpleWorker newSimpleWorker(JComponent progress_panel){
			return new MapSizeChangeWorker(progress_panel, parent, spinner, col_spinner, row_spinner, map, value, row_header, col_header);
		}	
		
		@Override
		public void stateChanged(ChangeEvent e) { //FIXME: If multi-threaded version is implemented, this method should be removed. 
			int next_value = (Integer)spinner.getValue();
			
			/*
			int diff = Math.abs(value-next_value);
			if(diff < multi_thread_threshold){ doActionByEDT(); } //single thread execution
			else{ doAction(); } //multi-thread execution
			*/
			doAction();
			value = next_value;
		}
		
		protected void doActionByEDT(){ //for single thread execution (by Event dispatch thread of Swing)
			worker = new MapSizeChangeWorker(null, parent, spinner, col_spinner, row_spinner, map, value, row_header, col_header);
			MapSizeChangeWorker worker_local = (MapSizeChangeWorker)worker;
			worker_local.doTask();
			value = worker_local.value;			
		}
	}
	
	
	class MapSizeChangeWorker extends SimpleWorker{
		protected Map<Integer, MatrixTableModel> map;
		protected JSpinner spinner = null;
		protected JSpinner col_spinner = null;
		protected JSpinner row_spinner = null;
		protected int value = -1;		
		protected String row_header = "";
		protected String col_header = "";

		public MapSizeChangeWorker(JComponent parent, JComponent root, JSpinner spinner, JSpinner col_spinner, JSpinner row_spinner, Map<Integer, MatrixTableModel> map, int value, String row_header, String col_header) {
			super(parent, root);
			this.map		= map;
			this.spinner 	= spinner;
			this.col_spinner = col_spinner;
			this.row_spinner = row_spinner;
			this.value 		= value;
			this.row_header = row_header;
			this.col_header = col_header;
		}
		
		@Override
		public void doTask(){
			update();
		}
		
		protected synchronized void update(){
			int next_value = (Integer)spinner.getValue();
			if(next_value < value){
				initTask(value - next_value);
				for(int i = value; next_value < i; i--){
					map.remove(i);
					progress();
				}
			}else if(value < next_value){
				int row_size = (Integer)row_spinner.getValue();
				int col_size = (Integer)col_spinner.getValue();

				initTask(next_value -value);
				for(int i = value; i < next_value; i++){
					MatrixTableModel model = MatrixTableModel.newInstance(row_header, col_header, row_size, col_size);
					map.put(i+1, model);
					progress();
				}
			}else{ initTask(1); progress();} //do nothing 
			value = next_value;						
		}
	}
	
	class ComboBoxChangeAction implements ActionListener{
		protected Map<Integer, MatrixTableModel> map;
		protected MatrixTable table;
		
		public ComboBoxChangeAction(Map<Integer, MatrixTableModel> map, MatrixTable table){
			this.map = map;
			this.table = table;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() instanceof JComboBox){
				JComboBox<Integer> comboBox = (JComboBox<Integer>)e.getSource();
				final MatrixTableModel model = map.get(comboBox.getSelectedItem());
				if(Objects.nonNull(model)){
					SwingUtilities.invokeLater(new Runnable(){
						@Override
						public void run() {
							table.setModel(model);
						}
					}); 
				}				
			}
		}
	}
	
	class ComboBoxRenewAction implements ChangeListener{
		protected JComboBox<Integer> comboBox;		
		
		public ComboBoxRenewAction(JComboBox<Integer> comboBox){
			this.comboBox = comboBox;
		}
		
		@Override
		public void stateChanged(ChangeEvent e) {
			if(e.getSource() instanceof JSpinner){
				JSpinner spinner = (JSpinner)e.getSource();
				setComboBoxModel(comboBox, spinner);
				comboBox.setSelectedIndex(0); //this method calls following comboBox.actionListener() 				
			}
		}
	}
	
	class ClearAction implements ActionListener{
		protected JTextArea area;
		protected JTextField field;
		
		public ClearAction(JTextArea area, JTextField field){
			this.area = area;
			this.field = field;
		}
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			area.setText("");
			field.requestFocusInWindow();
		}
	}
	
	class CopyAction implements ActionListener{
		
		protected JTextArea area;
		protected JTextField field;
		
		public CopyAction(JTextArea area, JTextField field){
			this.area = area;
			this.field = field;
		}
		
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			//stream_area.copy();
			Toolkit tk = Toolkit.getDefaultToolkit();
			Clipboard clip = tk.getSystemClipboard();
			String str = area.getText();
			if(str != null){
				StringSelection ss = new StringSelection(str);
				clip.setContents(ss, ss);						
			}
			field.requestFocusInWindow();
		}
	}
	
	class HelpAction implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println(getHelpText());
			
		}
		
		public String getHelpText(){
			String[] text = new String[]{ "USAGE: "
					, "---Calculator of `Truth Set' ---"
					, "Please input `FORMULA' to the above text field then press [||\\varphi||] button or [ENTER] key or [Alt + ENTER] key."
					, "If FORMULA is successfully calculated, the resultant matrix appears to console window."
					, ""
					, "Syntax of FORMULA::="
					, "PROPOSITION |"  
					, "\\chl{FROM_AGENT TO_AGENT} | //channel constant"
					, "\\neg FORMULA | "
					, "FORMULA \\lor FORMULA |"
					, "FORMULA \\land FORMULA |" 
					, "FORMULA \\to FORMULA | //implication"
					, "[PROGRAM_TERM] FORMULA | //Box operator"
					, "<PROGRAM_TERM> FORMULA | //Diamond operator" 
					, ""
					, "Syntax of PROGRAM_TERM::="
					, "\\rel{AGENT} | // This is atomic program term."
					, "PROGRAM_TERM \\cup PROGRAM_TERM | //non-deterministic choice"
					, "PROGRAM_TERM \\; PROGRAM_TERM | //composition"
					, "\\? PROGRAM_TERM | test"
					, "\\cmf{FORMULA}{AGENT}{AGENT} //semi-private announcement"
					, ""
					, "NOTE: You may use parenthesis, i.e., `(' and `)'."
					, "Remark: Above syntax is based on TeX command. At the end of this HELP, We show TeX source which is not predefined in TeX, e.g., `\\chl' and `\\?'."
					, ""
					, "EXAMPLE: "
					, "((p_1 \\to p_2) \\to p_1) \\to p_1 [ENTER]"
					, "[\\cmf{p_1}{a_1}{a_2}] p_1 [ENTER]"
					, ""
					, "---Frame property verifier---"
					, "Please input following option to the text field or leave empty then press [FP] button or [Alt + F] key."
					, "OPTIONS::= AGENT | all "
					, ""
					, "EXAMPLE: "
					, "[FP] //verify frame property of current editing relation"
					, "a_1 [FP]"
					, "all [FP] //verify frame property of all relations"
					, ""
					, "---Visualization---"
					, "Please input an id of AGENT or WORLD  just click [Viz] button."
					, "Please input following option to the text field or leave empty then press [Viz] button or [Alt + V] key."
					, "OPTIONS::= AGENT | WORLD | all"
					, ""
					, "EXAMPLE: "
					, "[Viz] //visualize relation of current editiong one"
					, "a_1 [Viz] //visualize relation of an agent a_1"
					, "w_1 [Viz] //visualize channel relation at w_1 for every agent"
					, ""
					, "If this function is successfully finished, output jpeg file will appear on a window."
					, "Note: Output `dot' files and `jpeg' files are saved under `INSTALLED_DIR/dot' directory."
					, ""
					, "---TeX command---"
					, "Here are TeX source which are not predefined in TeX:", 
					"\\newcommand{\\rel}[1]{\\mathop{\\mathsf{R}_{#1}}}", 
					"\\newcommand{\\chl}[1]{\\mathsf{c}_{{#1}}}",
					"\\newcommand{\\cmf}[3]{{[{#1}\\!\\!\\downarrow^{#2}_{#3}]}}",
					"\\newcommand{\\?}{?}",
					"\\renewcommand{\\;}{;}",
					""};
			StringBuilder sb = new StringBuilder();
			for(String s: text){
				sb.append(s + crlf);
			}
			return sb.toString();
		}
	}	
	
	protected class ShutdownHandler extends WindowAdapter implements ActionListener{
		protected JFrame frame;
		
		public ShutdownHandler(JFrame frame){
			super();
			this.frame = frame;
		}
		
		@Override
		public void windowClosing(WindowEvent e){
			confirmExit();
		}
				
		public void confirmExit(){
			int opt = JOptionPane.showConfirmDialog(frame, "Exit Calculator?", "Confirm Exit", JOptionPane.YES_NO_OPTION);
			if(opt == JOptionPane.YES_OPTION){ doShutdownSequence(); }
		}
		
		public void doShutdownSequence(){
			if(Objects.nonNull(executor)){ executor.shutdown(); }
			System.exit(0);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			confirmExit();
		}
	}
	
	class CellMouseAction extends MouseAdapter{
		
		MatrixTable table = null;
		
		public CellMouseAction(MatrixTable table){
			super();
			this.table = table;
		}
		
		public void mouseClicked(MouseEvent e){
			if(Objects.nonNull(table)){
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				//System.err.print("(" + row + "," + col + ")=");
				//System.err.println(table.getValueAt(row, col));
				if(row >= 0 && col >= 0){ //Note: row, col becomes -1 if we click table directly after adding some worlds/agents
					try{
						Object obj = table.getValueAt(row, col);
						if(obj != null){
							int val = Integer.parseInt(obj.toString());
							if(val == 0) {val = 1; }
							else {val = 0; }
							table.setValueAt(val, row, col);						
						}
					}catch(NumberFormatException ne){table.setValueAt(0, row, col);}					
				}
			}
		}
	}	

/*	
	class CellAddAction implements ActionListener{
		
		final static int START_HEIGHT = 4;
		final static int START_WIDTH  = 4;
		final static int EXPAND_SPEED_HEIGHT = 1;
		final static int EXPAND_SPEED_WIDTH = 3;
		final static int FIX = 0;
		MatrixTable table;
		int h = START_HEIGHT;
		int w = START_WIDTH;
		int i;
		int end;
		boolean isColumn = false;
		TableColumn col;
		
		public CellAddAction(MatrixTable table, int i, boolean isColumn){
			this.table = table;
			this.i = i;
			this.isColumn = isColumn;
			if(isColumn){ 
				TableColumnModel col_model = table.getColumnModel();
				int col_size = col_model.getColumnCount();
				col =  col_model.getColumn(col_size - 1);
				this.end = col.getWidth(); 
				col.setPreferredWidth(w);
			} else { this.end = table.getRowHeight() + FIX; }
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(isColumn){ expandColumn((Timer)e.getSource()); }
			else{ expandRow((Timer)e.getSource()); }
			
		}
		
		public void expandColumn(Timer timer){
			if(w < end){
				w += EXPAND_SPEED_WIDTH;
				col.setPreferredWidth(w);
			}else{
				timer.stop();
			}						
		}
		
		public void expandRow(Timer timer){
			if(h < end){
				h += EXPAND_SPEED_HEIGHT;
				table.setRowHeight(i, h);
			}else{
				timer.stop();
			}			
		}
	}
*/
	
/*	
	class CellDeleteAction implements ActionListener{
		final static int START_HEIGHT = 0;
		final static int START_WIDTH  = 0;
		final static int CONTRACT_SPEED_HEIGHT = 1;
		final static int CONTRACT_SPEED_WIDTH = 3;
		ExtendedTable table;
		int h;
		int w;
		int i;
		int end; 
		
		boolean isColumn = false;
		TableColumn col;		
		
		public CellDeleteAction(ExtendedTable table, int i, boolean isColumn){
			this.table = table;
			this.i = i;
			
			this.isColumn = isColumn;
			if(isColumn){
				TableColumnModel col_model = table.getColumnModel();
				int col_size = col_model.getColumnCount();
				col =  col_model.getColumn(col_size - 1);
				this.end = col.getWidth(); 
				//col.setPreferredWidth(w);
			}else{
				this.end = table.getRowHeight();
			}
			this.h = this.end;
		}
		
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if(isColumn){ contractColumn((Timer)e.getSource()); }
			else{ contractRow((Timer)e.getSource());	}
		}
		
		public void contractColumn(Timer timer){
			w-= CONTRACT_SPEED_WIDTH;
			if(h > START_HEIGHT){
				col.setPreferredWidth(w);
			}else{
				timer.stop();		
			}		
		}
		
		public void contractRow(Timer timer){
			h-= CONTRACT_SPEED_HEIGHT;
			if(h > START_HEIGHT){
				table.setRowHeight(i, h);
			}else{
				timer.stop();
			}
		}
	}
*/	
}
