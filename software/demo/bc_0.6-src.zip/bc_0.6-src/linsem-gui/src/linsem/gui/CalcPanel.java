package linsem.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.text.BadLocationException;

import linsem.gui.text.ComboKeyListener;
import linsem.gui.text.StreamRedirectArea;
import linsem.gui.text.ThumbnailTabbedPane;
import linsem.gui.thread.DoubleWorkerRunAction;
import linsem.gui.thread.WorkerRunAction;


public class CalcPanel extends JPanel {

	private static final long serialVersionUID = 3382999472900954495L;

	//GUI components
	//protected GUIMain root 			= null;
	protected JPanel toolbar_panel  = null;
	protected JPanel param_panel 	= null;
	protected JPanel console_panel  = null;
	protected JPanel tabbed_panel   = null;
	protected JTabbedPane tabbed_pane = null;
	protected JPanel control_panel 	= null;
	protected JScrollPane progress_scrollPane = null;
	protected JPanel progress_panel = null;
	
	//Tool bars
	protected JToolBar formula_toolBar  	= null;
	protected JToolBar program_toolBar  	= null;
	protected JToolBar modal_axiom_toolBar 	= null;

	//for parameter field (input)
	protected JTextField command_field  	= null;
	protected JComboBox<String> command_box	= null;
	protected final static String[] PRESET_COMMANDS = {"p_1 \\to \\neg p_1", "a_1", "w_1", "all"};
	protected int default_field_size 	= 30;
	protected String default_field_text = "p_1";
	
	//for command buttons
	protected JButton calc_truth_set_button = null;
	protected JButton calc_frame_property_button = null;
	protected JButton viz_button 			= null;
	protected JButton clear_button			= null;
	protected JButton copy_button			= null;
	protected JButton help_button 			= null;
	
	//for console (output)
	protected StreamRedirectArea stream_area = null;
	protected int default_stream_area_row_size  = 30;
	protected int default_stream_area_col_size  = 75;
	
	public CalcPanel() {}
	
	public void initPanel(){
		setTitle("<html><h3>CALC</h3></html>");		
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(getToolbarPanel());
		add(getParamPanel());
		add(getConsolePanel());
		add(getTabbedPane());
		initButtons();		
	}
	
	public JPanel getToolbarPanel(){
		if(toolbar_panel == null){
			toolbar_panel = newDefaultPanel();
			
			//Formulas
			formula_toolBar = newDefaultToolBar(toolbar_panel);
			
			//Program terms
			program_toolBar = newDefaultToolBar(toolbar_panel);
			
			//Modal axioms
			modal_axiom_toolBar = newDefaultToolBar(toolbar_panel);			

			//Note: buttons for these toolbar will be initialized in `initToolbarButtons' after initializing command field.
		}
		return toolbar_panel;
	}
	
	public JPanel getParamPanel(){
		if(param_panel == null){
			param_panel 	= newDefaultPanel();
			command_box     = newDefaultComboBox(param_panel, "", PRESET_COMMANDS, default_field_size);
			command_field   = (JTextField)command_box.getEditor().getEditorComponent();
			command_field.addKeyListener(new ComboKeyListener(command_box));
			command_field.requestFocusInWindow();
		}
		return param_panel;
	}
	
	public JTabbedPane getTabbedPane(){
		if(tabbed_pane == null){
			tabbed_pane = newDefaultTabbedPane();
			tabbed_pane.addTab("Control", null, getControlPanel(), "dummy");
			
			progress_panel = getProgressPanel();
			tabbed_pane.addTab("Progress", null, getProgressScrollPane(), "dummy");			
		}
		return tabbed_pane;
	}
	
	public JPanel getControlPanel(){
		if(control_panel == null){
			control_panel = newDefaultPanel();
		}
		return control_panel;
	}
	
	public JScrollPane getProgressScrollPane(){
		if(progress_scrollPane == null){
			progress_scrollPane = new JScrollPane();
			progress_scrollPane.setViewportView(getProgressPanel());
		}
		return progress_scrollPane;
	}
	
	public JPanel getProgressPanel(){
		if(progress_panel == null){			
			progress_panel = newDefaultPanel();
			progress_panel.setLayout(new BoxLayout(progress_panel, BoxLayout.Y_AXIS));
			/*
			JPanel button_panel = new JPanel();
			progress_panel.add(button_panel);
			
			JButton btnAdd = new JButton("add");
			button_panel.add(btnAdd);
			btnAdd.addActionListener(new WorkerRunAction(progress_panel, "single"));
			
			JButton btnAdd2 = new JButton("add2");
			button_panel.add(btnAdd2);
			btnAdd2.addActionListener(new DoubleWorkerRunAction(progress_panel, "double"));
			*/
		}
		return progress_panel;
	}
	
	public JPanel getConsolePanel(){
		if(console_panel == null){
			console_panel = newDefaultPanel();						
			JScrollPane stream_scrollPane = new JScrollPane();
			stream_area = new StreamRedirectArea();
			stream_area.setSystemStream();
			stream_area.setRows(default_stream_area_row_size);
			stream_area.setColumns(default_stream_area_col_size);
			stream_area.setLineWrap(true);
			stream_area.setEditable(false);
			stream_area.setForeground(Color.GREEN);
			stream_area.setBackground(Color.DARK_GRAY);
			stream_area.setEditable(true);
			stream_area.setCaretColor(Color.GREEN);

			stream_scrollPane.setViewportView(stream_area);
			console_panel.add(stream_scrollPane);
			
			System.out.println("Console output (redirect from System.out):");
		}
		return console_panel;
	}

	public void initButtons(){
		initInsertButtons();
		initCommandButtons();
		initControlButtons();
	}
	
	public void initInsertButtons(){
		//Insert buttons for formulas
		newInsertButton(formula_toolBar, command_field, "<html>&nbsp; p &nbsp;</html>", "Atomic formula", "p_1");
		newInsertButton(formula_toolBar, command_field, "<html>c<sub>ab</sub><html>", "Channel constant", "\\chl{a_1 a_2} ");
		newInsertButton(formula_toolBar, command_field, "<html>&not;</html>", "Negation", "\\neg ");
		newInsertButton(formula_toolBar, command_field, "<html>&or;</html>", "Or", "\\lor ");
		newInsertButton(formula_toolBar, command_field, "<html>&and;</html>", "And", "\\land ");
		newInsertButton(formula_toolBar, command_field, "<html>&rarr;</html>", "Implication", "\\to ");
		newInsertButton(formula_toolBar, command_field, "<html>&#9671;</html>", "Diamond", "< \\rel{a_1} > ");
		newInsertButton(formula_toolBar, command_field, "<html>&#9633;</html>", "Box", "[ \\rel{a_1} ] ");
					
		//Insert buttons for program terms
		newInsertButton(program_toolBar, command_field, "<html>R<sub>a</sub></html>", "Atomic program", "\\rel{a_1} ");
		newInsertButton(program_toolBar, command_field, "<html>&cup;</html>", "Non-deterministic choice", "\\cup ");
		newInsertButton(program_toolBar, command_field, "<html>&nbsp; ; &nbsp;<html>", "Program composition", "\\; ");
		newInsertButton(program_toolBar, command_field, "<html>&nbsp; ? &nbsp;<html>", "Test", "\\? ");
		newInsertButton(program_toolBar, command_field, "<html>&darr;<sup>a</sup><sub>b</sub></html>", "Semi-private announcement", "\\cmf{p_1}{a_1}{a_2} ");
		//newInsertButton(program_toolBar, command_field, "<html>&darr;<sup>H</sup><html>", "Group announcement", "\\iac{p_1}{H} ").setEnabled(false);
		
		//Insert buttons for TB4D5
		newInsertButton(modal_axiom_toolBar, command_field, "<html>T</html>", "Reflexivity", "[\\rel{a_1}] p_1 \\to p_1");
		newInsertButton(modal_axiom_toolBar, command_field, "<html>B</html>", "Symmetricity", "p_1 \\to [\\rel{a_1}]<\\rel{a_1}>p_1 ");
		newInsertButton(modal_axiom_toolBar, command_field, "<html>4</html>", "Transitivity", "[\\rel{a_1}] p_1 \\to [\\rel{a_1}]([\\rel{a_1}]p_1)");
		newInsertButton(modal_axiom_toolBar, command_field, "<html>D</html>", "Seriality", "[\\rel{a_1}] p_1 \\to <\\rel{a_1}>p_1");
		newInsertButton(modal_axiom_toolBar, command_field, "<html>5</html>", "Euclideanness", "<\\rel{a_1}> p_1 \\to [\\rel{a_1}]<\\rel{a_1}>p_1");
	}
	
	public void initCommandButtons(){
		newDefaultButton(param_panel, "x", -1, new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				command_field.setText("");
				command_field.requestFocusInWindow();
			}
		});
		calc_truth_set_button = newDefaultButton(param_panel, "<html>||&phi||</html>", KeyEvent.VK_ENTER, null);			
		calc_frame_property_button = newDefaultButton(param_panel, "FP", KeyEvent.VK_F, null);			
		viz_button = newDefaultButton(param_panel, "Viz", KeyEvent.VK_V, null);					
	}
	
	public void initControlButtons(){
		clear_button = newDefaultButton(control_panel, "Clear", KeyEvent.VK_L, null);
		copy_button = newDefaultButton(control_panel, "Copy", KeyEvent.VK_C, null);
		help_button = newDefaultButton(control_panel, "Help", KeyEvent.VK_H, null);		
	}
	
//------	
	
	public void setTitle(String title) {
		setBorder(new TitledBorder(null, title, TitledBorder.LEADING,
				TitledBorder.TOP, null, null));
	}
		
	public JComboBox<String> newDefaultComboBox(JComponent parent, String caption, String[] data, int size){
		if(caption!=null){
			JLabel label = new JLabel(caption);
			parent.add(label);
		}
		if(data == null)data = new String[]{};
		JComboBox<String> combo = new JComboBox<String>(data);
		combo.setEditable(true);
		combo.setSelectedIndex(-1);
		JTextField field = (JTextField)combo.getEditor().getEditorComponent();
		field.setColumns(size);		
		field.setText("");

		parent.add(combo);
		return combo;
	}	
	
	public JButton newDefaultButton(JComponent parent, String caption, int nemonic, ActionListener listener){
		JButton button = new JButton(caption);
		button.addActionListener(listener);
		if(nemonic > 0) button.setMnemonic(nemonic);
		parent.add(button);
		return button;
	}
	
	public JToolBar newDefaultToolBar(JComponent parent){
		JToolBar toolBar = new JToolBar();
		toolBar.setOrientation(SwingConstants.HORIZONTAL);
		parent.add(toolBar);
		return toolBar;
	}
	
	public JButton newInsertButton(JComponent parent, final JTextField field, String caption, String toolTip, final String text){
		JButton button = new JButton(caption);
		button.setToolTipText(toolTip);
		button.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				int pos = field.getCaretPosition();
				try {
					field.getDocument().insertString(pos, text, null);
				} catch (BadLocationException e1) {
					e1.printStackTrace();
				}
				field.requestFocusInWindow();
			}
			
		});
		parent.add(button);
		Dimension d = parent.getMaximumSize();
		d.width = 30;
		button.setMaximumSize(d);
		return button;
	}

	public JPanel newDefaultPanel() {
		JPanel panel = new JPanel();
		panel.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.setAlignmentY(Component.TOP_ALIGNMENT);
		FlowLayout flowLayout = (FlowLayout) panel.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		return panel;
	}	
	
	public JTabbedPane newDefaultTabbedPane(){
		JTabbedPane tabbed_pane = new ThumbnailTabbedPane();
		tabbed_pane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		tabbed_pane.setAlignmentX(Component.LEFT_ALIGNMENT);
		tabbed_pane.setAlignmentY(Component.TOP_ALIGNMENT);
		return tabbed_pane;
	}
}

