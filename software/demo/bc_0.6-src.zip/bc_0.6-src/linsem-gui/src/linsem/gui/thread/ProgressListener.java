package linsem.gui.thread;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Objects;

import javax.swing.JLabel;
import javax.swing.JProgressBar;

public 	class ProgressListener implements PropertyChangeListener{

	protected final JProgressBar bar;
	protected final JLabel time_label;
	
	public ProgressListener(JProgressBar bar, JLabel time_label){
		this.bar = bar;
		this.bar.setValue(0);
		this.time_label = time_label;
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent e) {
		if(e.getSource() instanceof SimpleWorker){
			SimpleWorker worker = (SimpleWorker)e.getSource();
			if(!bar.isDisplayable()){
				//progress: DISPOSE_ON_CLOSE
				worker.cancel(true);
			}

			if("progress".equals(e.getPropertyName())){
				bar.setIndeterminate(false);
				int progress = (Integer)e.getNewValue();
				bar.setValue(progress);
				if(Objects.nonNull(time_label)){
					setRemainingTime(time_label, worker.getStartTime(), worker.getTaskSize(), worker.getCurrentDoneTask());
				}
			}
		}
	}
	
	protected void setRemainingTime(JLabel label, long start_time, int task_size, int curr_done_task){
		long curr_time   = System.currentTimeMillis();
		long passed_time = curr_time - start_time; 
		if(curr_done_task > 0){
			long estimate_total_time = (passed_time / curr_done_task) * task_size;
			long estimate_remaining_time = (estimate_total_time - passed_time) / 1000;
			
			long estimate_hour = estimate_remaining_time / 3600;
			long estimate_min  = estimate_remaining_time % 3600 / 60;
			long estimate_sec  = estimate_remaining_time % 60;
			
			String hour = formatTime(estimate_hour);
			String min  = formatTime(estimate_min);
			String sec  = formatTime(estimate_sec);
			
			String time = hour + ":" + min + ":" + sec;
			label.setText(time);			
		}else{
			label.setText("--:--:--");
		}
	}
	
	protected String formatTime(long time){
		String res = "";
		if(time < 10) res += "0";
		return res += String.valueOf(time);
	}
	
}