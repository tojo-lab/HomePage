package linsem.gui.thread;

import java.beans.PropertyChangeEvent;
import java.util.Objects;

import javax.swing.JLabel;
import javax.swing.JProgressBar;

public 	class DoubleProgressListener extends ProgressListener{

	protected final JProgressBar sub_bar;
	protected final JLabel sub_time_label;
	
	public DoubleProgressListener(JProgressBar main_bar, JProgressBar sub_bar, JLabel time_label, JLabel sub_time_label) {
		super(main_bar, time_label);
		this.sub_bar = sub_bar;
		this.sub_bar.setValue(0);
		this.sub_time_label = sub_time_label;
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent e) {
		super.propertyChange(e);
		if(e.getSource() instanceof DoubleWorker){
			DoubleWorker worker = (DoubleWorker)e.getSource();
			if(!bar.isDisplayable()){
				//progress: DISPOSE_ON_CLOSE
				worker.cancel(true);
			}			
			
			if("progress_sub".equals(e.getPropertyName())){
				sub_bar.setIndeterminate(false);
				int progress = (Integer)e.getNewValue();
				sub_bar.setValue(progress);
				if(Objects.nonNull(sub_time_label)){
					setRemainingTime(sub_time_label, worker.getSubStartTime(), worker.getSubTaskSize(), worker.getCurrentDoneSubTask());
				}
			}			
		}
	}		
}