package linsem.gui.thread;

import java.awt.event.ActionEvent;
import java.util.Objects;

import javax.swing.AbstractAction;
import javax.swing.SwingWorker;

public 	class WorkerCancelAction extends AbstractAction{

	protected SimpleWorker worker;
	
	public WorkerCancelAction(SimpleWorker worker){
		super("cancel");
		this.worker = worker;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(Objects.nonNull(worker) && !worker.isDone()){
			worker.cancel(true);
			worker.removeParent();
		}
	}
}
