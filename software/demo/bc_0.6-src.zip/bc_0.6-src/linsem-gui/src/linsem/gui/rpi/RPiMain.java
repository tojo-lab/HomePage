package linsem.gui.rpi;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.util.concurrent.Executors;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import linsem.gui.CalcPanel;
import linsem.gui.EditorPanel;
import linsem.gui.GUIMain;
import linsem.gui.text.ThumbnailTabbedPane;

public class RPiMain extends GUIMain{

	protected int gui_width		= 800;
	protected int gui_height	= 480;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) { 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					GUIMain frame = new RPiMain();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public RPiMain() {
		//for scheduler
		this.executor = Executors.newSingleThreadExecutor();
		
		setTitle(ID + "(ver. " + VERSION + ")");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		ShutdownHandler handler = new ShutdownHandler(this);
		addWindowListener(handler); 
		
		setBounds(100, 100, gui_width, gui_height);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		
		//JScrollPane scrollPane = new JScrollPane();
		//contentPane.add(scrollPane, BorderLayout.CENTER);

		
		JPanel panel = new JPanel();
		//scrollPane.setViewportView(panel);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		//TODO: here should be main Tabbed pane ------------
		JTabbedPane tabbed_pane = new ThumbnailTabbedPane();
		tabbed_pane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		tabbed_pane.setAlignmentX(Component.LEFT_ALIGNMENT);
		tabbed_pane.setAlignmentY(Component.TOP_ALIGNMENT);
		panel.add(tabbed_pane, BorderLayout.CENTER);

		// for model editor
		//editor_panel = new EditorPanel();
		editor_panel = new RPiEditorPanel();
		editor_panel.initPanel();
		tabbed_pane.addTab("<html><h3>Kripke Model</h3></html>", null, editor_panel, "dummy");
		editor_panel.setAlignmentY(Component.TOP_ALIGNMENT);
		editor_panel.setLayout(new BoxLayout(editor_panel, BoxLayout.Y_AXIS));	
		
		// for control panel and outputs
		calc_panel = new RPiCalcPanel();
		calc_panel.initPanel();
		tabbed_pane.addTab("<html><h3>CALC</h3></html>", null, calc_panel, "dummy");
		calc_panel.setAlignmentX(Component.LEFT_ALIGNMENT);
		calc_panel.setAlignmentY(Component.TOP_ALIGNMENT);
		
		/*
		JSplitPane splitPane = new JSplitPane();
		splitPane.setOneTouchExpandable(true);
		splitPane.setDividerSize(8);
		splitPane.setLeftComponent(editor_panel);
		splitPane.setRightComponent(calc_panel);
		splitPane.setDividerLocation(520);
		panel.add(splitPane, BorderLayout.CENTER);
		*/
		// -------------------------------------------------
		
		status_bar = new JTextField();
		status_bar.setText("Ready.");
		status_bar.setEditable(false);
		contentPane.add(status_bar, BorderLayout.SOUTH);
		//status_bar.setColumns(10);
		
		//for menu bar
		contentPane.add(getMainMenuBar(), BorderLayout.NORTH);
		
		//inject event actions
		install_shared_listeners();
		
		//final processing before launching
		setVerboseForModelSizeEdit(show_model_size_edit_item.isSelected());
		setBackgroundExecutionsForModelSizeEdit(bg_model_size_edit_item.isSelected());	
		setBackgroundExecutionsForModelGeneration(bg_model_generation_item.isSelected());	
		setBackgroundExecutionsForCalculation(bg_calc_item.isSelected());	
		setBackgroundExecutionsForVisualization(bg_viz_item.isSelected());
	}
}
