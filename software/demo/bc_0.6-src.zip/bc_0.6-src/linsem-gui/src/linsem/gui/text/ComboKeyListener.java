package linsem.gui.text;

import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class ComboKeyListener extends KeyAdapter{
	protected final JComboBox<String> combo;
	protected final List<String> list;
	protected boolean shouldHide;
	
	public ComboKeyListener(JComboBox<String> combo){
		super();
		this.combo = combo;
		list = new ArrayList<String>();
		for(int i = 0; i < combo.getModel().getSize(); i++){
			list.add(combo.getItemAt(i));
		}
	}
	
	@Override
	public void keyTyped(final KeyEvent e){
		EventQueue.invokeLater(new Runnable(){

			@Override
			public void run() {
				String input = ((JTextField)e.getComponent()).getText();
				ComboBoxModel<String> model;
				if(input == null || input.isEmpty()){
					String[] args = list.toArray(new String[list.size()]);
					model = new DefaultComboBoxModel<String>(args);
					setSuggestionModel(combo, model, "");
					combo.hidePopup();
				}else{
					model = getSuggestedModel(list, input);
					if(model.getSize() == 0 || shouldHide){
						combo.hidePopup();
					}else{
						setSuggestionModel(combo, model, input);
						combo.showPopup();
					}
				}
			}
			
		});
	}
	
	@Override
	public void keyPressed(KeyEvent e){
		JTextField field = (JTextField)e.getComponent();
		String text = field.getText();
		shouldHide = false;
		
		switch(e.getKeyCode()){
			case KeyEvent.VK_RIGHT: //Auto-complete
				for(String s: list){
					if(s.startsWith(text)){
						field.setText(s);
						break;
					}
				}
				break;
			case KeyEvent.VK_ENTER:
				if(!list.contains(text)){
					list.add(0, text);
					//Collections.sort(list); //This is not necessary to record input history
					setSuggestionModel(combo, getSuggestedModel(list, text), text);
				}
				shouldHide = true;
				break;
			case KeyEvent.VK_ESCAPE:
				shouldHide = true;
				break;
			default:
				break;
		}
	}
	
	protected static void setSuggestionModel(JComboBox<String> combo, ComboBoxModel<String> model, String text){
		combo.setModel(model);
		combo.setSelectedIndex(-1);
		((JTextField)combo.getEditor().getEditorComponent()).setText(text);
	}
	
	protected static ComboBoxModel<String> getSuggestedModel(List<String> list, String text){
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>();
		for(String s: list){
			if(s.startsWith(text)){
				model.addElement(s);
			}
		}
		return model;
	}
}
