package linsem.gui.thread;

public 	class ProgressData{ 
	public final Object value;
	public final WorkerState state;
	public ProgressData(WorkerState state, Object value){
		this.state = state;
		this.value = value;
	}
}