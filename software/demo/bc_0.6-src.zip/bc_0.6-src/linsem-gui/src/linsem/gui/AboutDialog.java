package linsem.gui;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.BoxLayout;

import java.awt.Component;

import javax.swing.SwingConstants;

public class AboutDialog extends JDialog {

	private JPanel contentPane;
	protected final static int scale = 50;
	protected final static String file_path = "./resources/topfigure.jpg";
	protected final static String url_tojo_lab = "http://cirrus.jaist.ac.jp:8080/soft/bc";
	protected final static String url_JAIST = "http://www.jaist.ac.jp";
	protected final String ID;
	protected final double VERSION;

	/**
	 * Create the frame.
	 */
	public AboutDialog(Frame owner,String id, double version) {
		super(owner);
		this.ID = id;
		this.VERSION = version;
		setResizable(false);
		setTitle("About");
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 440, 310);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		JLabel label_title = new JLabel("<html><h2>"+ this.ID + "</h2>Version " + this.VERSION + "<br>Copyright(C) 2014-2015 by Tojo-lab, JAIST.</html>");
		label_title.setHorizontalAlignment(SwingConstants.LEFT);
		panel.add(label_title);

		//panel.add(get_image_label()); //TODO: if I get a permission, this will be available.
		
		JLabel label_tojo_lab = new JLabel(get_url_label("Tojo-lab", url_tojo_lab));
		label_tojo_lab.setHorizontalAlignment(SwingConstants.LEFT);
		label_tojo_lab.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e) {
				open_webcite(url_tojo_lab);
			}
		});
		panel.add(label_tojo_lab);
		
		JLabel label_JAIST = new JLabel(get_url_label("JAIST", url_JAIST));
		label_JAIST.addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e) {
				open_webcite(url_JAIST);
			}
		});
		panel.add(label_JAIST);
		
		JPanel panel_btn = new JPanel();
		contentPane.add(panel_btn, BorderLayout.SOUTH);
		panel_btn.setLayout(new BorderLayout(0, 0));
		
		JButton btn_OK = new JButton("OK");
		btn_OK.addActionListener(new DialogCloseAction(this));
		panel_btn.add(btn_OK, BorderLayout.EAST);
		
		pack();
		setLocationRelativeTo(null);
	}
		
	public String get_url_label(String title, String url){
		return "<html>"+ title +": <a href=\"" + url + "\">" + url + "</a></html>";
	}

	public void open_webcite(String url){
		Desktop dp = Desktop.getDesktop();
		try {
			dp.browse(new URL(url).toURI());
		} catch (IOException | URISyntaxException e1) {
			e1.printStackTrace();
		}		
	}

	public JLabel get_image_label(){
		try {
			BufferedImage image = ImageIO.read(new File(file_path));
			int width = image.getWidth();
			Image scaled_image = image.getScaledInstance(width * scale / 100, -1, Image.SCALE_AREA_AVERAGING | Image.SCALE_SMOOTH);
			JLabel label_image = new JLabel(new ImageIcon(scaled_image));
			label_image.addMouseListener(new MouseAdapter(){
				@Override
				public void mouseClicked(MouseEvent e) {
					open_webcite(url_tojo_lab);
				}
			});
			return label_image;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
		
	class DialogCloseAction implements ActionListener{
		
		protected JDialog owner;
		
		public DialogCloseAction(JDialog owner){
			this.owner = owner;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			if(owner!=null) owner.dispose();
		}
		
	}
}
