package linsem.gui;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import linsem.gui.table.MatrixTableModel;
import linsem.model.ChanneledKripkeModel;
import linsem.util.UJMPUtil;

import org.ujmp.core.matrix.SparseMatrix;

public class EditorModelPanel extends EditorPanel implements ChanneledKripkeModel<String, SparseMatrix>{
	private static final long serialVersionUID = -3192410563054342776L;
	
	protected final static int min = 1; 
	

	@Override
	public List<String> getW() {
		return listOf(world_prefix + delimiter, min, sizeW());
	}

	@Override
	public int sizeW() {
		if(Objects.nonNull(world_spinner)){ return (int)world_spinner.getValue(); }
		else{ return -1; }
	}

	@Override
	public void setW(List<String> w) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	@Override
	public void setW(String[] w) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}
	
	@Override
	public List<String> getG() {
		return listOf(agent_prefix + delimiter, min, sizeG());
	}

	@Override
	public int sizeG() {
		if(Objects.nonNull(agent_spinner)){ return (int)agent_spinner.getValue(); }
		else{ return -1; }
	}

	@Override
	public void setG(List<String> g) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	@Override
	public void setG(String[] g) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	@Override
	public Map<String, SparseMatrix> getR() {
		Map<String, SparseMatrix> R = new LinkedHashMap<String, SparseMatrix>();
		int size = sizeG();
		List<String> W = getW();
		List<String> G = getG();
		for(int i = 0; i < size; i++){
			MatrixTableModel relation_a_model  	= relation_map.get(i+1); //FIXED: + 1 should be removed if we starts with 0.  
			SparseMatrix R_a = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(relation_a_model));
			UJMPUtil.setMatrixLabels(R_a, W.toArray(new String[0]), W.toArray(new String[0]));
			String a = G.get(i);
			R.put(a, R_a);
		}
		return R;
	}

	@Override
	public void setR(Map<String, SparseMatrix> r) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}	
	
	@Override
	public Map<String, SparseMatrix> getC() {
		Map<String, SparseMatrix> C = new LinkedHashMap<String, SparseMatrix>();
		int size = sizeW();
		List<String> W = getW();
		List<String> G = getG();		
		for(int i = 0; i < size; i++){
			MatrixTableModel channel_model = (MatrixTableModel) channel_map.get(i+1);			
			SparseMatrix c_w = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(channel_model));
			UJMPUtil.setMatrixLabels(c_w, G.toArray(new String[0]), G.toArray(new String[0]));
			String w = W.get(i);
			C.put(w, c_w);
		}		
		return C;
	}

	@Override
	public void setC(Map<String, SparseMatrix> c) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}
	
	@Override
	public List<String> getP() {
		return listOf(proposition_prefix + delimiter, 1, sizeP());
	}
	
	@Override
	public int sizeP(){
		if(Objects.nonNull(proposition_spinner)) { return (int)proposition_spinner.getValue(); }
		else{ return -1; }
	}

	@Override
	public void setP(List<String> p) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	@Override
	public void setP(String[] p) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	@Override
	public SparseMatrix getV() {
		MatrixTableModel valuation_model = (MatrixTableModel) valuation_table.getModel();
		SparseMatrix V = UJMPUtil.matrix2boolmatrix(UJMPUtil.table2matrix(valuation_model));
		UJMPUtil.setMatrixLabels(V, getW().toArray(new String[0]), getP().toArray(new String[0]));
		return V;
	}

	@Override
	public void setV(SparseMatrix v) throws Exception {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	@Override
	public void clear() {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}
	
	public List<String> listOf(String prefix, int begin, int end){//FIXME: <= makes trouble when we change begin from 0.
		if(begin > end) return null;
		List<String> list = new ArrayList<String>();
		for(int i = begin; i <= end; i++){
			list.add(prefix + i);
		}
		return list;
	}
}
