package linsem.gui.thread;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class DoubleProgressPanel extends SimpleProgressPanel{

	protected JProgressBar sub_bar;
	protected JLabel sub_time_label;
	
	public DoubleProgressPanel(String caption) {
		super(caption);
	}

	@Override
	protected void initBar(){
		//super.initBar();
		bar      = new JProgressBar(0, 100);
		sub_bar  = new JProgressBar(0, 100);
		bar.setIndeterminate(true);
		bar.setStringPainted(true);
		sub_bar.setIndeterminate(true);
		sub_bar.setStringPainted(true);
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(bar);
		panel.add(sub_bar);
		add(panel);
	}
	
	@Override
	protected void initTimeLabel(){
		time_label = new JLabel("--:--:--");
		sub_time_label = new JLabel("--:--:--");
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(time_label);
		panel.add(sub_time_label);
		add(panel);
	}
	
	@Override
	public JProgressBar getSubBar(){
		return sub_bar;
	}
	
	@Override
	public JLabel getSubTimeLabel() {
		return sub_time_label;
	}
}
