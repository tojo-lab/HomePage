package linsem.gui.rpi;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import linsem.gui.CalcPanel;

public class RPiCalcPanel extends CalcPanel{
		
	public RPiCalcPanel() {}
	
	public void initPanel(){
		//setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setLayout(new BorderLayout(0, 0));
		default_stream_area_row_size  = 10;
		default_stream_area_col_size  = 75;
		add(getInputPanel(), BorderLayout.NORTH);
		command_field.setPreferredSize(new Dimension(200, 25));
		add(getConsolePanel(), BorderLayout.CENTER);
		initButtons();		
	}
	
	public JPanel getInputPanel(){
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(getToolbarPanel());
		panel.add(getParamPanel());
		panel.add(getTabbedPane());
		return panel;
	}
	
}
