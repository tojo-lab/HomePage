package linsem.gui.thread;

import java.util.List;

import javax.swing.JComponent;

public 	class DoubleWorker extends SimpleWorker{
	protected int sub_curr = 0;
	protected int sub_task_size = 0;
	protected long sub_start_time = 0;
	
	public DoubleWorker(JComponent parent, JComponent root) {
		super(parent, root);
	}

	@Override
	protected void process(List<ProgressData> chunks){ //Handled by event dispatch thread (EDT)
		if(isCancelled()) return;
		/*
		if(!parent.isDisplayable()){
			//process: DISPOSE_ON_CLOSE
			cancel(true);
			return;
		}*/
		
		for(ProgressData chunk: chunks){
			switch(chunk.state){
				case MAIN: 
					//bar.setValue((Integer)chunk.value); 
					setProgress((Integer)chunk.value);
					break;
				case SUB:
					setSubProgress((Integer)chunk.value);
					break;
				case LOG:
					System.out.println((String)chunk.value);
					break;
				case WORK:
					System.out.print((String)chunk.value);
					break;
				case PAUSE:
					blink((Boolean)chunk.value);
					break;
				default:
					throw new AssertionError("Unknown state");
			}				
			//if(!isCancelled())System.out.print(chunk);
		}
	}

	protected final void setSubProgress(int progress){
		firePropertyChange("progress_sub", progress, progress + 1);
	}
	
	@Override
	protected void doTask(){
		initTask(50);
		publish(new ProgressData(WorkerState.LOG, "Size of task: " + task_size));
		publish(new ProgressData(WorkerState.LOG, "\n---------------\n"));
		while(curr < task_size && !isCancelled()){ //Main loop			
			//do sub task
			try{ doSubTask(); }catch(InterruptedException e){ break; }
			
			//do main task
			publish(new ProgressData(WorkerState.WORK, "."));
			progress();
		}
	}
	
	protected void doSubTask() throws InterruptedException{
		initSubTask(50);
		while(sub_curr <= sub_task_size && !isCancelled()){ //Sub loop
			if(isPausing){
				try{ Thread.sleep(500); }catch(InterruptedException e){ break; }
				publish(new ProgressData(WorkerState.PAUSE, isBlinking));
				isBlinking ^= true;
				continue;
			}
			
			Thread.sleep(10); //dummy
			subProgress();
		}
	}
	
	public void initSubTask(int sub_task_size){
		sub_start_time = System.currentTimeMillis();
		sub_curr = 0;
		this.sub_task_size = sub_task_size;
		setSubProgress(0);
	}
	
	public void addSubTask(int sub_task_size){
		this.sub_task_size += sub_task_size;
	}
	
	public void subProgress(){
		publish(new ProgressData(WorkerState.SUB, 100 * sub_curr / sub_task_size));
		sub_curr++;
	}
	
	public long getSubStartTime(){
		return sub_start_time;
	}
	
	public int getSubTaskSize(){
		return sub_task_size;
	}
	
	public int getCurrentDoneSubTask(){
		return sub_curr;
	}
}
