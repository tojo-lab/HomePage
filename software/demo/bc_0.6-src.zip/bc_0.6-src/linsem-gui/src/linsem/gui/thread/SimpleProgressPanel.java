package linsem.gui.thread;

import java.awt.Component;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JToolBar;

public class SimpleProgressPanel extends JPanel implements JPanelWithProgressBars{

	protected JProgressBar bar;
	protected JLabel time_label;
	protected JButton pause_button;
	protected JButton cancel_button;
	protected static int cnt = 0;
	protected boolean isShowCount = true;
	
	/**
	 * Create the panel.
	 */
	public SimpleProgressPanel(String caption) {
		initPanel(caption);
	}

	public SimpleProgressPanel(String caption, boolean isShowCount){
		this.isShowCount = isShowCount;
		initPanel(caption);
	}
	
	public void initPanel(String caption){
		if(isShowCount){ caption = "[" + ++cnt + "] " + caption; }
		setName(caption);
		initTitleLabel(caption);
		initBar();
		initTimeLabel();
		initControlButtons();
		initLayout();		
	}
	
	public void initLayout(){
		setAlignmentX(Component.LEFT_ALIGNMENT);
		setAlignmentY(Component.TOP_ALIGNMENT);
		FlowLayout layout = (FlowLayout)getLayout();
		layout.setAlignment(FlowLayout.LEFT);
	}
		
	protected void initTitleLabel(String caption){
		JLabel label = new JLabel(caption);
		add(label);		
	}
	
	protected void initBar(){
		bar = new JProgressBar(0, 100); 
		bar.setIndeterminate(true);
		bar.setStringPainted(true);
		add(bar);		
	}
	
	protected void initTimeLabel(){
		time_label = new JLabel("--:--:--"); 
		add(time_label);
	}
	
	protected void initControlButtons(){
		pause_button  = new JButton("pause");
		cancel_button = new JButton("cancel");
		add(pause_button);
		add(cancel_button);		
	}

	@Override
	public JProgressBar getMianBar() {
		return bar;
	}

	@Override
	public JLabel getMainTimeLabel() {
		return time_label;
	}
	
	@Override
	public JProgressBar getSubBar() {
		return null;
	}

	@Override
	public JLabel getSubTimeLabel() {
		return null;
	}

}
