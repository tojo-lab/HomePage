package linsem.gui.thread;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;

public class TestFrame extends JFrame {

	protected JPanel contentPane;
	protected JPanel panel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TestFrame frame = new TestFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TestFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //TODO: This should be HIDE_ON_CLOSE
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		// ----------------------
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.NORTH);
		
		panel = new JPanel();
		scrollPane.setViewportView(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));		
		// -----------------------
		
		
		JPanel button_panel = new JPanel();
		contentPane.add(button_panel, BorderLayout.SOUTH);
		
		JButton btnAdd = new JButton("add");
		button_panel.add(btnAdd);
		btnAdd.addActionListener(new WorkerRunAction(panel, "single", null));
		
		JButton btnAdd2 = new JButton("add2");
		button_panel.add(btnAdd2);
		btnAdd2.addActionListener(new DoubleWorkerRunAction(panel, "double", null));
		
	}
	
}
