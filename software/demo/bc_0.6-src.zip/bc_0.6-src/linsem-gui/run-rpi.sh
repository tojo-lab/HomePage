﻿#!/bin/sh
java -cp .:./dist/linsem-gui.jar:./lib/ujmp-complete-0.2.5.jar:./lib/linsem.jar linsem.gui.rpi.RPiMain
