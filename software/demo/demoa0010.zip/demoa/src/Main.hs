module Main where
import DemoGuiMain
import Graphics.UI.FLTK.LowLevel.FLTKHS
import qualified Graphics.UI.FLTK.LowLevel.FL as FL
import Graphics.UI.FLTK.LowLevel.Fl_Types
import Graphics.UI.FLTK.LowLevel.Fl_Enumerations

import Debug.Trace
import Data.List
import Data.Char
import Models
import Display
import MinBis
import ActEpist
import MinAE
import DPLL 
import Semantics
import DEMO

main :: IO()
main = do
--  let 
--  showM (thinkN j (knowEx [j] (remind j drgA (Disj[q,Neg (Conj[p,r])]))p))
  window <- make_window
  _ <- showWidget window
  _ <- FL.run
  return ()
