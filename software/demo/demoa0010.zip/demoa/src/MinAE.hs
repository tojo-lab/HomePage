module MinAE
where 

import Data.List
import Models
import MinBis
import ActEpist

unfold :: PoACM State -> PoACM State
unfold (Pacm states pre post acc [])     = zero
unfold acm@(Pacm states pre post acc [p]) = acm
unfold (Pacm states pre post acc points) = 
  Pacm states' pre' post' acc' points'
  where 
  len = toInteger (length states)
  points' = [ p + len | p <- points ]
  states' = states ++ points' 
  pre'    = pre ++  [ (j+len,f) | (j,f) <- pre,  k <- points, j == k ]
  post'   = post ++ [ (ag,j+len,f) | (ag,j,f) <- post, k <- points, j == k ]
  acc'    = acc ++ [ (ag,i+len,j) | (ag,i,j) <- acc, k <- points, i == k ]

preds, sucs :: (Eq a, Ord a, Eq b, Ord b) => [(a,b,b)] -> b -> [(a,b)]
preds rel s = (sort.nub) [ (ag,s1) | (ag,s1,s2) <- rel, s == s2 ]
sucs  rel s = (sort.nub) [ (ag,s2) | (ag,s1,s2) <- rel, s == s1 ]

psPartition :: (Eq a, Ord a, Eq b, Eq c) => Model a b c -> [[a]]
psPartition (Mo states pre post rel) = 
  rel2part states (\ x y -> preds rel x == preds rel y 
                            && 
                            sucs rel x == sucs rel y)

{-
minPmod :: (Eq a, Ord a) => Pmod a (Form, Subst)  -> Pmod [a] (Form, Subst)
minPmod pm@(Pmod states pre rel pts) = 
  (Pmod states' pre' rel' pts') 
     where
     m         = Mo states pre rel
     partition = refine m (psPartition m)
     states'   = partition 
     f         = bl partition
     g         = \ xs -> canonF (Disj (map (table2fct (pretf pre)) xs))
     subg      = \ xs -> (canonF (Disj (map fst (map (table2fct (subtf pre)) xs))),canonF (Disj (map snd (map (table2fct (subtf pre)) xs))))
     rel'      = (nub.sort) (map (\ (x,y,z) -> (x, f y, f z)) rel)
     pre'      = zip states' ((map g states'), (map subg states'))
     pts'      = map (bl states') pts
-}
--aePmod ::  (Eq a, Ord a, Show a) => Pmod a Form -> Pmod State Form
--aePmod ::  PoAM -> PoAM
--aePmod ::  PoACM -> PoACM
--aePmod = (bisimPmod propEquiv) . minPmod . unfold . 
--                          (bisimPmod propEquiv) . gsmPoACM . convPmod

