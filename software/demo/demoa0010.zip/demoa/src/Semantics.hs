module Semantics where
import Debug.Trace
import Data.List
import Data.Char
import Models
import Display
import MinBis
import ActEpist
import MinAE
import DPLL 

type FACM state = [Agent] -> PoACM state

val :: EpistM -> State -> [Prop]
val m = table2fct (valuation m) 

{-newVal :: (Eq a, Ord a) => 
newVal ::  EpistM -> PoACM -> (State,State) -> [Prop]
newVal m am (w,s) = [ p | p <- allprops, subfct p ]
   where
   allprops = (sort.nub)
    ((val  m w) ++ (map (\ (x,_) -> x) (table2fct am s))) subfct p = isTrAt w m (sub am s p) == True -}

newAM :: State -> [Form] -> [([Form], Form)] -> [Form]
newAM sp [] [] = [] 
newAM sp bforms [] = []
newAM sp [] [([Top],pforms)] = expandFrm [pforms]
newAM sp bforms [([Top],pforms)] = expandFrm [pforms]
newAM sp bforms post = 
--     trace("\nnewAM 4th #####" ++ "bfrm:" ++ show(bforms) ++ "post:" ++ show(post))
     expandFrm [aform | (bform2,aform) <- post, null(bform2 \\  bforms)] 

conjCvt :: [Form] -> [Form]
conjCvt [] = []
conjCvt (Conj[a,b]:xs) = [a,b] ++ (conjCvt xs)
conjCvt (x:xs) = [x] ++ (conjCvt xs)

expandFrm :: [Form] -> [Form]
expandFrm [] = []
expandFrm ((Disj[Neg (Conj[cond1,cond2]),consq]):xs) = 
    [Disj[Neg (Conj[cond1,cond2]),consq], Disj[Neg (Conj[cond2,cond1]),consq]] 
    ++[Disj[consq, Neg (Conj[cond1,cond2])], Disj[consq, Neg (Conj[cond2,cond1]),consq]] 
    ++ [Disj[Neg cond1,Disj[Neg cond2,consq]], Disj[Neg cond1,Disj[consq, Neg cond2]]] 
    ++ [Disj[Disj[Neg cond2,consq], Neg cond1], Disj[Disj[consq, Neg cond2], Neg cond1]] 
    ++ [Disj[Neg cond2, Disj[Neg cond1,consq]], Disj[Neg cond2, Disj[consq, Neg cond1]]] 
    ++ [Disj[Disj[Neg cond1,consq], Neg cond2], Disj[Disj[consq, Neg cond1], Neg cond2]] 
    ++ (expandFrm xs) 
expandFrm ((Disj[Neg (Conj conds),consq]):xs) = 
    [Disj[Neg (Conj conds),consq], Disj[consq, Neg (Conj conds)]] 
    ++ [Disj[Neg cnd, Disj[Neg (Conj(conds \\ [cnd])), consq]] | cnd <- conds] 
    ++ [Disj[Neg cnd, Disj[consq, Neg (Conj(conds \\ [cnd]))]] | cnd <- conds] 
    ++ [Disj[Disj[Neg (Conj(conds \\ [cnd])), consq], Neg cnd] | cnd <- conds] 
    ++ [Disj[Disj[consq, Neg (Conj(conds \\ [cnd]))], Neg cnd] | cnd <- conds] 
    ++ (expandFrm xs) 
expandFrm ((Disj[Neg a , b]):xs) = [Disj[Neg  a, b]] ++ (expandFrm xs)
expandFrm (Disj[a,b]:xs) = [Disj[a,b], Disj[b,a]] ++ (expandFrm xs)
expandFrm (Conj[a,b]:xs) = [Conj[a,b], Conj[b,a]] ++ (expandFrm xs)
expandFrm (x:xs) = 
--     trace(show x)
                   [x] ++ (expandFrm xs)



apply :: Eq a => [(a,b)] -> a -> Maybe b
--apply [] _ = error "argument not in list"
apply [] _ = Nothing
apply ((x,z):xs) y | x == y    = Just z
                   | otherwise = apply xs y

upc :: EpistM -> PoACM State -> Pmod (State,State) [Prop] [Form]
upc m@(Pmod worlds val aw rel points) acm@(Pacm states pre post susp actuals) = 
--   trace("\n###upc :aw'" ++ show(aw')) 
   Pmod worlds' val' aw' rel' points'
   where 
    worlds' = [ (w,s) | w <- worlds, s <- states, 
                       formula <- maybe [] (\ x -> [x]) (apply pre s), 
                       isTrAt w m formula     ]
    val'   = [ ((w,s),props) | (w,props) <- val, 
                                s        <- states, 
                                elem (w,s) worlds'             ]
    aw'    = [ (ag1, (w1,s1), sort(nub((union bforms (newAM s1 bforms transfrml))))) | 
--    aw'    = [ (ag1, (w1,s1), nub((union bforms (newAM s1 bforms transfrml)))) | 
                                 (ag1, w1, bforms) <- aw, (w2,s1) <- worlds',(ag2,s2,transfrml) <- post,
                                 w1 == w2, s1 == s2, ag1 == ag2 ]
    rel'   =  [ (ag1,(w1,s1),(w2,s2)) | 
                 (ag1,w1,w2) <- rel, 
                 (ag2,s1,s2) <- susp, 
                  ag1 == ag2, 
                  elem (w1,s1) worlds', 
                  elem (w2,s2) worlds'   ]
    points' = [ (p,a) | p <- points, a <- actuals,
                       elem (p,a) worlds'    ]

sameVal :: [Prop] -> [Prop] -> [(Agent,[Form])] -> [(Agent,[Form])] -> Bool
sameVal ps qs aws bws = (((nub . sort) ps ==  (nub . sort) qs) && ((nub.sort) aws == (nub.sort) bws))

-- upd ::  (Eq state, Ord state) => 
upd ::  EpistM -> PoACM State -> EpistM
upd sm am = (bisimPmod (sameVal) . convPmod) (upc sm am)

upds  :: EpistM -> [PoACM State] -> EpistM
upds = foldl upd 

reachableAut :: SM -> NFA State -> State -> [State]
reachableAut model nfa@(NFA start moves final) w = 
  acc model nfa [(w,start)] []
  where 
    acc :: SM -> NFA State -> [(State,State)] -> [(State,State)] -> [State]
    acc model (NFA start moves final) [] marked =  
       (sort.nub) (map fst (filter (\ x -> snd x == final) marked))
    acc m@(Mo states _ _ rel) nfa@(NFA start moves final) 
          ((w,s):pairs) marked = 
      acc m nfa (pairs ++ (cs \\ pairs)) (marked ++ cs)
      where 
        cs = nub ([ (w, s') | Move t (Tst f) s' <- moves, 
                              t == s, notElem (w,s') marked, 
                              isTrueAt w m f ]
                  ++
                 [ (w',s') | Move t (Acc ag) s' <- moves, t == s, 
                             w' <- states, 
                             notElem (w',s') marked, 
                             elem (ag,w,w') rel ])

isTrueAt :: State -> SM -> Form -> Bool
isTrueAt w m Top = True 
isTrueAt w m@(Mo worlds val aw acc) (Prop p) = 
  elem p (concat [ props | (w',props) <- val, w'==w ])
isTrueAt w m (Neg f)   = not (isTrueAt w m f) 
isTrueAt w m (Conj fs) = and (map (isTrueAt w m) fs)
isTrueAt w m (Disj fs) = or  (map (isTrueAt w m) fs)

isTrueAt w m@(Mo worlds val aw acc) (K ag f) = 
  and (map (flip ((flip isTrueAt) m) f) (alternatives acc ag w))
isTrueAt w m@(Mo worlds val aw acc) (EK agents f) = 
  and (map (flip ((flip isTrueAt) m) f) (groupAlts acc agents w))
isTrueAt w m@(Mo worlds val aw acc) (CK agents f) = 
  and (map (flip ((flip isTrueAt) m) f) (commonAlts acc agents w))

isTrueAt w m (Up am f) = 
  and [ isTrueAt w' m' f | 
         (m',w') <- decomposeE (upd (mod2epi m [w]) am) ]
isTrueAt w m (Aut nfa f) = 
  and [ isTrueAt w' m f | w' <- reachableAut m nfa w ]

isTrAt :: State -> EpistM -> Form -> Bool
isTrAt w (Pmod worlds val aw rel pts) = isTrueAt w (Mo worlds val aw rel)

isTrue :: EpistM -> Form -> Bool
isTrue (Pmod worlds val aw rel pts) form = 
   and [ isTrueAt w (Mo worlds val aw rel) form | w <- pts ]

groupAlts :: [(Agent,State,State)] -> [Agent] -> State -> [State]
groupAlts rel agents current = 
  (nub . sort . concat) [ alternatives rel a current | a <- agents ]

commonAlts :: [(Agent,State,State)] -> [Agent] -> State -> [State]
commonAlts rel agents current = 
  closure rel agents (groupAlts rel agents current) 

sortL :: Ord a => [[a]] -> [[a]]
sortL  = sortBy (\ xs ys -> if length xs < length ys then LT
                               else if length xs > length ys then GT
                               else compare xs ys) 

initE :: [Prop] -> EpistM
initE allProps = (Pmod worlds val aw accs points)
  where 
    worlds = [0..(2^k - 1)]
    k      = length allProps
    val    = zip worlds (sortL (powerList allProps))
    aw     = [ (ag, st, []) | ag <- all_agents, st <- worlds ] 
    accs   = [ (ag,st1,st2) | ag <- all_agents, 
                              st1 <- worlds, 
                              st2 <- worlds      ]
    points = worlds

powerList  :: [a] -> [[a]]
powerList  [] = [[]]
powerList  (x:xs) = (powerList xs) ++ (map (x:) (powerList xs))

--e00 :: EpistM
--e00 = initE [P 0]

--e0 :: EpistM
--e0 = initE [P 0,Q 0] 

public :: Form -> PoACM State
public form = 
   (Pacm [0] [(0,form)] [(a,0,[])| a <- all_agents] [ (a,0,0) | a <- all_agents] [0])

--explicitly knows
publicEx :: Form -> PoACM State
publicEx form = 
   (Pacm [0] [(0,form)] [(a,0,[([Top],form)]) | a <- all_agents] [ (a,0,0) | a <- all_agents] [0])

--not known knows
publicVa :: Form -> PoACM State
publicVa form = 
   (Pacm [0,1] [(0,form),(1,form)] ([(a,0,[([Top],form)]) | a <- all_agents ] ++ [(a,1,[])| a <- all_agents])
     ([ (a,0,0) | a <- all_agents] 
        ++ [ (a,0,1) | a <- all_agents] 
        ++ [ (a,1,0) | a <- all_agents] 
        ++ [ (a,1,1) | a <- all_agents])
     [0,1])

--not known
groupVa :: [Agent] -> Form -> PoACM State
groupVa agents form = 
  if (sort agents) == all_agents 
    then publicVa form 
    else 
      (Pacm
         [0,1,2] 
         [(0,form),(1,form),(2,Top)] 
         ([(a,0,[([Top],form)]) | a <- agents ] 
           ++ [(a,0,[]) | a <- all_agents \\ agents ] 
           ++ [(a,1,[]) | a <- agents ] ++ [(a,1,[]) | a <- all_agents \\ agents ]
           ++ [(a,2,[]) | a <- all_agents ]) 
         ([ (a,0,0) | a <- all_agents ] 
           ++ [ (a,0,1) | a <- all_agents ] 
           ++ [ (a,0,2) | a <- all_agents \\ agents ] 
           ++ [ (a,1,0) | a <- all_agents ] 
           ++ [ (a,1,1) | a <- all_agents ] 
           ++ [ (a,1,2) | a <- all_agents \\ agents ] 
           ++ [ (a,2,0) | a <- all_agents \\ agents ] 
           ++ [ (a,2,1) | a <- all_agents \\ agents ] 
           ++ [ (a,2,2) | a <- all_agents           ])
         [0,1])

secret :: [Agent] -> Form -> PoACM State
secret agents form = 
  if (sort agents) == all_agents 
    then public form 
    else 
      (Pacm 
         [0,1] 
         [(0,form),(1,Top)] 
         ([ (a,0,[([Top],form)])| a <- agents ]
           ++ [ (a,0,[])| a <- all_agents \\ agents ]
           ++ [ (a,1,[([Top],Top)]) | a <- all_agents]) 
         ([ (a,0,0) | a <- agents ] 
           ++ [ (a,0,1) | a <- all_agents \\ agents ] 
           ++ [ (a,1,1) | a <- all_agents           ])
         [0])

--test :: Form -> PoAM
test :: Form -> PoACM State
test = secret [] 

reveal :: [Agent] -> [Form] -> PoACM State
reveal ags forms = 
  (Pacm 
     states
     (zip states forms)
     ([(ag, s, [([Top], form)]) | s <- states,  form <- forms, ag <- ags ]
       ++ [(ag, s, []) | s <- states, ag <-  others ])
     ([ (ag,s,s) | s <- states, ag <- ags ]
       ++
      [ (ag,s,s') | s <- states, s' <- states, ag <- others ])
     states)
    where states = map fst (zip [0..] forms)
          others = all_agents \\ ags

info :: [Agent] -> Form -> PoACM State
info agents form = reveal agents [form, negation form]

--one :: PoAM
one :: PoACM State
one = public Top

{-
cmpP :: PoAM -> PoAM ->
                 Pmod (State,State) Form
cmpP m@(Pmod states pre susp ss) (Pmod states' pre' susp' ss') = 
  (Pmod nstates npre nsusp npoints)
       where  
         npoints = [ (s,s') | s <- ss, s' <- ss' ]
         nstates = [ (s,s') | s <- states, s' <- states' ] 
         npre    = [ ((s,s'), g) | (s,f)     <- pre, 
                                   (s',f')   <- pre', 
                                    g        <- [computePre m f f']      ]
         nsusp   = [ (ag,(s1,s1'),(s2,s2')) | (ag,s1,s2)    <- susp, 
                                              (ag',s1',s2') <- susp', 
                                               ag == ag'                 ] 
cmpA :: PoACM -> PoACM ->
                 Pmod (State,State) (Form, Subst)
cmpA m@(Pmod states pre susp ss) (Pmod states' pre' susp' ss') = 
  (Pmod nstates npre nsusp npoints)
       where  
         npoints = [ (s,s') | s <- ss, s' <- ss' ]
         nstates = [ (s,s') | s <- states, s' <- states' ] 
         npre    = [ ((s,s'), (g, gsubst)) | (s,(f,subst))     <- pre, 
                                   (s',(f',subst'))   <- pre', 
                                    g        <- [computePreC m f f'],
                                    gsubst   <- [computePreC m subst subst']      ]
         nsusp   = [ (ag,(s1,s1'),(s2,s2')) | (ag,s1,s2)    <- susp, 
                                              (ag',s1',s2') <- susp', 
                                               ag == ag'                 ] 

computePre  :: PoAM -> Form -> Form -> Form
computePre m g g'  | pureProp conj = conj 
                   | otherwise     = Conj [ g, Neg (Up m (Neg g')) ] 
  where conj    = canonF (Conj [g,g'])
computePreC  :: PoACM -> Form -> Form -> Form
computePreC m g g' | pureProp conj = conj 
                   | otherwise     = Conj [ g, Neg (Up m (Neg g')) ] 
  where conj    = canonF (Conj [g,g'])

computeSub  :: PoACM -> Form -> Form -> Form
computeSub m g g' | pureProp disj = disj 
                  | otherwise     = Disj [ g, (Up m  g')] 
  where disj    = canonF (Disj [g,g'])
-}

{-
cmpPoAM :: PoAM -> PoAM -> PoAM
cmpPoAM pm pm' = aePmod (cmpP pm pm')
cmpACM :: PoACM -> PoACM -> PoACM
cmpACM am am' = aePmod (cmpA am am')
-}

--cmp :: [PoACM] -> PoACM
--cmp = foldl cmpACM one

m2  = initE [P 0,Q 0]
psi = Disj[Neg(K b p),q]


--pow :: Int -> PoAM -> PoAM
--pow :: Int -> PoACM -> PoACM
--pow n am = cmp (take n (repeat am)) 

-- vBtest :: EpistM -> PoACM -> [EpistM ]
-- vBtest m a = map (upd m) (star one cmpACM a)

star :: a -> (a -> a -> a) -> a -> [a]
star z f a = z : star (f z a) f a

-- vBfix :: EpistM -> PoACM -> [EpistM ]
-- vBfix m a = fix (vBtest m a)

fix :: Eq a => [a] -> [a]
fix (x:y:zs) = if x == y then [x]
                         else x: fix (y:zs) 

m1  = initE [P 1,P 2,P 3] 
phi = Conj[p1,Neg (Conj[K a p1,Neg p2]), 
              Neg (Conj[K a p2,Neg p3])]
--a1  = know_uncons a phi

{-
ndSum' :: PoAM -> PoAM -> PoAM
ndSum' m1 m2 = (Pmod states val acc ss)
  where 
       (Pmod states1 val1 acc1 ss1) = convPmod m1
       (Pmod states2 val2 acc2 ss2) = convPmod m2
       f   = \ x -> toInteger (length states1) + x 
       states2' = map f states2
       val2'    = map (\ (x,y)   -> (f x, y)) val2
       acc2'    = map (\ (x,y,z) -> (x, f y, f z)) acc2
       ss       = ss1 ++ map f ss2
       states   = states1 ++ states2'
       val      = val1 ++ val2' 
       acc      = acc1 ++ acc2' 

am0 = ndSum' (test p) (test (Neg p))

am1 = ndSum' (test p) (ndSum' (test q) (test r))

ndSum :: PoAM -> PoAM -> PoAM
ndSum m1 m2 = aePmod (ndSum' m1 m2)

ndS :: [PoAM] -> PoAM
ndS = foldl ndSum zero

testAnnounce :: Form -> PoAM
testAnnounce form = ndS [ cmp [ test form, public form ], 
                          cmp [ test (negation form), 
                                public (negation form)] ]
-}
