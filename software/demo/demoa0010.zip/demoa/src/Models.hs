module Models where 

import Data.List 

data Agent = A | B | C | D | E | J deriving (Eq,Ord,Enum) 

a, alice, b, bob, c, carol, d, dave, e, ernie, j, judge :: Agent 
a = A; alice = A
b = B; bob   = B
c = C; carol = C
d = D; dave  = D
e = E; ernie = E
j = J; judge = J

instance Show Agent where 
  show A = "a"; show B = "b"; show C = "c"; show D = "d" ; show E = "e"; show J = "j"

all_agents :: [Agent]
--all_agents = [a .. last_agent]
all_agents = [a,j]

--last_agent :: Agent 
--last_agent = a
--last_agent = b
--last_agent = c
--last_agent = d
--last_agent = e

data Model state formula awfrm = Mo
                           [state]
                           [(state,formula)]
                           [(Agent,state,awfrm)]
                           [(Agent,state,state)]
                           deriving (Eq,Ord,Show)

data Pmod state formula awfrm = Pmod
                           [state]
                           [(state,formula)]
                           [(Agent,state,awfrm)]
                           [(Agent,state,state)]
                           [state]
                           deriving (Eq,Ord,Show)

mod2pmod :: Model state formula awfrm -> [state] -> Pmod state formula awfrm
mod2pmod (Mo states prec aw accs) points = Pmod states prec aw accs points 

pmod2mp :: Pmod state formula awfrm -> (Model state formula awfrm, [state]) 
pmod2mp (Pmod states prec aw accs points)  = (Mo states prec aw accs, points)

decompose ::  Pmod state formula awfrm -> [(Model state formula awfrm, state)]
decompose (Pmod states prec aw accs points) = 
   [(Mo states prec aw accs, point) | point <- points ]

table2fct :: Eq a => [(a,b)] -> a -> b
table2fct t = \ x -> maybe undefined id (lookup x t)

rel2part :: (Eq a) => [a] -> (a -> a -> Bool) -> [[a]]
rel2part [] r = []
rel2part (x:xs) r = xblock : rel2part rest r
  where 
  (xblock,rest) = partition (\ y -> r x y) (x:xs)

domain :: Model state formula  awfrm -> [state]
domain (Mo states _ _ _) = states

eval :: Model state formula awfrm -> [(state,formula)]
eval (Mo _ pre _ _) = pre

awareness :: Model state formula awfrm -> [(Agent,state,awfrm)]
awareness (Mo _ _ aw _) = aw

access :: Model state formula awfrm -> [(Agent,state,state)]
access (Mo _ _ _ rel) = rel

points :: Pmod state formula awfrm -> [state]
points (Pmod _ _ _ _ pnts) = pnts

{-gsm :: Ord state => Pmod state formula ->  Pmod state formula
gsm (Pmod states pre aw rel points) = (Pmod states' pre' aw' rel' points)
   where 
   states' = closure rel all_agents points
   pre'    = [(s,f)     | (s,f)     <- pre, 
                           elem s states'                   ]
   aw'    = [(ag,s,f) | (ag,s,f) <- aw, 
                           elem s states'                   ]
   rel'    = [(ag,s,s') | (ag,s,s') <- rel, 
                           elem s states', 
                           elem s' states'                  ]
-}

{-
gsm :: Ord state => Pmod state formula ->  Pmod state formula
gsm (Pmod states pre aw rel points) = (Pmod states' pre' aw' rel' points)
   where 
   states' = closure rel all_agents points
   pre'    = [(s,f)     | (s,f)     <- pre, 
                           elem s states'                   ]
   aw'    = [(ag,s,f) | (ag,s,f) <- aw, 
                           elem s states'                   ]
   rel'    = [(ag,s,s') | (ag,s,s') <- rel, 
                           elem s states', 
                           elem s' states'                  ]
-}

closure ::  Ord state => 
             [(Agent,state,state)] -> [Agent] -> [state] -> [state]
closure rel agents xs 
  | xs' == xs = xs
  | otherwise = closure rel agents xs'
     where 
     xs' = (nub . sort) (xs ++ (expand rel agents xs))

expand :: Ord state => 
           [(Agent,state,state)] -> [Agent] -> [state] -> [state]
expand rel agnts ys = 
      (nub . sort . concat) 
         [ alternatives rel ag state | ag    <- agnts, 
                                       state <- ys       ]

alternatives :: Eq state => 
                [(Agent,state,state)] -> Agent -> state -> [state]
alternatives rel ag current = 
  [ s' | (a,s,s') <- rel, a == ag, s == current ] 

