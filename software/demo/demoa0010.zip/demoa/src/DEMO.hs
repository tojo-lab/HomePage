module DEMO
    (
     module Data.List,
     module Data.Char, 
     module Models,
     module Display,
     module MinBis,
     module ActEpist,
     module MinAE,
     module DPLL,
     module Semantics,
     module DEMO
    )
    where

import Debug.Trace
import Data.List
import Data.Char
import Models
import Display
import MinBis
import ActEpist
import MinAE
import DPLL 
import Semantics

version :: String
version = "DEMO 1.03, Summer 2005"

measure :: (Eq a,Ord a) => (Model a b c,a) -> Maybe [Int]
measure (m,w) = 
  let 
    f           = filter (\ (us,vs) -> elem w us || elem w vs) 
    g [(xs,ys)] = length ys - 1
  in 
    case kd45 (domain m) (access m) of 
      Just a_balloons -> Just 
         ( [ g (f balloons) | (a,balloons) <- a_balloons  ])
      Nothing         -> Nothing 

initEx :: EpistM
initEx = initE [P 0,P 1,Q 0]
--initEx = initE [P 0,Q 0,R 0]

bthink :: PoACM State
bthink = (Pacm [0,1] pre post acc [1])
    where
    pre = [(0,Top),(1,Conj[p,q])]
    post = [(a,0,[]),(a,1,[]),(b,0,[]),(b,1,[([q],p)])]
    acc = [(b,0,0),(b,1,1),(a,0,0),(a,0,1),(a,1,0),(a,1,1)]

--introsepct
introspect :: Agent -> Form -> PoACM State
introspect agent form =  
      (Pacm
         [0,1] 
         [(0,form),(1,Top)] 
         ([(agent,0,[([Top],form)])] 
           ++ [(a,0,[]) | a <- all_agents \\ [agent]]
           ++ [(a,1,[]) | a <- all_agents ])
         ([ (a,0,0) | a <- all_agents ] 
           ++ [ (a,0,1) | a <- all_agents \\ [agent] ] 
           ++ [ (a,1,0) | a <- all_agents \\ [agent] ] 
           ++ [ (a,1,1) | a <- all_agents ])
         [0])

predict :: Agent -> PoACM State
predict agent = (Pacm [0,1] pre post acc [0])
    where
    pre = [(0,Conj[Disj[p, p1],Disj[p,q]]),(1,Top)]
    post = [(agent,0,[([Disj[Neg p,q],p],q),([Disj[Neg p1,p],p1],p)])] ++ [ (a,0,[]) | a <- all_agents \\ [agent]]
           ++ [ (a,1,[]) | a <- all_agents]
    acc = [(a,0,0) | a <- all_agents] ++ [(a,0,1) | a <- all_agents \\ [agent]] 
           ++ [(a,1,1) | a <- all_agents] ++ [(a,1,0) | a <- all_agents \\ [agent]]
           
inference :: Agent -> Form -> Form -> PoACM State
inference agent frm consq = (Pacm [0,1] pre post acc [0])
    where
--     pre = [(0,Conj[frm, consq]),(1,Top)]
     pre = [(0,Conj[frm, consq]),(1,Top)]
     post = [(agent,0,[([(Disj[Neg frm, consq]),frm], consq)])] ++ [ (a,0,[]) | a <- all_agents \\ [agent]]
           ++ [ (a,1,[]) | a <- all_agents]
     acc = [(a,0,0) | a <- all_agents] ++ [(a,0,1) | a <- all_agents \\ [agent]] 
           ++ [(a,1,1) | a <- all_agents] ++ [(a,1,0) | a <- all_agents \\ [agent]]
           

think1 :: Agent -> EpistM -> EpistM
think1 agent m@(Pmod worlds val aw rel points)
    | isIntmed awofsts' m = 
--       trace("\n!!think1 doinfer!!!\n") 
    doInfer agent m awofsts'
    | otherwise = 
--       trace("\n!!think1 otherwise\n") 
    m
    where 
        awofsts' = totalfrm agent m

thinkN :: Agent -> EpistM -> EpistM
thinkN agent m
    | isIntmed (totalfrm agent m) m && not(null((totalfrm agent (think1 agent m)) \\ (totalfrm agent m))) = 
--       trace("\n!!thinkN doinfer!!!\n")
    thinkN agent (think1 agent m)
    | otherwise = 
--    trace("\n!!thinkN infer!!!\n") 
    m

isIntmed :: [(State,[Form])] -> EpistM -> Bool
isIntmed [] m = False
isIntmed (x:xs) m 
    | (isInfer  x  x m /= (Top, Top)) = 
--    trace("IntMed<<<<<<<< infer" ++ show(isInfer x x m) ++ "x*******:" ++ show(x) ++ "xs:::::" ++ show(xs) ++ "\n") 
    True
    | otherwise = 
--    trace("IntMed<<<<<<<< otherwise\n" ++ "x*******:" ++ show(x) ++ "xs:::::" ++ show(xs) ++ "\n") 
    isIntmed xs m

extract :: [Form] -> [Form] -> [Form]
extract [] ps = []
extract (x:xs) ps = filter (== x) ps ++ extract xs ps


isInfer :: (State,[Form]) -> (State,[Form]) -> EpistM -> (Form, Form)
isInfer (a,[]) awfrms m = (Top, Top)
isInfer (a,(Disj[Neg conds, consq]:suf)) awfrms m
    | elem conds (snd(awfrms)) && notElem consq (snd(awfrms)) && (isTrueAt a (fst(pmod2mp(m))) consq) = 
--    trace("Implication!!!" ++ show(awfrms) ++ ":conds==" ++ show(conds) ++ " consq==" ++ show(consq)++ "\n") 
    (conds, consq)
    | otherwise  = isInfer (a,suf) awfrms m
isInfer (a,(Disj[consq, Neg conds]:suf)) awfrms m
    | elem conds (snd(awfrms)) && notElem consq (snd(awfrms)) && (isTrueAt a (fst(pmod2mp(m))) consq) = 
--    trace("Implication!!!" ++ show(awfrms) ++ ":conds==" ++ show(conds) ++ " consq==" ++ show(consq)++ "\n") 
    (conds, consq)
    | otherwise  = isInfer (a,suf) awfrms m
isInfer (a,(pref:suf)) awfrms m = isInfer (a,suf) awfrms m

doInfer :: Agent -> EpistM -> [(State,[Form])] -> EpistM
doInfer agent m [] = m
doInfer agent m (x:xs)
    | isInfer x x  m /= (Top, Top) = 
--    (trace("doInfer Impl:" ++ show(inference agent conds consq))) 
    upd m (inference agent conds consq)
    | otherwise = 
--    trace("doInfer Otherwise") 
    doInfer agent m xs
    where 
        conds = fst(isInfer x x m)
        consq = snd(isInfer x x m)

totalfrm :: Agent -> EpistM -> [(State,[Form])]
totalfrm agent m@(Pmod worlds val aw rel points) = 
--    trace("\n###########points: " ++ show(points))
    sort([(stts,awofsts) | (agt, stts, awofsts) <- aw, agt == agent, elem stts points])

--implicit
knowIm :: [Agent] -> EpistM -> Form -> EpistM
knowIm agents m form = upd m (actKnowIm agents form)

actKnowIm :: [Agent] -> Form -> PoACM State
actKnowIm agents frm = 
   Pacm [0,1,2] [(0,frm),(1,Neg frm),(2,Top)]
    ([(a, 0, [])|a <- all_agents ] ++ 
     [(a, 1, [])|a <- all_agents] ++ [(a, 2, [])|a <- all_agents]) 
    ([(a, 0, 0) | a <- all_agents] ++ [(a, 0,1) | a <- all_agents \\ agents] ++ 
     [(a, 0,2) | a <- all_agents \\ agents] ++ [(a,1,0) | a <- all_agents \\ agents] ++ 
     [(a,1,2)| a <- all_agents \\ agents] ++ [(a,1,1) | a <- all_agents] ++ 
     [(a, 2,0) | a <- all_agents \\ agents] ++ [(a,2,1)| a <- all_agents \\ agents] ++ [(a,2,2)|a<-all_agents])
    [0]
--explicit
knowEx :: [Agent] -> EpistM -> Form -> EpistM
knowEx agents m form = upd m (actKnowEx agents form)

actKnowEx :: [Agent] -> Form -> PoACM State
actKnowEx agents frm = 
   Pacm [0,1,2] [(0,frm),(1,Neg frm),(2,Top)]
    ([(a, 0, [([Top], frm)])| a <- agents] ++ [(a, 0, [])|a <- all_agents \\ agents] ++ 
     [(a, 1, [([Top], Neg frm)])| a <- agents] ++ [(a, 1, [])|a <- all_agents \\ agents] ++ 
     [(a, 2, [])|a <- all_agents]) 
    ([(a, 0, 0) | a <- all_agents] ++ [(a, 0,1) | a <- all_agents \\ agents] ++ 
     [(a, 0,2) | a <- all_agents \\ agents] ++ [(a,1,0) | a <- all_agents \\ agents] ++ 
     [(a,1,2)| a <- all_agents \\ agents] ++ [(a,1,1) | a <- all_agents] ++ 
     [(a, 2,0) | a <- all_agents \\ agents] ++ [(a,2,1)| a <- all_agents \\ agents] ++ [(a,2,2)|a<-all_agents])
    [0]

remind :: Agent -> EpistM -> Form -> EpistM
--remind agent m frm = doRemind agent medModel frm
--    where medModel = upd m (conscious agent frm)
remind agent m frm = upd m (actRemind agent frm)

actRemind :: Agent -> Form -> PoACM State
actRemind agent frm = 
   Pacm [0,1,2] [(0,(K agent frm)),(1,(Neg (K agent frm))),(2,Top)]
    ([(agent, 0, [([Top], frm)])] ++ [(a, 0, [])|a <- all_agents \\ [agent]] ++ 
     [(a, 1, [])|a <- all_agents] ++ [(a, 2, [])|a <- all_agents]) 
    ([(a,0,0)| a <- all_agents] ++ [(a, 0,1) | a <- all_agents \\ [agent]] ++ 
     [(a,0,2)| a <- all_agents \\ [agent]] ++ [(a,1,2) | a <- all_agents] ++ 
     [(a,1,0)| a <- all_agents \\ [agent]] ++ [(a,1,1) | a <- all_agents] ++ 
     [(a,2,0)| a <- all_agents \\ [agent]] ++ [(a,2,1) | a <- all_agents] ++
     [(a,2,2)| a <- all_agents])
    [0]

{--
doRemind :: Agent -> EpistM -> Form -> EpistM
doRemind agent m@(Pmod worlds val awfrms rel points) frm = Pmod worlds val [(agt, stts, (addForm awfrm frm))|(agt, stts, awfrm) <- awfrms] rel points

addForm :: [Form] -> Form -> [Form]
addForm awfrms frm
    | elem frm awfrms = [conjxy a frm | a <- awfrms, frm /= a] ++ awfrms
    | otherwise = awfrms
--}


epistZero :: Pmod State [Prop] [Form]
epistZero =  Pmod [] [] [] [] []
-- exknow r and imknow p and r implies q
{-initDrg :: Pmod State [Prop] [Form]
initDrg =  Pmod [0,1,2]
    [(0,[Ca 0]),(1,[Cs 0,Ca 0]),(2,[St 0,Cs 0,Ca 0])] 
    [(a,0,[ca]),(a,1,[ca]),(a,2,[ca]),(j,0,[ca]),(j,1,[ca]),(j,2,[ca])]
    [(a,0,0),(a,0,1),(a,0,2),(a,1,0),(a,1,1),(a,1,2),(a,2,0),(a,2,1),(a,2,2),
     (j,0,0),(j,0,1),(j,0,2),(j,1,0),(j,1,1),(j,1,2),
     (j,2,0),(j,2,1),(j,2,2)]
    [0,1,2]
-}
initDrg :: Pmod State [Prop] [Form]
initDrg =  Pmod [0,1,2]
    [(0,[R 0]),(1,[Q 0,R 0]),(2,[P 0,Q 0,R 0])] 
    [(a,0,[r]),(a,1,[r]),(a,2,[r]),(j,0,[r]),(j,1,[r]),(j,2,[r])]
    [(a,0,0),(a,0,1),(a,0,2),(a,1,0),(a,1,1),(a,1,2),(a,2,0),(a,2,1),(a,2,2),
     (j,0,0),(j,0,1),(j,0,2),(j,1,0),(j,1,1),(j,1,2),
     (j,2,0),(j,2,1),(j,2,2)]
    [0,1,2]

conjxy :: Form -> Form -> Form
conjxy a b 
    |a <= b = Conj[a, b]
    |otherwise = Conj[b,a]

{-
drgA :: EpistM
drgA = think1 a (remind a initDrg (Disj[q,Neg (Conj[p,r])])) 

drgJ :: EpistM
drgJ = thinkN j (knowEx [j] (remind j drgA (Disj[Neg (Conj[st,ca]),cs]))st)
-}
-- p, p2 -> q and Imknow p -> p1
initRun :: Pmod State [Prop] [Form]
initRun =  Pmod [0,1,2]
    [(0,[P 0,R 0]),(1,[P 0,Q 0,R 0]),(2,[P 0,Q 0,R 0,O 0])] 
    [(a,0,[p,Disj[Neg o,q]]),(a,1,[p,Disj[Neg o,q]]),(a,2,[p,Disj[Neg o,q]]),
     (j,0,[p,Disj[Neg o,q]]),(j,1,[p,Disj[Neg o,q]]),(j,2,[p,Disj[Neg o,q]])]
    [(a,0,0),(a,0,1),(a,0,2),
     (a,1,0),(a,1,1),(a,1,2),
     (a,2,0),(a,2,1),(a,2,2),
     (j,0,0),(j,0,1),(j,0,2),
     (j,1,0),(j,1,1),(j,1,2),
     (j,2,0),(j,2,1),(j,2,2)]
    [0,1,2]

runA :: EpistM
runA = thinkN a (remind a initRun (Disj[Neg p,r]))
--runA = think1 a (remind a initRun (Disj[Neg p0,p1]))

runJ :: EpistM
runJ = thinkN j (remind j (knowIm [j] (remind j runA (Disj[Neg p,r]))(Disj[Neg r,o])) (Disj[Neg r,o]))
    --
-- Exknow s -> q impKnow p -s
initOpe :: Pmod State [Prop] [Form]
initOpe =  Pmod [0,1,2,3]
    [(0,[]),(1,[Ij 0]),(2,[Dg 0,Ij 0]),(3,[Ms 0,Dg 0,Ij 0])] 
    [(a,0,[Disj[Neg dg,ij]]),(a,1,[Disj[Neg dg,ij]]),(a,2,[Disj[Neg dg,ij]]),(a,3,[Disj[Neg dg,ij]]),
     (j,0,[Disj[Neg dg,ij]]),(j,1,[Disj[Neg dg,ij]]),(j,2,[Disj[Neg dg,ij]]),(j,3,[Disj[Neg dg,ij]])]
    [(a,0,0),(a,0,1),(a,0,2),(a,0,3),
     (a,1,0),(a,1,1),(a,1,2),(a,1,3),
     (a,2,0),(a,2,1),(a,2,2),(a,2,3),
     (a,3,0),(a,3,1),(a,3,2),(a,3,3),
     (j,0,0),(j,0,1),(j,0,2),(j,0,3),
     (j,1,0),(j,1,1),(j,1,2),(j,1,3),
     (j,2,0),(j,2,1),(j,2,2),(j,2,3),
     (j,3,0),(j,3,1),(j,3,2),(j,3,3)]
    [0,1,2,3]

opeA :: EpistM
opeA = thinkN a initOpe

opeJ :: EpistM
--opeJ = thinkN b (upd (upd (upd opeA  (knowEx [b] p)) (knowEx [b] (Disj[Neg p, p1]))) (knowEx [b] (Disj[Neg p1, p2])))
opeJ = thinkN j (remind j (knowEx [j] opeA ms) (Disj[Neg ms,dg]))

--knowEX r, p and r -> s
initUhp :: Pmod State [Prop] [Form]
initUhp =  Pmod [0,1,2,3,4,5]
    [(0,[R 0]),(1,[Q 0,R 0]),(2,[R 0,O 0]),(3,[P 0,R 0,O 0]),(4,[Q 0,R 0,O 0]),(5,[P 0,Q 0,R 0,O 0])]
    [(a,0,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),(a,1,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),(a,2,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),
     (a,3,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),(a,4,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),(a,5,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),
     (j,0,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),(j,1,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),(j,2,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),
     (j,3,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),(j,4,expandFrm[r,Disj[Neg (Conj[p,r]),o]]),(j,5,expandFrm[r,Disj[Neg (Conj[p,r]),o]])]
    [(a,0,0),(a,0,1),(a,0,2),(a,0,3),(a,0,4),(a,0,5),
     (a,1,0),(a,1,1),(a,1,2),(a,1,3),(a,1,4),(a,1,5),
     (a,2,0),(a,2,1),(a,2,2),(a,2,3),(a,2,4),(a,2,5),
     (a,3,0),(a,3,1),(a,3,2),(a,3,3),(a,3,4),(a,3,5),
     (a,4,0),(a,4,1),(a,4,2),(a,4,3),(a,4,4),(a,4,5),
     (a,5,0),(a,5,1),(a,5,2),(a,5,3),(a,5,4),(a,5,5),
     (j,0,0),(j,0,1),(j,0,2),(j,0,3),(j,0,4),(j,0,5),
     (j,1,0),(j,1,1),(j,1,2),(j,1,3),(j,1,4),(j,1,5),
     (j,2,0),(j,2,1),(j,2,2),(j,2,3),(j,2,4),(j,2,5),
     (j,3,0),(j,3,1),(j,3,2),(j,3,3),(j,3,4),(j,3,5),
     (j,4,0),(j,4,1),(j,4,2),(j,4,3),(j,4,4),(j,4,5),
     (j,5,0),(j,5,1),(j,5,2),(j,5,3),(j,5,4),(j,5,5)]
    [0,1,2,3,4,5]

uhpA :: EpistM
uhpA = think1 a initUhp
--uhpA = think1 a (knowEx [a] initUhp (Conj[o, Neg q]))

uhpJ :: EpistM
uhpJ = thinkN j (knowIm [j] (knowEx [j] uhpA p) (Disj[Neg o, q]))
--uhpJ = thinkN j (knowEx [j] (knowEx [j] uhpA p) (Disj[Neg o, q]))


initTest :: Pmod State [Prop] [Form]
initTest =  Pmod [0,1]
    [(0,[P 0,Q 0,R 0]),(1,[P 0,Q 0,R 0])] 
    [(a,0,expandFrm [p,q,Disj[Neg(Conj[p,q]),r]]),(a,1,expandFrm [p,Disj[Neg p,q]]),
     (j,0,[p,Disj[Neg p,q]]),(j,1,[p,Disj[Neg p,q]])]
    [(a,0,0),(a,0,1),
     (a,1,0),(a,1,1),
     (j,0,0),(j,0,1),
     (j,1,0),(j,1,1)]
    [0,1]


initPub :: [(Int, Form)] -> EpistM -> EpistM
initPub  [] model = model
initPub  (x:xs) model
    | fst x == 1 = initPub xs (upd model (public (snd x)))
    | fst x == 2 = initPub xs (upd model (publicEx (snd x)))

initSet :: [(Int, Form)] -> Int -> EpistM
initSet [] _ = epistZero
initSet  a 1 = initPub a (initE[P 0])
initSet  a 2 = initPub a (initE[P 0, Q 0])
initSet  a 3 = initPub a (initE[P 0, Q 0, R 0])
initSet  a 4 = initPub a (initE[P 0, Q 0, R 0, S 0])
initSet  a 5 = initPub a (initE[P 0, Q 0, R 0, S 0, O 0])

--chkAwqSts :: Form -> EpistM -> Bool
chkAwFrmJA ::  Form -> EpistM -> Bool
chkAwFrmJA frm (Pmod sts pre aw acc pnts) = elem frm (nub (concat [frms | (ag,st,frms) <-aw, ag==a,elem st awst]))
    where 
    awst = nub [ast | (aag, pnt, ast) <- acc, aag == j, elem pnt pnts]

chkKwFrmJA ::  Form -> EpistM -> Bool
chkKwFrmJA frm (Pmod sts pre aw acc pnts) = and (map  (isTrueAtWrap (Mo sts pre aw acc) frm ) kwst) 
    where 
    kwst = nub [kst | (aag, pnt, kst) <- acc, aag == a, elem pnt kstj]
    kstj = nub [kst | (aag, pnt, kst) <- acc, aag == j, elem pnt pnts]

isTrueAtWrap :: SM -> Form -> State -> Bool
isTrueAtWrap m frm w = isTrueAt w m frm 

chkAwFrmReal :: Form -> Agent -> EpistM -> Bool
chkAwFrmReal frm agnt (Pmod sts pre aw acc pnts) = and (map (elem frm) (nub ( [frms | (ag,st,frms) <-aw, ag==agnt,elem st pnts])))

chkAwDiffReal :: Agent -> EpistM -> EpistM -> IO ()
chkAwDiffReal agnt (Pmod stb prb awb acb ptb) (Pmod sta pra awa aca pta) =  
  if (length difaware) > 0 
  then if agnt == a then putStrLn ("Accused" ++ ":" ++ show difaware)
       else putStrLn ("Judge" ++ ":" ++ show difaware)
  else return ()
  where 
    baware = nub (concat [frms | (ag,st,frms) <-awb, ag==agnt,elem st ptb])
    aaware = nub (concat [frms | (ag,st,frms) <-awa, ag==agnt,elem st pta])
    difaware = aaware \\ baware 
