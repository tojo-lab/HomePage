module MinBis where 

import Debug.Trace
import Data.List
import Models 

--list2sub :: State -> [(Agent, State, [Form])] -> [(Agent, [Form])]
list2sub :: (Eq a, Eq b, Eq c) => a -> [(b,a,c)] -> [(b,c)]
list2sub sts awfms = [ (ag, formulas) | (ag, sts1, formulas) <- awfms, sts1 == sts ] 
--list2sub sts awfms = [(p,r) | (p,q,r)<-(filter (\(x,y,z) -> x == sts ) awfms)] 

lookupFs :: (Eq a,Eq b, Eq c, Eq ag, Show a, Show b, Show c, Show ag) => a -> a -> [(a,b)] -> [(ag,a,c)]-> (b -> b -> [(ag,c)] -> [(ag,c)] -> Bool) -> Bool
lookupFs i j tablepre tableaw r = case lookup i tablepre of 
  Nothing -> lookup j tablepre == Nothing 
  Just f1 -> case lookup j tablepre of 
      Nothing -> False
--      Just f2 -> (trace("i:" ++ show(i) ++ "j:" ++ show(j) ++ "af1:" ++ show(af1) ++ "af2:" ++ show(af2))) r f1 f2 af1 af2
      Just f2 -> r f1 f2 af1 af2
          where 
             af1 = list2sub i tableaw
             af2 = list2sub j tableaw

initPartition :: (Eq a, Eq b, Eq c, Show a, Show b, Show c) => Model a b c -> (b -> b -> [(Agent,c)] -> [(Agent,c)] -> Bool) -> [[a]]
initPartition (Mo states pre aw rel) r = 
  rel2part states (\ x y -> lookupFs x y pre aw r)

refinePartition :: (Eq a, Eq b, Eq c) => Model a b c -> [[a]] -> [[a]]
refinePartition m p = refineP m p p 
  where 
  refineP :: (Eq a, Eq b, Eq c) => Model a b c -> [[a]] -> [[a]] -> [[a]]
  refineP m part [] = []
  refineP m@(Mo states pre aw rel) part (block:blocks) = 
     newblocks ++ (refineP m part blocks) 
       where 
         newblocks = 
           rel2part block (\ x y -> sameAccBlocks m part x y) 

sameAccBlocks :: (Eq a, Eq b, Eq c) => 
         Model a b c -> [[a]] -> a -> a -> Bool
sameAccBlocks m@(Mo states pre aw rel) part s t = 
    and [ accBlocks m part s ag == accBlocks m part t  ag | 
                                               ag <- all_agents ]

accBlocks :: (Eq a, Eq b, Eq c) => Model a b c -> [[a]] -> a -> Agent -> [[a]]
accBlocks m@(Mo states pre aw rel) part s ag = 
    nub [ bl part y | (ag',x,y) <- rel, ag' == ag, x == s ]

bl :: (Eq a) => [[a]] -> a -> [a]
bl part x = head (filter (\ b -> elem x b) part)

initRefine :: (Eq a, Eq b, Eq c, Show a, Show b, Show c) => Model a b c -> (b -> b -> [(Agent, c)] -> [(Agent, c)] -> Bool) -> [[a]]
initRefine m r = refine m (initPartition m r)

refine :: (Eq a, Eq b, Eq c) => Model a b c -> [[a]] -> [[a]]
refine m part = if rpart == part 
                       then part 
                       else refine m rpart 
  where rpart = refinePartition m part 

minimalModel :: (Eq a, Ord a, Show a, Eq b, Ord b, Show b, Eq c, Ord c, Show c) => 
                 (b -> b -> [(Agent, c)] -> [(Agent, c)] -> Bool) -> Model a b c -> Model [a] b c
minimalModel r m@(Mo states pre aw rel) = 
  (Mo states' pre' aw' rel') 
     where
     partition = initRefine m r
     states'   = partition 
     f         = bl partition
     rel'      = (nub.sort) (map (\ (x,y,z) -> (x, f y, f z)) rel)
     aw'       = (nub.sort) (map (\ (x,y,z) -> (x, f y, z)) aw)
     pre'      = (nub.sort) (map (\ (x,y)   -> (f x, y))      pre)

minimalPmod :: (Eq a, Ord a, Show a, Eq b, Ord b, Show b, Eq c, Ord c, Show c) => 
                  (b -> b -> [(Agent, c)] -> [(Agent, c)] -> Bool) -> Pmod a b c -> Pmod [a] b c
minimalPmod r (Pmod sts pre aw rel pts) = (Pmod sts' pre' aw' rel' pts') 
  where (Mo sts' pre' aw' rel') = minimalModel r (Mo sts pre aw rel)
        pts' = map (bl sts') pts

convert :: (Eq a, Show a) => [a] -> a  -> Integer
convert = convrt 0 
  where 
  convrt :: (Eq a, Show a) => Integer -> [a] -> a -> Integer 
  convrt n []     x = error (show x ++ " not in list")
  convrt n (y:ys) x | x == y    = n
                    | otherwise = convrt (n+1) ys x 

conv ::  (Eq a, Show a) => Model a b c -> Model Integer b c
conv  (Mo worlds val aw acc) = 
      (Mo (map f worlds) 
          (map (\ (x,y)   -> (f x, y)) val)
          (map (\ (x,y,z)   -> (x, f y, z)) aw)
          (map (\ (x,y,z) -> (x, f y, f z)) acc))
  where f = convert worlds

convPmod ::  (Eq a, Show a) => Pmod a b c -> Pmod Integer b c
convPmod (Pmod sts pre aw rel pts) = (Pmod sts' pre' aw' rel' pts') 
   where (Mo sts' pre' aw' rel') = conv (Mo sts pre aw rel)
         pts' = nub (map (convert sts) pts)

bisim ::  (Eq a, Ord a, Show a, Eq b, Ord b, Eq c, Ord c, Show b, Show c) => 
           (b -> b -> [(Agent, c)] -> [(Agent, c)] -> Bool) -> Model a b c -> Model Integer b c 
bisim r = conv . (minimalModel r)

bisimPmod ::  (Eq a, Ord a, Show a, Eq b, Ord b, Eq c, Ord c, Show b, Show c) => 
            (b -> b -> [(Agent, c)] -> [(Agent, c)] -> Bool) -> Pmod a b c -> Pmod Integer b c 
bisimPmod r = convPmod . (minimalPmod r)

