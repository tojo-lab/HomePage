{-# LANGUAGE OverloadedStrings #-}
module Callbacks where
import qualified Graphics.UI.FLTK.LowLevel.FL as FL
import Graphics.UI.FLTK.LowLevel.Fl_Types
import Graphics.UI.FLTK.LowLevel.Image
import Graphics.UI.FLTK.LowLevel.FLTKHS
import DEMO
import qualified Data.Text as T
import System.Process
import System.IO
import GHC.IO.Handle
import System.Directory


--import DemoGuiMain
{-
buttonCb ::  Ref TextDisplay -> Ref Button -> IO ();
buttonCb a _ = do {
--        l1 <- T.pack (show drgA);
        l2 <- textBufferNew (Just 10) (Just 10);      
        setText l2  (T.pack (show drgA));
        setBuffer a (Just l2);
        };
-}

buttonCb2 :: Ref Input -> Ref TextDisplay -> Ref Button -> IO ();
buttonCb2 a b _ = do {
        l1 <- getValue a;
        l2 <- textBufferNew (Just 10) (Just 10); 
        setText l2 (T.pack (show l1));
        setBuffer b (Just l2);
        };       

btnIniCb :: Ref Choice -> Ref Input -> Ref RoundButton 
            -> Ref Input -> Ref RoundButton 
            -> Ref Input -> Ref RoundButton 
            -> Ref Input -> Ref RoundButton 
            -> Ref TextDisplay -> Ref Button -> IO ()
btnIniCb inum ii1 ir1 ii2 ir2 ii3 ir3 ii4 ir4 inio _ = do 
        vinum <- getValue inum
        vii1 <- getValue ii1
        vir1 <- getValue ir1
        vii2 <- getValue ii2
        vir2 <- getValue ir2
        vii3 <- getValue ii3
        vir3 <- getValue ir3
        vii4 <- getValue ii4
        vir4 <- getValue ir4
        l3 <- textBufferNew (Just 100) (Just 100)
        let frm1 = if (T.length vii1) > 0 
                       then case vir1 of True  -> [(1, fl1)]
                                         False -> [(2, fl1)]
                       else  []
                   where fl1 = strToForm (T.unpack vii1)
        let frm2 = if (T.length vii2) > 0 
                       then case vir2 of True  -> frm1 ++ [(1, fl2)]
                                         False -> frm1 ++ [(2, fl2)]
                       else frm1
                   where fl2 = strToForm (T.unpack vii2)
        let frm3 = if (T.length vii3) > 0 
                       then case vir3 of True  -> frm2 ++ [(1, fl3)]
                                         False -> frm2 ++ [(2, fl3)]
                       else frm2
                   where fl3 = strToForm (T.unpack vii3)
        let frm4 = if (T.length vii4) > 0 
                       then case vir3 of True  -> frm3 ++ [(1, fl4)]
                                         False -> frm3 ++ [(2, fl4)]
                       else frm3
                   where fl4 = strToForm (T.unpack vii4)
        let iniMo = case vinum of
                         (MenuItemIndex 0) -> initSet frm4 2
                         (MenuItemIndex 1) -> initSet frm4 3
                         (MenuItemIndex 2) -> initSet frm4 4
            iniMoText = T.pack (showMstr iniMo)
        setText l3 iniMoText
        setBuffer inio (Just l3)
        
    
ini_frmCb :: Ref RoundButton -> Ref RoundButton -> IO ();
ini_frmCb a  b = do {
    l2 <- clear a;
    setonly b;
    };

btnResJCb :: Ref Choice -> Ref Input -> Ref Input
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref RoundButton -> Ref TextDisplay 
        -> Ref Output -> Ref Output -> Ref Output -> Ref Output -> Ref Output
        -> Ref Window -> Ref Box -> Ref Button-> IO ()
btnResJCb inum cas xelm
    ii1 ir1
    ii2 ir2 
    ii3 ir3 
    ii4 ir4 
    ri1 ra1 rj1 
    ri2 ra2 rj2 
    ri3 ra3 rj3 
    ri4 ra4 rj4 
    ri5 ra5 rj5 
    racons ro 
    jkaCas jkaACsn jkaEx jkaKCsn intRes diag diagm
    b = do 
        deactivate b
        vinum <- getValue inum
        vcas <- getValue cas
        vxelm <- getValue xelm
        vii1 <- getValue ii1
        vir1 <- getValue ir1
        vii2 <- getValue ii2
        vir2 <- getValue ir2
        vii3 <- getValue ii3
        vir3 <- getValue ir3
        vii4 <- getValue ii4
        vir4 <- getValue ir4
        vri1 <- getValue ri1
        vra1 <- getValue ra1
        vrj1 <- getValue rj1
        vri2 <- getValue ri2
        vra2 <- getValue ra2
        vrj2 <- getValue rj2
        vri3 <- getValue ri3
        vra3 <- getValue ra3
        vrj3 <- getValue rj3
        vri4 <- getValue ri4
        vra4 <- getValue ra4
        vrj4 <- getValue rj4
        vri5 <- getValue ri5
        vra5 <- getValue ra5
        vrj5 <- getValue rj5
        vracons <- getValue racons
        l3 <- textBufferNew (Just 100) (Just 100)
        let causeFrm = if (T.length vcas) > 0 
                       then strToForm (T.unpack vcas)
                       else Top 
        let exElmFrm = if (T.length vxelm) > 0 
                       then strToForm (T.unpack vxelm)
                       else Top 
        let frm1 = if (T.length vii1) > 0 
                       then case vir1 of True  -> [(1, fl1)]
                                         False -> [(2, fl1)]
                       else  []
                   where fl1 = strToForm (T.unpack vii1)
        let frm2 = if (T.length vii2) > 0 
                       then case vir2 of True  -> frm1 ++ [(1, fl2)]
                                         False -> frm1 ++ [(2, fl2)]
                       else frm1
                   where fl2 = strToForm (T.unpack vii2)
        let frm3 = if (T.length vii3) > 0 
                       then case vir3 of True  -> frm2 ++ [(1, fl3)]
                                         False -> frm2 ++ [(2, fl3)]
                       else frm2
                   where fl3 = strToForm (T.unpack vii3)
        let frm4 = if (T.length vii4) > 0 
                       then case vir4 of True  -> frm3 ++ [(1, fl4)]
                                         False -> frm3 ++ [(2, fl4)]
                       else frm3
                   where fl4 = strToForm (T.unpack vii4)
        if ( isInfixOf "err" ((show frm1) ++ (show frm2) ++ (show frm3) ++ (show frm4) 
              ++ (show (strToForm (T.unpack vri1))) ++ (show (strToForm (T.unpack vri2)))
              ++ (show (strToForm (T.unpack vri3))) ++ (show (strToForm (T.unpack vri4))) 
              ++ (show (strToForm (T.unpack vri5))))) 
        then do
            print "Input error."
            setLabel diagm (T.pack "Please enter the formula in a correct syntax !")
            showWidget diag
            makeCurrent diag
        else return ()

        let iniMo = case vinum of
                         (MenuItemIndex 0) -> initSet frm4 2
                         (MenuItemIndex 1) -> initSet frm4 3
                         (MenuItemIndex 2) -> initSet frm4 4
            resAmo1 = calcResMo a vri1 vra1 iniMo
            resAmo2 = calcResMo a vri2 vra2 resAmo1
            resAmo3 = calcResMo a vri3 vra3 resAmo2
            resAmo4 = calcResMo a vri4 vra4 resAmo3
            resAmo5 = calcResMo a vri5 vra5 resAmo4
            resAmoCons = case vracons of 
                              True -> think1 a resAmo5
                              False -> thinkN a resAmo5
            resJmo1 = calcResMo j vri1 vrj1 resAmoCons
            resJmo2 = calcResMo j vri2 vrj2 resJmo1
            resJmo3 = calcResMo j vri3 vrj3 resJmo2
            resJmo4 = calcResMo j vri4 vrj4 resJmo3
            resJmo5 = calcResMo j vri5 vrj5 resJmo4
            resJmoCons = thinkN j resJmo5
            jknowCas = chkAwFrmJA causeFrm resJmoCons
            jknCasTex = case jknowCas of 
                         True -> "Yes"
                         False -> "No"
            jknowaEx = chkAwFrmJA exElmFrm resJmoCons
            jknExTex = case jknowaEx of 
                         True -> "Yes"
                         False -> "No"
            csnFrm = Disj[Neg causeFrm, exElmFrm]
            jknowaCsn = chkAwFrmJA csnFrm resJmoCons
            jknCsnTex = case jknowaCsn of 
                         True -> "Yes"
                         False -> "No"
            jkaKCsnBool = chkKwFrmJA csnFrm resJmoCons
            jkaKCsnTex = case jkaKCsnBool of 
                             True -> "Yes"
                             False -> "No"
            jRes = judgeRes [jknowCas, jknowaCsn,jkaKCsnBool]
            jResTex  = case jRes of 
                           1 -> "Deterimnistic intention"
                           2 -> "Willfull negligence"
                           3 -> "Mistake of causal relation"
                           4 -> "Negligence"
                           5 -> "Innocence"
        chkAwDiffReal a iniMo resAmo1
        chkAwDiffReal a resAmo1 resAmo2
        chkAwDiffReal a resAmo2 resAmo3
        chkAwDiffReal a resAmo3 resAmo4
        chkAwDiffReal a resAmo4 resAmo5
        chkAwDiffReal a resAmo5 resAmoCons
        chkAwDiffReal j resAmoCons resJmo1
        chkAwDiffReal j resJmo1 resJmo2
        chkAwDiffReal j resJmo2 resJmo3
        chkAwDiffReal j resJmo3 resJmo4
        chkAwDiffReal j resJmo4 resJmo5
        chkAwDiffReal j resJmo5 resJmoCons
        c1 <- setValue jkaCas (T.pack jknCasTex) Nothing
        c2 <- setValue jkaACsn (T.pack jknCsnTex) Nothing
        c3 <- setValue jkaEx (T.pack jknExTex) Nothing
        c4 <- setValue jkaKCsn (T.pack jkaKCsnTex) Nothing
        c5 <- setValue intRes (T.pack jResTex) Nothing
        setText l3 (T.pack (showMstr (resJmoCons)))
        setBuffer ro (Just l3)
        activate b

judgeRes :: [Bool] -> Int
judgeRes [True,  True,  _]     = 1
judgeRes [False, True,  _]     = 2
judgeRes [True,  False, _]     = 3
judgeRes [False, False, True ] = 4
judgeRes [False, False, False] = 5


btnWrGraphCb :: Ref Choice 
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref Input -> Ref Choice -> Ref Choice 
        -> Ref RoundButton -> Ref Choice -> Ref Window -> Ref Box
        -> Ref Button -> IO ()
btnWrGraphCb inum 
    ii1 ir1
    ii2 ir2 
    ii3 ir3 
    ii4 ir4 
    ri1 ra1 rj1 
    ri2 ra2 rj2 
    ri3 ra3 rj3 
    ri4 ra4 rj4 
    ri5 ra5 rj5 
    racons  lnum diag diagm
    b = do 
        deactivate b
        redraw b
        vinum <- getValue inum
        vii1 <- getValue ii1
        vir1 <- getValue ir1
        vii2 <- getValue ii2
        vir2 <- getValue ir2
        vii3 <- getValue ii3
        vir3 <- getValue ir3
        vii4 <- getValue ii4
        vir4 <- getValue ir4
        vri1 <- getValue ri1
        vra1 <- getValue ra1
        vrj1 <- getValue rj1
        vri2 <- getValue ri2
        vra2 <- getValue ra2
        vrj2 <- getValue rj2
        vri3 <- getValue ri3
        vra3 <- getValue ra3
        vrj3 <- getValue rj3
        vri4 <- getValue ri4
        vra4 <- getValue ra4
        vrj4 <- getValue rj4
        vri5 <- getValue ri5
        vra5 <- getValue ra5
        vrj5 <- getValue rj5
        vracons <- getValue racons
        vlnum <- getValue lnum
        let frm1 = if (T.length vii1) > 0 
                       then case vir1 of True  -> [(1, fl1)]
                                         False -> [(2, fl1)]
                       else  []
                   where fl1 = strToForm (T.unpack vii1)
        let frm2 = if (T.length vii2) > 0 
                       then case vir2 of True  -> frm1 ++ [(1, fl2)]
                                         False -> frm1 ++ [(2, fl2)]
                       else frm1
                   where fl2 = strToForm (T.unpack vii2)
        let frm3 = if (T.length vii3) > 0 
                       then case vir3 of True  -> frm2 ++ [(1, fl3)]
                                         False -> frm2 ++ [(2, fl3)]
                       else frm2
                   where fl3 = strToForm (T.unpack vii3)
        let frm4 = if (T.length vii4) > 0 
                       then case vir4 of True  -> frm3 ++ [(1, fl4)]
                                         False -> frm3 ++ [(2, fl4)]
                       else frm3
                   where fl4 = strToForm (T.unpack vii4)
        let iniMo = case vinum of
                         (MenuItemIndex 0) -> initSet frm4 2
                         (MenuItemIndex 1) -> initSet frm4 3
                         (MenuItemIndex 2) -> initSet frm4 4
            resAmo1 = calcResMo a vri1 vra1 iniMo
            resAmo2 = calcResMo a vri2 vra2 resAmo1
            resAmo3 = calcResMo a vri3 vra3 resAmo2
            resAmo4 = calcResMo a vri4 vra4 resAmo3
            resAmo5 = calcResMo a vri5 vra5 resAmo4
            resAmoCons = case vracons of 
                              True -> think1 a resAmo5
                              False -> thinkN a resAmo5
            resJmo1 = calcResMo j vri1 vrj1 resAmoCons
            resJmo2 = calcResMo j vri2 vrj2 resJmo1
            resJmo3 = calcResMo j vri3 vrj3 resJmo2
            resJmo4 = calcResMo j vri4 vrj4 resJmo3
            resJmo5 = calcResMo j vri5 vrj5 resJmo4
            resJmoCons = thinkN j resJmo5
        writeGr "./current.dot" (graphviz resJmoCons) 
        system("circo -Tpng -o./current.png ./current.dot")
        case vlnum of
             (MenuItemIndex 0) -> system("circo -Tpng -o./current.png ./current.dot")
             (MenuItemIndex 1) -> system("dot -Tpng -o./current.png ./current.dot")
        eiim1 <- pngImageNew "./current.png"
        case eiim1 of 
            (Right im1) -> do
                           im2 <- Graphics.UI.FLTK.LowLevel.FLTKHS.copy (safeCast im1::Ref Image) 
                                  (Just (Size (Width 1200) (Height 600)))
                           window <- doubleWindowNew (Size (Width 1200) (Height 600)) Nothing Nothing
                           begin window
                           button <- buttonNew
                                      (Rectangle
                                      (Position (X 590) (Y 290))
                                      (Size (Width 10) (Height 10)))
                                      Nothing 
                           setImage button im2
                           end window
                           setResizable window (Just button) 
                           showWidget window
--                           makeCurrent window
--activate window
               -- redraw pngWidgetCreated
--draw im1 (Position (X 10) (Y 10)) 
            (Left im1) -> print "AAA"
        activate b

drawPngFile :: Ref PNGImage -> Ref Widget -> IO ()
drawPngFile img1 widget = do
    x <- getX widget
    y <- getY widget
    w <- getW widget
    h <- getH widget
    flcPushClip (toRectangle (x,y,w,h))
    draw img1 (Position (X x) (Y y))
    flcPopClip

btnResACb :: Ref Choice -> Ref Input -> Ref Input
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref RoundButton
        -> Ref Input -> Ref Choice 
        -> Ref Input -> Ref Choice 
        -> Ref Input -> Ref Choice 
        -> Ref Input -> Ref Choice 
        -> Ref Input -> Ref Choice 
        -> Ref RoundButton -> Ref TextDisplay  
        -> Ref Button-> IO ()
btnResACb inum cas xelm
    ii1 ir1  
    ii2 ir2 
    ii3 ir3 
    ii4 ir4 
    ri1 ra1 
    ri2 ra2 
    ri3 ra3 
    ri4 ra4 
    ri5 ra5 
    racons ro _ = do 
        vinum <- getValue inum
        vii1 <- getValue ii1
        vir1 <- getValue ir1
        vii2 <- getValue ii2
        vir2 <- getValue ir2
        vii3 <- getValue ii3
        vir3 <- getValue ir3
        vii4 <- getValue ii4
        vir4 <- getValue ir4
        vcas <- getValue cas
        vxelm <- getValue xelm
        vri1 <- getValue ri1
        vra1 <- getValue ra1
        vri2 <- getValue ri2
        vra2 <- getValue ra2
        vri3 <- getValue ri3
        vra3 <- getValue ra3
        vri4 <- getValue ri4
        vra4 <- getValue ra4
        vri5 <- getValue ri5
        vra5 <- getValue ra5
        vracons <- getValue racons
        l3 <- textBufferNew (Just 10) (Just 10)
        let frm1 = if (T.length vii1) > 0 
                       then case vir1 of True  -> [(1, fl1)]
                                         False -> [(2, fl1)]
                       else  []
                   where fl1 = strToForm (T.unpack vii1)
        let frm2 = if (T.length vii2) > 0 
                       then case vir2 of True  -> frm1 ++ [(1, fl2)]
                                         False -> frm1 ++ [(2, fl2)]
                       else frm1
                   where fl2 = strToForm (T.unpack vii2)
        let frm3 = if (T.length vii3) > 0 
                       then case vir3 of True  -> frm2 ++ [(1, fl3)]
                                         False -> frm2 ++ [(2, fl3)]
                       else frm2
                   where fl3 = strToForm (T.unpack vii3)
        let frm4 = if (T.length vii4) > 0 
                       then case vir3 of True  -> frm3 ++ [(1, fl4)]
                                         False -> frm3 ++ [(2, fl4)]
                       else frm3
                   where fl4 = strToForm (T.unpack vii4)
        let iniMo = case vinum of
                         (MenuItemIndex 0) -> initSet frm4 2
                         (MenuItemIndex 1) -> initSet frm4 3
                         (MenuItemIndex 2) -> initSet frm4 4
            resAmo1 = calcResMo a vri1 vra1 iniMo
            resAmo2 = calcResMo a vri2 vra2 resAmo1
            resAmo3 = calcResMo a vri3 vra3 resAmo2
            resAmo4 = calcResMo a vri4 vra4 resAmo3
            resAmo5 = calcResMo a vri5 vra5 resAmo4
            resAmoCons = case vracons of 
                              True -> think1 a resAmo5
                              False -> thinkN a resAmo5
        setText l3 (T.pack (showMstr (resAmoCons)))
        setBuffer ro (Just l3)


calcResMo :: Agent -> T.Text -> MenuItemIndex -> EpistM -> EpistM
calcResMo agt cri crc befMo = if (T.length cri ) > 0
                              then case crc of
                                       (MenuItemIndex 0) -> befMo
                                       (MenuItemIndex 1) -> knowIm [agt] befMo (strToForm (T.unpack cri))
                                       (MenuItemIndex 2) -> knowEx [agt] befMo (strToForm (T.unpack cri))
                                       (MenuItemIndex 3) -> remind agt befMo (strToForm (T.unpack cri))
                              else befMo

ini_numCb :: Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Choice -> IO ()
ini_numCb inp inq inr ins int inum = do
        vinum <- getValue inum
        case vinum of
             (MenuItemIndex 0) -> do activate inp
                                     activate inq
                                     deactivate inr
                                     deactivate ins
                                     deactivate int
             (MenuItemIndex 1) -> do activate inp
                                     activate inq
                                     activate inr
                                     deactivate ins
                                     deactivate int
             (MenuItemIndex 2) -> do activate inp
                                     activate inq
                                     activate inr
                                     activate ins
                                     deactivate int
             (MenuItemIndex 3) -> do activate inp
                                     activate inq
                                     activate inr
                                     activate ins
                                     activate int
setUnvisGrp :: [Ref Group] -> [Ref Input] -> IO ()
setUnvisGrp [] [] = return ()
setUnvisGrp [x] [y] = do
    r1 <- setValue y (T.pack "") Nothing
    hide x
setUnvisGrp (x:xs) (y:ys) = do
    hide x
    r1 <- setValue y (T.pack "") Nothing
    setUnvisGrp xs ys

setVisGrp :: [Ref Group] -> IO ()
setVisGrp [] = return ()
setVisGrp [x] = do
    setVisible x
    redraw x
setVisGrp (x:xs) = do
    setVisible x
    redraw x
    setVisGrp xs

setInputNumCb :: Int -> Ref Output -> Ref Input -> IO()
setInputNumCb n nout _ = do
    c1 <- setValue nout (T.pack (show n)) Nothing
    return ()

putImplBtnCb :: Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input
    -> Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input ->
    Ref Output -> Ref Button -> IO()
putImplBtnCb ini1 ini2 ini3 ini4
    dep1 dep2 dep3 dep4 dep5 cause exelm outdm _ = do
    crnt <- getValue outdm
    case (T.unpack crnt) of
        "1" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini1 (T.pack "→")
                 return ()
        "2" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini2 (T.pack "→")
                 return ()
        "3" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini3 (T.pack "→")
                 return ()
        "4" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini4 (T.pack "→")
                 return ()
        "5" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep1 (T.pack "→")
                 return ()
        "6" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep2 (T.pack "→")
                 return ()
        "7" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep3 (T.pack "→")
                 return ()
        "8" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep4 (T.pack "→")
                 return ()
        "9" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep5 (T.pack "→")
                 return ()
        "10" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert cause (T.pack "→")
                 return ()
        "11" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert exelm (T.pack "→")
                 return ()

putNegBtnCb :: Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input
    -> Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input ->
    Ref Output -> Ref Button -> IO()
putNegBtnCb ini1 ini2 ini3 ini4
    dep1 dep2 dep3 dep4 dep5 cause exelm outdm _ = do
    crnt <- getValue outdm
    case (T.unpack crnt) of
        "1" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini1 (T.pack "￢")
                 return ()
        "2" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini2 (T.pack "￢")
                 return ()
        "3" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini3 (T.pack "￢")
                 return ()
        "4" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini4 (T.pack "￢")
                 return ()
        "5" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep1 (T.pack "￢")
                 return ()
        "6" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep2 (T.pack "￢")
                 return ()
        "7" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep3 (T.pack "￢")
                 return ()
        "8" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep4 (T.pack "￢")
                 return ()
        "9" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep5 (T.pack "￢")
                 return ()
        "10" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert cause (T.pack "￢")
                 return ()
        "11" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert exelm (T.pack "￢")
                 return ()

putLtrBtnCb :: Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input
    -> Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input -> Ref Input ->
    Ref Output -> String -> Ref Button -> IO()
putLtrBtnCb ini1 ini2 ini3 ini4
    dep1 dep2 dep3 dep4 dep5 cause exelm outdm str _ = do
    crnt <- getValue outdm
    case (T.unpack crnt) of
        "1" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini1 (T.pack str)
                 return ()
        "2" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini2 (T.pack str)
                 return ()
        "3" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini3 (T.pack str)
                 return ()
        "4" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert ini4 (T.pack str)
                 return ()
        "5" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep1 (T.pack str)
                 return ()
        "6" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep2 (T.pack str)
                 return ()
        "7" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep3 (T.pack str)
                 return ()
        "8" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep4 (T.pack str)
                 return ()
        "9" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert dep5 (T.pack str)
                 return ()
        "10" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert cause (T.pack str)
                 return ()
        "11" -> do
                 c1 <- Graphics.UI.FLTK.LowLevel.FLTKHS.insert exelm (T.pack str)
                 return ()


readCllback :: System.IO.Handle -> System.IO.Handle ->  Ref TextBuffer -> IO () 
readCllback stdo stdh textbuff = do 
    hClose stdo
    hDuplicateTo stdh stdout
    h <- openFile "mystdout" ReadWriteMode
    str <- hGetContents h
    appendToBuffer textbuff (T.pack str)
    hClose h
    removeFile "mystdout"
    h <- openFile "mystdout" ReadWriteMode
    hDuplicateTo h stdout
    hClose h
    FL.repeatTimeout 10 (readCllback stdout stdh textbuff) 

spinBkgCb :: [Ref Group] -> [Ref Input] -> Ref Spinner -> IO ()
spinBkgCb grpl inpl sp = do
--    v <- getValue (safeCast valuator :: Ref Valuator)
    v' <- getValue sp
    let v = truncate v'
    let spgrpl = splitAt v grpl
    let spinpl = splitAt v inpl
--    putStrLn ((show v) ++ ":" ++ (show (fst spgrpl)) ++ ":" ++ (show (snd spgrpl)))
    setVisGrp (fst spgrpl)
    setUnvisGrp (snd spgrpl) (snd spinpl)

diaClsBtnCb :: Ref Window -> Ref Button -> IO ()
diaClsBtnCb dialogue b
    = do
        hide dialogue

clrLogBtnCb :: Ref TextBuffer -> Ref Button -> IO ()
clrLogBtnCb logtxtbf b
    = do
        setText logtxtbf (T.pack "")
