﻿
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
#
#                       Belief Calculator
#                            ver. 0.6
#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

# USAGE: 

---Calculator of `Truth Set' ---
Please input `FORMULA' to the above text field then press [||\varphi||] button or [ENTER] key or [Alt + ENTER] key.
If FORMULA is successfully calculated, the resultant matrix appears to console window.

Syntax of FORMULA::=
PROPOSITION |
\chl{FROM_AGENT TO_AGENT} | //channel constant
\neg FORMULA | 
FORMULA \lor FORMULA |
FORMULA \land FORMULA |
FORMULA \to FORMULA | //implication
[PROGRAM_TERM] FORMULA | //Box operator
<PROGRAM_TERM> FORMULA | //Diamond operator

Syntax of PROGRAM_TERM::=
\rel{AGENT} | // This is atomic program term.
PROGRAM_TERM \cup PROGRAM_TERM | //non-deterministic choice
PROGRAM_TERM \; PROGRAM_TERM | //composition
\? PROGRAM_TERM | test
\cmf{FORMULA}{AGENT}{AGENT} //semi-private announcement

NOTE: You may use parenthesis, i.e., `(' and `)'.
Remark: Above syntax is based on TeX command. At the end of this HELP, We show TeX source which is not predefined in TeX, e.g., `\chl' and `\?'.

EXAMPLE: 
((p_1 \to p_2) \to p_1) \to p_1 [ENTER]
[\cmf{p_1}{a_1}{a_2}] p_1 [ENTER]

---Frame property verifier---
Please input following option to the text field or leave empty then press [FP] button or [Alt + F] key.
OPTIONS::= AGENT | all 

EXAMPLE: 
[FP] //verify frame property of current editing relation
a_1 [FP]
all [FP] //verify frame property of all relations

---Visualization---
Please input an id of AGENT or WORLD  just click [Viz] button.
Please input following option to the text field or leave empty then press [Viz] button or [Alt + V] key.
OPTIONS::= AGENT | WORLD | all

EXAMPLE: 
[Viz] //visualize relation of current editiong one
a_1 [Viz] //visualize relation of an agent a_1
w_1 [Viz] //visualize channel relation at w_1 for every agent

If this function is successfully finished, output jpeg file will appear on a window.
Note: Output `dot' files and `jpeg' files are saved under `INSTALLED_DIR/dot' directory.

---TeX command---
Here are TeX source which are not predefined in TeX:
\newcommand{\rel}[1]{\mathop{\mathsf{R}_{#1}}}
\newcommand{\chl}[1]{\mathsf{c}_{{#1}}}
\newcommand{\cmf}[3]{{[{#1}\!\!\downarrow^{#2}_{#3}]}}
\newcommand{\?}{?}
\renewcommand{\;}{;}


# Developer
Ryo Hatano, Tojo-lab, Japan Advanced Institute of Science and Technology
r-hatano@jaist.ac.jp
