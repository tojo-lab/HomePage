﻿#!/bin/sh
java -cp .:./dist/linsem-gui.jar:./lib/ujmp-complete-0.2.5.jar:./lib/linsem-ext.jar:./lib/processing/core.jar:./lib/processing/gluegen-rt.jar:./lib/processing/gluegen-rt-natives-macosx-universal.jar:./lib/processing/jogl-all.jar:./lib/processing/jogl-all-natives-macosx-universal.jar: linsem.gui.GUIMain
